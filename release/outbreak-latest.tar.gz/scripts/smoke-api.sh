#!/bin/bash
set -euo pipefail

BASE_URL="${1:-${BASE_URL:-http://127.0.0.1:8765}}"
ROM_PATH="${ROM_PATH:-/fake/path/smoke-test.sfc}"
CORE_NAME="${CORE_NAME:-snes9x}"

log() {
    printf '[smoke] %s\n' "$1"
}

fetch_json() {
    local path="$1"
    curl -fsS "${BASE_URL}${path}"
}

assert_json() {
    local json="$1"
    local expr="$2"
    local message="$3"

    python3 - "$json" "$expr" "$message" <<'PYEOF'
import json
import sys

payload = json.loads(sys.argv[1])
expr = sys.argv[2]
message = sys.argv[3]
value = eval(expr, {}, {"payload": payload})
if not value:
    raise SystemExit(message)
PYEOF
}

wait_for_server() {
    local attempt
    for attempt in $(seq 1 30); do
        if curl -fsS "${BASE_URL}/status" >/dev/null 2>&1; then
            return 0
        fi
        sleep 1
    done
    echo "Server did not become ready at ${BASE_URL}" >&2
    exit 1
}

log "Waiting for ${BASE_URL}"
wait_for_server

status_json="$(fetch_json /status)"
assert_json "$status_json" 'payload["status"] == "running"' "status endpoint did not report running"
log "status endpoint is healthy"

session_json="$(fetch_json /session)"
assert_json "$session_json" 'payload.get("status", "idle") in ("idle", "hosting", "playing")' "session endpoint returned unexpected payload"
log "session endpoint returned valid JSON"

peers_json="$(fetch_json /peers)"
assert_json "$peers_json" '"peers" in payload and "max_ping" in payload' "peers endpoint returned unexpected payload"
log "peers endpoint returned expected keys"

ui_html="$(curl -fsS "${BASE_URL}/ui")"
printf '%s' "$ui_html" | grep -q 'const API = window.location.origin;'
log "UI is serving origin-relative API configuration"

log "Triggering simulated broadcast"
broadcast_json="$(curl -fsS -X POST "${BASE_URL}/broadcast" \
    -H "Content-Type: application/json" \
    -d "{\"rom\":\"${ROM_PATH}\",\"core\":\"${CORE_NAME}\"}")"
assert_json "$broadcast_json" 'payload.get("started") is True' "broadcast endpoint did not report success"

session_json="$(fetch_json /session)"
assert_json "$session_json" 'payload.get("status") == "hosting"' "session did not enter hosting state"
assert_json "$session_json" 'payload.get("system") == "snes"' "session did not include detected system metadata"
log "broadcast populated session state"

log "Stopping session"
stop_json="$(curl -fsS -X POST "${BASE_URL}/stop" \
    -H "Content-Type: application/json" \
    -d '{}')"
assert_json "$stop_json" 'payload.get("stopped") is True' "stop endpoint did not report success"

session_json="$(fetch_json /session)"
assert_json "$session_json" 'payload.get("status") == "idle"' "session did not return to idle state"
log "stop returned session to idle"

history_json="$(fetch_json /history)"
assert_json "$history_json" 'payload.get("total", 0) >= 1' "history did not record the stopped session"
log "history recorded the smoke session"

log "Smoke test passed"
