#!/bin/bash
# =============================================================================
# Outbreak — EmulationStation Event Hook
# Installed to /userdata/system/scripts/netplay-event.sh
#
# ES calls every script in /userdata/system/scripts/ for all UI events.
#
# Handles two events:
#   system-selected — tracks which system the user is browsing
#   game-start      — detects ES built-in "Host a Netplay Game" and registers
#                     the session with Outbreak for lobby, session management,
#                     and core hash advertising.  Does NOT kill or relaunch
#                     RetroArch — ES's configgen-launched RA already has proper
#                     controller config and bezels.
#
# ES event calling convention:
#   $1 = event type  (e.g. system-selected, game-selected, game-start, game-end)
#   $2 = system name (for system-selected) or other context
#   ES_SYSTEM, ES_ROM, ES_GAMENAME also set as env vars
# =============================================================================

INSTALL_DIR="/userdata/system/netplay-arcade"
CORES_SCRIPT="$INSTALL_DIR/scripts/netplay-cores.sh"
CORE_CHECKER="$INSTALL_DIR/scripts/core-checker.sh"
LOG_FILE="/tmp/netplay-arcade.log"
SESSION_FILE="/tmp/netplay_session.json"

_log() { echo "[$(date '+%H:%M:%S')] ES-EVENT: $1" >> "$LOG_FILE" 2>/dev/null; }

EVENT="${1:-}"

case "$EVENT" in

# ─── SYSTEM SELECTED ────────────────────────────────────────────────────────
system-selected)
    SYSTEM="${2:-${ES_SYSTEM:-}}"
    [ -z "$SYSTEM" ] && exit 0
    SYSTEM=$(echo "$SYSTEM" | tr '[:upper:]' '[:lower:]')
    printf '{"system":"%s","ts":%s}\n' "$SYSTEM" "$(date +%s)" \
        > /tmp/es_browsing.json.tmp && \
        mv /tmp/es_browsing.json.tmp /tmp/es_browsing.json
    ;;

# ─── GAME START — netplay session registration ──────────────────────────────
# When the user selects "Host a Netplay Game" from the B-button menu, ES
# launches RetroArch via configgen with --host.  We detect this and write a
# session file so Outbreak's server can advertise the session on the LAN/WAN
# lobby.  We do NOT kill or relaunch RA — ES's launch has proper controller
# config from configgen, bezels, and all system overrides.
#
# ES event args (camelCase, positional — env vars are NOT set):
#   $1 = gameStart
#   $2 = system name   (e.g. mame)
#   $3 = emulator type  (e.g. libretro)
#   $4 = core name      (e.g. mame)
#   $5 = ROM path       (e.g. /userdata/roms/mame/roms/avsp.zip)
gameStart)
    ROM_PATH="${5:-${ES_ROM:-}}"
    [ -z "$ROM_PATH" ] && exit 0

    # Run detection in the background so the event hook returns immediately
    # and doesn't block ES.  The subshell will self-exit if RA isn't hosting.
    (
        # Give RA a moment to fully start so we can inspect its cmdline
        sleep 3

        # Find a RetroArch process with --host (ES built-in netplay hosting)
        RA_PID=""
        RA_CMDLINE=""
        for pid_dir in /proc/[0-9]*/cmdline; do
            pid="${pid_dir#/proc/}"
            pid="${pid%/cmdline}"
            args=$(tr '\0' ' ' < "$pid_dir" 2>/dev/null) || continue
            case "$args" in
                *retroarch*--host*)
                    RA_PID="$pid"
                    RA_CMDLINE="$args"
                    break
                    ;;
            esac
        done

        # No RA hosting → normal game launch, nothing to do
        [ -z "$RA_PID" ] && exit 0

        # If an Outbreak-managed session is already active, don't overwrite it
        if [ -f "$SESSION_FILE" ]; then
            src=$(python3 -c "
import json
try: print(json.load(open('$SESSION_FILE')).get('source',''))
except: print('')
" 2>/dev/null)
            if [ -n "$src" ] && [ "$src" != "es_builtin" ]; then
                _log "Outbreak session active (source=$src) — not registering"
                exit 0
            fi
        fi

        _log "ES netplay host detected (RA PID=$RA_PID, ROM=$ROM_PATH)"

        # ── Extract core .so path from RA's command line ─────────────────
        # cmdline format: /usr/bin/retroarch -L /path/to/core.so --config ... --host ...
        CORE_SO=$(echo "$RA_CMDLINE" | grep -oP '(?<=-L )\S+')

        # ── Detect system and core name from ROM ────────────────────────
        SYSTEM_NAME=""
        CORE_NAME=""
        if [ -f "$CORE_CHECKER" ]; then
            meta_json=$(bash "$CORE_CHECKER" check-fix "$ROM_PATH" 2>/dev/null)
            if [ -n "$meta_json" ]; then
                SYSTEM_NAME=$(echo "$meta_json" | python3 -c "import json,sys; print(json.load(sys.stdin).get('system',''))" 2>/dev/null)
                CORE_NAME=$(echo "$meta_json" | python3 -c "import json,sys; print(json.load(sys.stdin).get('core',''))" 2>/dev/null)
            fi
        fi
        # Fallback: derive system from ROM parent dir, core from .so filename
        [ -z "$SYSTEM_NAME" ] && SYSTEM_NAME=$(basename "$(dirname "$ROM_PATH")" | tr '[:upper:]' '[:lower:]')
        if [ -z "$CORE_NAME" ] && [ -n "$CORE_SO" ]; then
            CORE_NAME=$(basename "$CORE_SO" _libretro.so)
        fi

        # ── Get core fingerprint ─────────────────────────────────────────
        # Always hash the actual .so that RA is running (not the pinned
        # channel copy — they may differ if the bind mount wasn't applied).
        CORE_MD5=""
        CORE_CHANNEL=""
        CORE_VER=""
        if [ -n "$CORE_SO" ] && [ -f "$CORE_SO" ]; then
            CORE_MD5=$(md5sum "$CORE_SO" 2>/dev/null | cut -d' ' -f1)
        fi
        # Check if this matches the pinned channel to populate version info
        if [ -f "$CORES_SCRIPT" ]; then
            ver_json=$(bash "$CORES_SCRIPT" version "$CORE_NAME" 2>/dev/null)
            if [ -n "$ver_json" ]; then
                pinned_md5=$(echo "$ver_json" | python3 -c "import json,sys; print(json.load(sys.stdin).get('md5',''))" 2>/dev/null)
                if [ "$CORE_MD5" = "$pinned_md5" ]; then
                    CORE_CHANNEL=$(echo "$ver_json" | python3 -c "import json,sys; print(json.load(sys.stdin).get('channel',''))" 2>/dev/null)
                    CORE_VER=$(echo "$ver_json" | python3 -c "import json,sys; print(json.load(sys.stdin).get('display_version',''))" 2>/dev/null)
                else
                    CORE_CHANNEL="system"
                    _log "WARN: running core ($CORE_MD5) != pinned channel ($pinned_md5)"
                fi
            fi
        fi
        [ -z "$CORE_CHANNEL" ] && CORE_CHANNEL="system"

        # ── Detect host IP ──────────────────────────────────────────────
        HOST_IP=$(timeout 2 ip route get 8.8.8.8 2>/dev/null | awk '{print $7; exit}')
        GAME_NAME=$(basename "$ROM_PATH" | sed 's/\.[^.]*$//')
        USERNAME=$(hostname)

        # ── Fighter Mode check ──────────────────────────────────────────
        # Rollback enabled for lightweight cores; excluded for heavy ones
        # (N64) where large savestates make it unreliable.
        USE_ROLLBACK=false
        case "$CORE_NAME" in
            mupen64plus*) ;;  # too heavy
            flycast*|fbneo*|mame*|snes9x*|bsnes*|genesis*|picodrive*|\
            fceumm*|mesen*|nestopia*|mgba*|vba*|gambatte*|\
            mednafen_ngp*|mednafen_supergrafx*|stella*)
                nproc=$(nproc 2>/dev/null || echo 1)
                load_int=$(awk '{printf "%d", $1 * 100}' /proc/loadavg 2>/dev/null || echo 9999)
                threshold_int=$(( nproc * 75 ))
                [ "$load_int" -lt "$threshold_int" ] && USE_ROLLBACK=true
                ;;
        esac

        # ── Write session file for Outbreak server ──────────────────────
        python3 -c "
import json, sys, time
d = {
    'game':         sys.argv[1],
    'rom':          sys.argv[2],
    'core':         sys.argv[3],
    'system':       sys.argv[4],
    'core_so':      sys.argv[5],
    'core_md5':     sys.argv[6],
    'core_channel': sys.argv[7],
    'core_version': sys.argv[8],
    'host':         sys.argv[9],
    'port':         55435,
    'timestamp':    int(time.time()),
    'broadcaster':  sys.argv[10],
    'local_players': 1,
    'max_players':  2,
    'use_rollback': sys.argv[11] == 'true',
    'status':       'hosting',
    'role':         'host',
    'source':       'es_builtin',
    'ra_pid':       int(sys.argv[12]),
}
with open(sys.argv[13], 'w') as f:
    json.dump(d, f, indent=2)
" "$GAME_NAME" "$ROM_PATH" "$CORE_NAME" "$SYSTEM_NAME" \
  "${CORE_SO:-}" "$CORE_MD5" "$CORE_CHANNEL" "$CORE_VER" \
  "$HOST_IP" "$USERNAME" "$USE_ROLLBACK" "$RA_PID" "$SESSION_FILE" 2>/dev/null

        if [ "$USE_ROLLBACK" = "true" ]; then
            _log "Session registered: $GAME_NAME (core=$CORE_NAME, Fighter Mode) — RA PID=$RA_PID kept running"
        else
            _log "Session registered: $GAME_NAME (core=$CORE_NAME) — RA PID=$RA_PID kept running"
        fi

    ) >> "$LOG_FILE" 2>&1 &
    ;;

# ─── GAME END — clean up session ────────────────────────────────────────────
gameEnd)
    # If there's an es_builtin session, clean it up when the game exits
    if [ -f "$SESSION_FILE" ]; then
        src=$(python3 -c "
import json
try: print(json.load(open('$SESSION_FILE')).get('source',''))
except: print('')
" 2>/dev/null)
        if [ "$src" = "es_builtin" ]; then
            rm -f "$SESSION_FILE"
            _log "ES game ended — session cleaned up"
        fi
    fi
    ;;

esac
