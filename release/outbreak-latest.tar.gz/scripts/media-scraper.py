#!/usr/bin/env python3
"""
Outbreak — ScreenScraper Media Downloader
Runs as a standalone background process to fetch box art, screenshots,
fanart, videos, and metadata for ROMs that are missing gamelist entries.

Usage:
    python3 media-scraper.py <system_dir> [--system-id <id>]

Examples:
    python3 media-scraper.py /userdata/roms/fbneo
    python3 media-scraper.py /userdata/roms/mame --system-id 75
    python3 media-scraper.py /userdata/roms/snes --system-id 4

Reads ScreenScraper credentials from ES settings at:
    /userdata/system/configs/emulationstation/es_settings.cfg

This script:
- Has its own lockfile to prevent concurrent runs
- Throttles API requests (1 per 2 seconds) to avoid rate limits
- Downloads one file at a time to avoid overwhelming the system
- Runs independently from the ROM download queue
- Updates gamelist.xml incrementally (doesn't overwrite existing entries)
"""

import json
import os
import re
import signal
import sys
import time
import urllib.request
import urllib.error
import urllib.parse
import xml.etree.ElementTree as ET
from pathlib import Path

# ─── Configuration ────────────────────────────────────────────────────────────

LOG_FILE = "/tmp/netplay-arcade.log"
LOCK_FILE = "/tmp/outbreak-media-scraper.lock"
ES_SETTINGS = "/userdata/system/configs/emulationstation/es_settings.cfg"

# ScreenScraper API — dev credentials are the same ones compiled into
# Batocera's EmulationStation (open source, publicly available in the binary).
SS_DEV_ID = "batoceralinux"
SS_DEV_PW = "omvIrirRPuY"
SS_BASE = "https://api.screenscraper.fr/api2"

# Default system ID for arcade (covers both FBNeo and MAME arcade ROMs)
DEFAULT_SYSTEM_ID = 75

# Auto-detect ScreenScraper system ID from directory name
SS_SYSTEM_IDS = {
    "nes": 3, "snes": 4, "megadrive": 1, "genesis": 1,
    "gba": 12, "gb": 9, "gbc": 10,
    "arcade": 75, "fbneo": 75, "mame": 75, "neogeo": 75,
    "atari2600": 26, "mastersystem": 2, "gamegear": 21,
    "nds": 15, "turbografx16": 31, "pcengine": 31,
    "32x": 19, "sega32x": 19, "dreamcast": 23,
}

# Throttle: seconds between API requests
REQUEST_DELAY = 2

# Pause downloads while a netplay session is active
SESSION_FILE = "/tmp/netplay_session.json"

def _wait_if_busy():
    """Block while a netplay session is active — free bandwidth for gameplay."""
    while os.path.exists(SESSION_FILE):
        time.sleep(5)

# Media types to download (type → subfolder, extension)
# These map ScreenScraper media types to Batocera's gamelist.xml conventions
MEDIA_MAP = {
    "fanart":  {"subdir": "images",  "suffix": "-image",   "ext": ".png", "xml_tag": "image"},
    "box-2D":  {"subdir": "images",  "suffix": "-thumb",   "ext": ".png", "xml_tag": "thumbnail"},
    "wheel":   {"subdir": "images",  "suffix": "-marquee", "ext": ".png", "xml_tag": "marquee"},
    "ss":      {"subdir": "images",  "suffix": "-screenshot", "ext": ".png", "xml_tag": None},
    "video":   {"subdir": "videos",  "suffix": "-video",   "ext": ".mp4", "xml_tag": "video"},
}

# Region preference order for media selection
REGION_PREF = ["us", "wor", "eu", "jp", "ss"]

# ROM extensions to scan
ROM_EXTENSIONS = {".zip", ".7z", ".chd", ".iso", ".gdi",
                  ".nes", ".sfc", ".smc", ".md", ".gen", ".gb", ".gbc",
                  ".gba", ".ngp", ".ngc", ".a26", ".pce", ".nds",
                  ".32x"}


# ─── Logging ──────────────────────────────────────────────────────────────────

def log(msg):
    ts = time.strftime("%H:%M:%S")
    line = f"[{ts}] MEDIA: {msg}"
    try:
        with open(LOG_FILE, "a") as f:
            f.write(line + "\n")
    except OSError:
        pass
    print(line, flush=True)


# ─── Lockfile ─────────────────────────────────────────────────────────────────

def acquire_lock():
    if os.path.exists(LOCK_FILE):
        try:
            pid = int(open(LOCK_FILE).read().strip())
            os.kill(pid, 0)  # check if process is alive
            log(f"Another scraper is running (PID {pid}) — exiting")
            return False
        except (ValueError, ProcessLookupError, PermissionError):
            os.remove(LOCK_FILE)  # stale lock
    with open(LOCK_FILE, "w") as f:
        f.write(str(os.getpid()))
    return True


def release_lock():
    try:
        os.remove(LOCK_FILE)
    except OSError:
        pass


def cleanup(signum=None, frame=None):
    release_lock()
    sys.exit(0)

signal.signal(signal.SIGTERM, cleanup)
signal.signal(signal.SIGINT, cleanup)


# ─── ScreenScraper credentials from ES settings ──────────────────────────────

def get_ss_credentials():
    """Read user's ScreenScraper username/password from ES settings."""
    user = pw = ""
    try:
        tree = ET.parse(ES_SETTINGS)
        for el in tree.iter("string"):
            name = el.get("name", "")
            val = el.get("value", "")
            if name == "ScreenScraperUser":
                user = val
            elif name == "ScreenScraperPass":
                pw = val
    except (ET.ParseError, FileNotFoundError):
        pass
    return user, pw


# ─── ScreenScraper API ───────────────────────────────────────────────────────

def _simplify_rom_name(rom_name):
    """Simplify ROM filename for ScreenScraper lookup.
    'Alien_Crush_USA.pce' → 'Alien Crush.pce'
    'Street Fighter II Turbo - Hyper Fighting (USA).zip' → 'Street Fighter II Turbo Hyper Fighting.zip'
    """
    stem, ext = os.path.splitext(rom_name)
    # Replace underscores with spaces
    stem = stem.replace("_", " ")
    # Strip region/revision tags in parentheses: (USA), (Europe), (Rev 1), etc.
    stem = re.sub(r'\s*\([^)]*\)', '', stem)
    # Strip bracketed tags: [!], [h1C], etc.
    stem = re.sub(r'\s*\[[^\]]*\]', '', stem)
    # Remove " - " separators (subtitle separators confuse SS)
    stem = stem.replace(" - ", " ")
    # Strip trailing bare region codes (IA downloads: Alien_Crush_USA.pce)
    stem = re.sub(r'\s+(?:USA|Europe|Japan|JPN|EUR)$', '', stem, flags=re.IGNORECASE)
    # Collapse whitespace
    stem = re.sub(r'\s+', ' ', stem).strip()
    return stem + ext


def ss_game_info(rom_name, system_id, ss_user, ss_pass):
    """Fetch game info from ScreenScraper API. Returns parsed JSON or None."""
    # Try simplified name first (better hit rate), fall back to original
    lookup_name = _simplify_rom_name(rom_name)
    attempts = [lookup_name] if lookup_name != rom_name else [rom_name]
    if lookup_name != rom_name:
        attempts.append(rom_name)
    for attempt_name in attempts:
        params = urllib.parse.urlencode({
            "devid": SS_DEV_ID,
            "devpassword": SS_DEV_PW,
            "softname": "Outbreak",
            "output": "json",
            "ssid": ss_user,
            "sspassword": ss_pass,
            "systemeid": system_id,
            "romnom": attempt_name,
        })
        url = f"{SS_BASE}/jeuInfos.php?{params}"
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Outbreak/1.0"})
            with urllib.request.urlopen(req, timeout=20) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                result = data.get("response", {}).get("jeu")
                if result:
                    return result
        except (urllib.error.URLError, json.JSONDecodeError, KeyError, OSError):
            continue
    log(f"API error for {rom_name}: not found after {len(attempts)} attempt(s)")
    return None


def pick_media_url(medias, media_type):
    """Pick the best media URL for a given type, preferring regions in order."""
    candidates = [m for m in medias if m.get("type") == media_type]
    if not candidates:
        return None
    # Try preferred regions first
    for region in REGION_PREF:
        for c in candidates:
            if c.get("region") == region:
                return c.get("url")
    # Fallback: first available
    return candidates[0].get("url") if candidates else None


def pick_text(entries, lang="en", fallback_lang="us"):
    """Pick localized text from ScreenScraper name/synopsis arrays."""
    if not entries:
        return ""
    for entry in entries:
        if entry.get("langue") == lang:
            return entry.get("text", "")
    for entry in entries:
        if entry.get("langue") == fallback_lang:
            return entry.get("text", "")
    # Fallback: first entry
    return entries[0].get("text", "") if entries else ""


def pick_genre(genres, lang="en"):
    """Extract genre string from ScreenScraper genres array."""
    for g in (genres or []):
        for n in g.get("noms", []):
            if n.get("langue") == lang:
                return n.get("text", "")
    return ""


def download_file(url, dest_path):
    """Download a file. Returns True on success."""
    tmp = dest_path + ".dl_tmp"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Outbreak/1.0"})
        with urllib.request.urlopen(req, timeout=60) as resp:
            with open(tmp, "wb") as f:
                while True:
                    chunk = resp.read(65536)
                    if not chunk:
                        break
                    f.write(chunk)
        if os.path.getsize(tmp) > 100:
            os.rename(tmp, dest_path)
            return True
        else:
            os.remove(tmp)
            return False
    except (urllib.error.URLError, OSError):
        try:
            os.remove(tmp)
        except OSError:
            pass
        return False


# ─── Gamelist XML helpers ─────────────────────────────────────────────────────

def load_gamelist(gamelist_path):
    """Load or create a gamelist.xml. Returns (tree, root)."""
    if os.path.exists(gamelist_path):
        try:
            tree = ET.parse(gamelist_path)
            return tree, tree.getroot()
        except ET.ParseError:
            pass
    root = ET.Element("gameList")
    tree = ET.ElementTree(root)
    return tree, root


def game_in_gamelist(root, rom_filename):
    """Check if a ROM already has a gamelist entry."""
    rel_path = f"./{rom_filename}"
    for game in root.findall("game"):
        path_el = game.find("path")
        if path_el is not None and path_el.text == rel_path:
            return True
    return False


def find_game_element(root, rom_filename):
    """Find and return the existing <game> element for a ROM, or None."""
    rel_path = f"./{rom_filename}"
    for game in root.findall("game"):
        path_el = game.find("path")
        if path_el is not None and path_el.text == rel_path:
            return game
    return None


def game_has_media(root, rom_filename, system_dir):
    """Check if a ROM's gamelist entry has actual media files on disk.
    Returns True only if thumbnail, fanart, marquee (wheel), and video all exist."""
    stem = os.path.splitext(rom_filename)[0]
    thumb = Path(system_dir) / "images" / f"{stem}-thumb.png"
    image = Path(system_dir) / "images" / f"{stem}-image.png"
    marquee = Path(system_dir) / "images" / f"{stem}-marquee.png"
    video = Path(system_dir) / "videos" / f"{stem}-video.mp4"
    return (thumb.exists() and thumb.stat().st_size > 100
            and image.exists() and image.stat().st_size > 100
            and marquee.exists() and marquee.stat().st_size > 100
            and video.exists() and video.stat().st_size > 1000)


def add_game_to_gamelist(root, rom_filename, metadata, media_paths):
    """Add a new <game> entry to the gamelist root element."""
    game = ET.SubElement(root, "game")

    ET.SubElement(game, "path").text = f"./{rom_filename}"

    if metadata.get("name"):
        ET.SubElement(game, "name").text = metadata["name"]
    if metadata.get("desc"):
        ET.SubElement(game, "desc").text = metadata["desc"]
    if metadata.get("rating"):
        # ScreenScraper rating is 0-20, ES expects 0.0-1.0
        try:
            r = float(metadata["rating"]) / 20.0
            ET.SubElement(game, "rating").text = f"{r:.1f}"
        except (ValueError, TypeError):
            pass
    if metadata.get("releasedate"):
        ET.SubElement(game, "releasedate").text = metadata["releasedate"]
    if metadata.get("developer"):
        ET.SubElement(game, "developer").text = metadata["developer"]
    if metadata.get("publisher"):
        ET.SubElement(game, "publisher").text = metadata["publisher"]
    if metadata.get("genre"):
        ET.SubElement(game, "genre").text = metadata["genre"]
    if metadata.get("players"):
        ET.SubElement(game, "players").text = metadata["players"]

    # Media paths (relative to system dir)
    for xml_tag, rel_path in media_paths.items():
        ET.SubElement(game, xml_tag).text = rel_path


def save_gamelist(tree, gamelist_path):
    """Write gamelist.xml with pretty formatting."""
    ET.indent(tree, space="\t")
    # Write XML declaration manually for compatibility
    tmp = gamelist_path + ".tmp"
    with open(tmp, "wb") as f:
        f.write(b'<?xml version="1.0"?>\n')
        tree.write(f, encoding="unicode" if False else "utf-8", xml_declaration=False)
    os.rename(tmp, gamelist_path)


# ─── Main scrape logic ───────────────────────────────────────────────────────

def scrape_system(system_dir, system_id):
    """Scrape media for all ROMs in a system directory that lack gamelist entries."""
    system_dir = Path(system_dir)
    if not system_dir.is_dir():
        log(f"Directory not found: {system_dir}")
        return

    gamelist_path = system_dir / "gamelist.xml"
    tree, root = load_gamelist(str(gamelist_path))

    # ── One-time migration: rename old screenshots to free -image slot for fanart ──
    images_dir = system_dir / "images"
    if images_dir.is_dir():
        migrated = 0
        for img in images_dir.iterdir():
            if img.name.endswith("-image.png"):
                screenshot_name = img.name.replace("-image.png", "-screenshot.png")
                screenshot_path = images_dir / screenshot_name
                if not screenshot_path.exists():
                    img.rename(screenshot_path)
                    migrated += 1
        if migrated:
            log(f"Migrated {migrated} screenshot(s) from -image to -screenshot in {system_dir.name}/")

    # Get credentials
    ss_user, ss_pass = get_ss_credentials()
    if not ss_user or not ss_pass:
        log("No ScreenScraper credentials found in ES settings — cannot scrape")
        return

    # Find ROMs that need scraping: no gamelist entry OR gamelist entry but
    # missing actual media files (e.g. bare entries with only name/path)
    roms_to_scrape = []
    for f in sorted(system_dir.iterdir()):
        if f.is_file() and f.suffix.lower() in ROM_EXTENSIONS:
            if not game_in_gamelist(root, f.name):
                roms_to_scrape.append(f)
            elif not game_has_media(root, f.name, system_dir):
                roms_to_scrape.append(f)

    if not roms_to_scrape:
        log(f"All ROMs in {system_dir.name}/ already have gamelist entries")
        return

    log(f"Scraping media for {len(roms_to_scrape)} ROMs in {system_dir.name}/...")

    # Create media directories
    images_dir = system_dir / "images"
    videos_dir = system_dir / "videos"
    images_dir.mkdir(exist_ok=True)
    videos_dir.mkdir(exist_ok=True)

    scraped = 0
    failed = 0

    for rom_path in roms_to_scrape:
        rom_name = rom_path.name
        game_id = rom_path.stem

        # API request
        game_info = ss_game_info(rom_name, system_id, ss_user, ss_pass)
        if not game_info:
            log(f"  skip {rom_name} (not found)")
            failed += 1
            _wait_if_busy(); time.sleep(REQUEST_DELAY)
            continue

        # Extract metadata
        medias = game_info.get("medias", [])
        metadata = {
            "name": pick_text(game_info.get("noms", []), lang="en"),
            "desc": pick_text(game_info.get("synopsis", []), lang="en"),
            "rating": game_info.get("note", {}).get("text", ""),
            "developer": game_info.get("developpeur", {}).get("text", ""),
            "publisher": game_info.get("editeur", {}).get("text", ""),
            "genre": pick_genre(game_info.get("genres", [])),
            "players": game_info.get("joueurs", {}).get("text", ""),
        }

        # Release date
        for d in game_info.get("dates", []):
            if d.get("region") in ("us", "wor", "eu", "jp"):
                raw = d.get("text", "")
                # Convert YYYY-MM-DD or YYYY to ES format YYYYMMDDTHHMMSS
                clean = raw.replace("-", "")
                if len(clean) == 4:
                    clean += "0101"
                elif len(clean) == 6:
                    clean += "01"
                metadata["releasedate"] = clean + "T000000"
                break

        # Download media files
        media_xml_paths = {}
        for ss_type, info in MEDIA_MAP.items():
            url = pick_media_url(medias, ss_type)
            if not url:
                continue

            subdir = system_dir / info["subdir"]
            subdir.mkdir(exist_ok=True)
            dest = subdir / f"{game_id}{info['suffix']}{info['ext']}"

            if dest.exists() and dest.stat().st_size > 100:
                # Already downloaded (maybe from a previous partial run)
                if info["xml_tag"]:
                    media_xml_paths[info["xml_tag"]] = f"./{info['subdir']}/{dest.name}"
                continue

            if download_file(url, str(dest)):
                if info["xml_tag"]:
                    media_xml_paths[info["xml_tag"]] = f"./{info['subdir']}/{dest.name}"
            else:
                log(f"  failed to download {ss_type} for {game_id}")

            _wait_if_busy(); time.sleep(0.5)  # brief pause between media downloads

        # Add or update gamelist entry
        existing = find_game_element(root, rom_name)
        if existing is not None:
            # Update existing bare entry with metadata and media paths
            for key, xml_tag in [("name", "name"), ("desc", "desc"),
                                  ("developer", "developer"), ("publisher", "publisher"),
                                  ("genre", "genre"), ("players", "players")]:
                if metadata.get(key) and existing.find(xml_tag) is None:
                    ET.SubElement(existing, xml_tag).text = metadata[key]
            if metadata.get("releasedate") and existing.find("releasedate") is None:
                ET.SubElement(existing, "releasedate").text = metadata["releasedate"]
            if metadata.get("rating") and existing.find("rating") is None:
                try:
                    r = float(metadata["rating"]) / 20.0
                    ET.SubElement(existing, "rating").text = f"{r:.1f}"
                except (ValueError, TypeError):
                    pass
            for xml_tag, rel_path in media_xml_paths.items():
                el = existing.find(xml_tag)
                if el is None:
                    ET.SubElement(existing, xml_tag).text = rel_path
                else:
                    el.text = rel_path
        else:
            add_game_to_gamelist(root, rom_name, metadata, media_xml_paths)
        scraped += 1
        log(f"  scraped {game_id} ({scraped}/{len(roms_to_scrape)})")

        # Save gamelist after each game (incremental — crash-safe)
        save_gamelist(tree, str(gamelist_path))

        # Throttle between games
        time.sleep(REQUEST_DELAY)

    log(f"Scrape complete: {scraped} scraped, {failed} not found "
        f"(total {len(roms_to_scrape)})")


# ─── Entry point ──────────────────────────────────────────────────────────────

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(f"Usage: {sys.argv[0]} <system_dir> [--system-id <id>]")
        sys.exit(1)

    system_dir = sys.argv[1]

    # Auto-detect system ID from directory name; fall back to arcade (75)
    dir_name = os.path.basename(os.path.normpath(system_dir))
    system_id = SS_SYSTEM_IDS.get(dir_name, DEFAULT_SYSTEM_ID)

    if "--system-id" in sys.argv:
        idx = sys.argv.index("--system-id")
        if idx + 1 < len(sys.argv):
            try:
                system_id = int(sys.argv[idx + 1])
            except ValueError:
                print(f"Invalid system ID: {sys.argv[idx + 1]}")
                sys.exit(1)

    if not acquire_lock():
        sys.exit(0)

    try:
        scrape_system(system_dir, system_id)
    finally:
        release_lock()
