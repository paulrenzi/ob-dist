#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BASE_URL="${BASE_URL:-http://127.0.0.1:8765}"
KEEP_RUNNING="${KEEP_RUNNING:-0}"

cleanup() {
    if [ "$KEEP_RUNNING" != "1" ]; then
        docker compose -f "$ROOT_DIR/docker-compose.yml" down >/dev/null
    fi
}

dump_logs() {
    docker compose -f "$ROOT_DIR/docker-compose.yml" logs --no-color --tail=200 || true
}

trap cleanup EXIT
trap dump_logs ERR

docker compose -f "$ROOT_DIR/docker-compose.yml" up -d --build
"$ROOT_DIR/scripts/smoke-api.sh" "$BASE_URL"
