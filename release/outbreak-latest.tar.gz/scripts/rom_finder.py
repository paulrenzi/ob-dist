#!/usr/bin/env python3
"""
rom_finder.py
─────────────
Fuzzy ROM library search for Batocera NetPlay Arcade.

Given a remote game title (e.g. "Super Mario Kart (USA)"), finds the best
matching local ROM file across all installed systems and returns the full
path + detected system + recommended netplay core.

Two data sources, tried in order of reliability:

  1. gamelist.xml  — EmulationStation's scrape DB, lives at
                     /userdata/roms/<system>/gamelist.xml
                     Contains <name> (clean title) and <path> (ROM path).
                     Most reliable because it has human-readable names.

  2. Raw filesystem — /userdata/roms/<system>/*.{zip,nes,sfc,…}
                     Used when gamelist.xml is absent or the game was
                     never scraped. Filename is the match target.

Matching strategy:
  - Normalise both strings (strip region/revision tags, lowercase,
    collapse whitespace, remove punctuation).
  - Score with three tiers:
      1. Exact normalised match       → score 100
      2. All query words present      → score 80 + word coverage %
      3. Longest common subsequence   → score proportional to LCS length
  - Return the highest-scoring candidate above MIN_SCORE (default 55).

Usage as a module:
    from rom_finder import RomFinder
    rf = RomFinder()
    result = rf.find("Super Mario Kart (USA)")
    # → {"path": "/userdata/roms/snes/Super Mario Kart (USA).zip",
    #    "system": "snes", "score": 100, "core": "snes9x",
    #    "name": "Super Mario Kart"}

Usage from CLI:
    python3 rom_finder.py "Super Mario Kart (USA)"
"""

import json
import os
import re
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Optional

ROMS_BASE      = "/userdata/roms"
CORE_DB_PATH   = "/userdata/system/netplay-arcade/core_compat.json"
ROM_INDEX_PATH = "/userdata/system/netplay-arcade/rom_index.json"
MIN_SCORE      = 55   # below this we report no match rather than a wrong ROM

# Systems Batocera stores under /userdata/roms/<system>
# Only systems that have netplay-compatible cores are included.
NETPLAY_SYSTEMS = [
    "nes", "snes", "megadrive", "genesis", "gba", "gb", "gbc",
    "arcade", "neogeo", "mame", "fbneo",
    "atari2600", "mastersystem", "sega32x", "segacd", "32x",
    "gamegear", "turbografx16", "pcengine", "nds",
]

ROM_EXTENSIONS = {
    ".zip", ".7z",
    ".nes", ".unf",
    ".sfc", ".smc", ".fig",
    ".md", ".gen", ".smd",
    ".gba",
    ".gb", ".gbc",
    ".chd",
    ".pce",
    ".sms", ".gg",
    ".a26",
    ".rom", ".neo",
    ".iso",
}

# ── Normalisation ──────────────────────────────────────────────────────────────

_REGION_TAG = re.compile(
    r'\s*\('
    r'(?:USA|Europe|Japan|World|En|JPN|EUR|US|Eu|JP|'
    r'Rev\s*\w+|v\d[\d.]*|Proto|Beta|Demo|Sample|'
    r'Unl|NL|DE|FR|IT|ES|PT|RU|KO|ZH|'
    r'[A-Z]{2,3}(?:,\s*[A-Z]{2,3})*)'
    r'\)'
    , re.IGNORECASE
)
_DISC_TAG   = re.compile(r'\s*\(Disc\s*\d+\)', re.IGNORECASE)
_PUNCT      = re.compile(r"[^\w\s]")
_WHITESPACE = re.compile(r"\s+")


def normalise(title: str) -> str:
    """Strip region/disc tags, punctuation, collapse whitespace, lowercase."""
    t = _REGION_TAG.sub("", title)
    t = _DISC_TAG.sub("", t)
    # Also strip file extension
    t = re.sub(r'\.\w{1,5}$', '', t)
    t = _PUNCT.sub(" ", t)
    t = _WHITESPACE.sub(" ", t).strip().lower()
    return t


# ── Scoring ────────────────────────────────────────────────────────────────────

def _lcs_length(a: str, b: str) -> int:
    """Length of the longest common subsequence of words."""
    wa, wb = a.split(), b.split()
    if not wa or not wb:
        return 0
    m, n = len(wa), len(wb)
    # Space-efficient DP
    prev = [0] * (n + 1)
    for i in range(1, m + 1):
        curr = [0] * (n + 1)
        for j in range(1, n + 1):
            if wa[i - 1] == wb[j - 1]:
                curr[j] = prev[j - 1] + 1
            else:
                curr[j] = max(curr[j - 1], prev[j])
        prev = curr
    return prev[n]


def score_match(query_norm: str, candidate_norm: str) -> int:
    """Return 0–100 similarity score between two normalised titles."""
    if not query_norm or not candidate_norm:
        return 0

    # Tier 1: exact
    if query_norm == candidate_norm:
        return 100

    # Tier 2: one is a prefix/suffix of the other (handles "The Legend of Zelda"
    # matching "Legend of Zelda, The")
    if candidate_norm.startswith(query_norm) or query_norm.startswith(candidate_norm):
        return 90

    # Tier 3: all query words appear in candidate
    qwords = set(query_norm.split())
    cwords = set(candidate_norm.split())
    if qwords and qwords.issubset(cwords):
        # Score by coverage: how much of the candidate is accounted for
        coverage = len(qwords) / max(len(cwords), 1)
        return int(80 + 10 * coverage)

    # Tier 4: LCS word overlap
    lcs = _lcs_length(query_norm, candidate_norm)
    total = max(len(query_norm.split()), len(candidate_norm.split()))
    if total == 0:
        return 0
    return int(70 * lcs / total)


# ── Core DB lookup ─────────────────────────────────────────────────────────────

_core_db_cache: Optional[dict] = None

def _load_core_db() -> dict:
    global _core_db_cache
    if _core_db_cache is not None:
        return _core_db_cache
    try:
        with open(CORE_DB_PATH) as f:
            _core_db_cache = json.load(f)
    except Exception:
        _core_db_cache = {}
    return _core_db_cache


def recommended_core(system: str) -> str:
    """Return the recommended netplay core for a Batocera system name."""
    db = _load_core_db()
    # Normalise common aliases
    aliases = {
        "genesis": "megadrive",
        "fbneo":   "arcade",
    }
    key = aliases.get(system, system)
    entry = db.get(key, {})
    return entry.get("recommended", "")


# ── ROM Index ──────────────────────────────────────────────────────────────────

class RomFinder:
    """
    Lazy-loads the ROM index on first search.
    Call invalidate() to force a re-scan (e.g. after a download completes).
    """

    def __init__(self, roms_base: str = ROMS_BASE):
        self._roms_base = roms_base
        self._index: list = []    # list of {"name_norm", "name", "path", "system"}
        self._loaded = False

    def invalidate(self):
        self._index = []
        self._loaded = False

    def _load(self):
        if self._loaded:
            return
        self._index = []

        # Source 0: persistent ROM index written by boot_scan — exact stem matches,
        # handles nested paths (e.g. mame/roms/avsp.zip) that filesystem scan misses.
        index_path = Path(ROM_INDEX_PATH)
        if index_path.exists():
            try:
                with open(index_path) as f:
                    idx_data = json.load(f)
                for stem, info in idx_data.get("roms", {}).items():
                    self._index.append({
                        "name":          stem,
                        "name_norm":     stem.lower(),
                        "path":          info["path"],
                        "system":        info["system"],
                        "source":        "index",
                        "core_override": info.get("core", ""),
                    })
            except Exception:
                pass

        base = Path(self._roms_base)
        if not base.is_dir():
            self._loaded = True
            return

        for system_dir in base.iterdir():
            if not system_dir.is_dir():
                continue
            system = system_dir.name
            if system.startswith("."):
                continue

            # Source 1: gamelist.xml (preferred — clean names)
            gamelist = system_dir / "gamelist.xml"
            if gamelist.exists():
                self._index_gamelist(gamelist, system, system_dir)
            else:
                # Source 2: raw filesystem
                self._index_directory(system_dir, system)

        self._loaded = True

    def _index_gamelist(self, gamelist_path: Path, system: str, system_dir: Path):
        """
        Parse EmulationStation gamelist.xml.
        Schema: <gameList><game><name>…</name><path>./rom.zip</path></game></gameList>
        <path> is relative to the gamelist's directory.
        """
        try:
            tree = ET.parse(str(gamelist_path))
        except ET.ParseError:
            # Fall back to directory scan on corrupt XML
            self._index_directory(system_dir, system)
            return

        root = tree.getroot()
        # Batocera uses <gameList> or <GameList>
        games = root.findall("game") or root.findall("Game")

        for game in games:
            name_el = game.find("name") if game.find("name") is not None else game.find("Name")
            path_el = game.find("path") if game.find("path") is not None else game.find("Path")
            if name_el is None or path_el is None:
                continue

            name = (name_el.text or "").strip()
            rel  = (path_el.text or "").strip()
            if not name or not rel:
                continue

            # Resolve relative paths (e.g. "./Super Mario Kart (USA).zip")
            if rel.startswith("./") or rel.startswith(".\\"):
                rel = rel[2:]
            rom_path = rel if os.path.isabs(rel) else str(system_dir / rel)

            self._index.append({
                "name":      name,
                "name_norm": normalise(name),
                "path":      rom_path,
                "system":    system,
                "source":    "gamelist",
            })

    def _index_directory(self, system_dir: Path, system: str):
        """Scan raw directory for ROM files, using filename as title."""
        try:
            entries = list(system_dir.iterdir())
        except PermissionError:
            return

        for entry in entries:
            if entry.is_dir() or entry.suffix.lower() not in ROM_EXTENSIONS:
                continue
            name = entry.stem   # filename without extension
            self._index.append({
                "name":      name,
                "name_norm": normalise(name),
                "path":      str(entry),
                "system":    system,
                "source":    "filesystem",
            })

    def find(self, query: str, system_hint: str = "") -> Optional[dict]:
        """
        Find best local ROM match for the given title string.

        Parameters
        ----------
        query       Remote game title (e.g. "Super Mario Kart (USA)")
        system_hint Optional Batocera system name to search first.
                    If provided and a good match is found there (score≥80),
                    we return immediately without searching other systems.

        Returns
        -------
        dict with keys: path, system, score, core, name, name_norm
        or None if no match above MIN_SCORE.
        """
        self._load()

        if not self._index:
            return None

        query_norm = normalise(query)
        if not query_norm:
            return None

        best_score  = 0
        best_entry  = None

        # Score every entry
        for entry in self._index:
            s = score_match(query_norm, entry["name_norm"])
            if s > best_score:
                best_score = s
                best_entry = entry
            if s == 100:
                break   # can't do better

        if best_score < MIN_SCORE or best_entry is None:
            return None

        # Verify the ROM file actually exists on disk
        if not os.path.exists(best_entry["path"]):
            return None

        core = best_entry.get("core_override") or recommended_core(best_entry["system"])

        return {
            "path":      best_entry["path"],
            "system":    best_entry["system"],
            "score":     best_score,
            "core":      core,
            "name":      best_entry["name"],
            "name_norm": best_entry["name_norm"],
            "source":    best_entry.get("source", "unknown"),
        }

    def find_candidates(self, query: str, limit: int = 5) -> list:
        """Return top N matches above MIN_SCORE (useful for disambiguation UI)."""
        self._load()
        query_norm = normalise(query)
        scored = []
        seen_paths = set()

        for entry in self._index:
            s = score_match(query_norm, entry["name_norm"])
            if s >= MIN_SCORE and entry["path"] not in seen_paths:
                seen_paths.add(entry["path"])
                core = entry.get("core_override") or recommended_core(entry["system"])
                scored.append({**entry, "score": s, "core": core})

        scored.sort(key=lambda x: x["score"], reverse=True)
        return scored[:limit]


# ── Module-level singleton (imported by netplay-server.py) ────────────────────
_finder = RomFinder()

def find_rom(query: str, system_hint: str = "") -> Optional[dict]:
    return _finder.find(query, system_hint)

def find_rom_candidates(query: str, limit: int = 5) -> list:
    return _finder.find_candidates(query, limit)

def invalidate_rom_index():
    _finder.invalidate()


# ── CLI ───────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage: rom_finder.py <game title> [system_hint]")
        sys.exit(1)

    query  = sys.argv[1]
    hint   = sys.argv[2] if len(sys.argv) > 2 else ""

    result = find_rom(query, hint)
    if result:
        print(json.dumps(result, indent=2))
    else:
        candidates = find_rom_candidates(query)
        if candidates:
            print(json.dumps({"no_exact_match": True,
                              "candidates": candidates}, indent=2))
        else:
            print(json.dumps({"error": f"No ROM found for: {query}"}))
        sys.exit(1)
