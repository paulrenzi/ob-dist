#!/bin/bash
# =============================================================================
# Batocera NetPlay Broadcast - One-Button Broadcast & Join  (v1.3)
# =============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEFAULT_INSTALL_DIR="/userdata/system/netplay-arcade"
LOCAL_INSTALL_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
INSTALL_DIR="$DEFAULT_INSTALL_DIR"
[ -d "$DEFAULT_INSTALL_DIR" ] || [ -w /userdata/system ] || INSTALL_DIR="$LOCAL_INSTALL_DIR"
CONFIG_FILE="$INSTALL_DIR/config.cfg"
LOG_FILE="/tmp/netplay-arcade.log"
SESSION_FILE="/tmp/netplay_session.json"
PING_CACHE="/tmp/ping_cache.json"
HISTORY_FILE="$INSTALL_DIR/session_history.json"
CORES_SCRIPT="$DEFAULT_INSTALL_DIR/scripts/netplay-cores.sh"
CORE_CHECKER="$DEFAULT_INSTALL_DIR/scripts/core-checker.sh"
ROM_CHECKER_SCRIPT="$DEFAULT_INSTALL_DIR/scripts/rom-checker.sh"
CONFIG_HELPERS="$SCRIPT_DIR/config-parser.sh"
[ -f "$CORES_SCRIPT" ] || CORES_SCRIPT="$SCRIPT_DIR/netplay-cores.sh"
[ -f "$CORE_CHECKER" ] || CORE_CHECKER="$SCRIPT_DIR/core-checker.sh"
[ -f "$ROM_CHECKER_SCRIPT" ] || ROM_CHECKER_SCRIPT="$SCRIPT_DIR/rom-checker.sh"

# ─── RETROARCH LOCKFILE (Task 3) ──────────────────────────────────────────────
LOCK=/tmp/outbreak-retroarch.lock

cleanup_lock() {
    rm -f "$LOCK"
}
trap cleanup_lock EXIT SIGTERM SIGINT

# Allow stop/ping/notify to bypass the lock guard — only broadcast and join need it
case "${1:-}" in
    stop|ping|notify) ;;  # bypass lockfile check
    *)
        if [[ -f "$LOCK" ]] && kill -0 "$(cat "$LOCK")" 2>/dev/null; then
            echo "Another session is already running -- stop it before starting a new one"
            exit 1
        fi
        echo $$ > "$LOCK"
        ;;
esac

# ─── SESSION HISTORY ──────────────────────────────────────────────────────────
append_session_history() {
    local role="$1"
    local with_user="$2"
    [ ! -f "$SESSION_FILE" ] && return

    python3 - "$SESSION_FILE" "$HISTORY_FILE" "$role" "$with_user" <<'PYEOF'
import json, os, sys, time
session_file, history_file, role, with_user = sys.argv[1:5]
try:
    with open(session_file) as f:
        sess = json.load(f)
except Exception:
    sys.exit(0)
started_at = int(sess.get("timestamp", 0))
ended_at   = int(time.time())
record = {
    "game":         sess.get("game", ""),
    "core":         sess.get("core", ""),
    "core_version": sess.get("core_version", ""),
    "core_channel": sess.get("core_channel", ""),
    "rom":          sess.get("rom",  ""),
    "role":         role,
    "with_user":    with_user,
    "host_ip":      sess.get("host", ""),
    "started_at":   started_at,
    "ended_at":     ended_at,
    "duration_s":   max(0, ended_at - started_at),
}
history = []
if os.path.exists(history_file):
    try:
        with open(history_file) as f:
            history = json.load(f)
        if not isinstance(history, list):
            history = []
    except Exception:
        history = []
history.append(record)
os.makedirs(os.path.dirname(history_file), exist_ok=True)
import tempfile
dir_ = os.path.dirname(history_file)
fd, tmp = tempfile.mkstemp(dir=dir_, suffix=".tmp")
try:
    with os.fdopen(fd, "w") as f:
        json.dump(history, f, indent=2)
    os.replace(tmp, history_file)
except Exception:
    try: os.unlink(tmp)
    except OSError: pass
    raise
print(f"[HIST] Saved: {record['game']} ({record['duration_s']}s as {role})")
PYEOF
}

# ─── LOAD CONFIG ─────────────────────────────────────────────────────────────
if [ -f "$CONFIG_HELPERS" ]; then
    # shellcheck source=/dev/null
    . "$CONFIG_HELPERS"
    load_netplay_config "$CONFIG_FILE"
else
    DISCORD_WEBHOOK=""
    USERNAME=$(hostname)
    MAX_PING=40
    RETROARCH_BIN="/usr/bin/retroarch"
fi

log() { echo "[$(date '+%H:%M:%S')] $1" | tee -a "$LOG_FILE"; }

# ─── PING UTILITY ────────────────────────────────────────────────────────────
get_ping() {
    local host="$1"
    ping -c 1 -W 2 "$host" 2>/dev/null | tail -1 | awk -F'/' '{print int($5)}' || echo "999"
}

detect_rom_meta() {
    local rom_path="$1"
    local meta_json detected_system detected_core

    DETECTED_ROM_SYSTEM=""
    DETECTED_ROM_CORE=""
    [ -f "$CORE_CHECKER" ] || return 0

    meta_json=$(bash "$CORE_CHECKER" check-fix "$rom_path" 2>/dev/null)
    [ -n "$meta_json" ] || return 0

    detected_system=$(echo "$meta_json" | python3 -c "import json,sys; print(json.load(sys.stdin).get('system',''))" 2>/dev/null)
    detected_core=$(echo "$meta_json" | python3 -c "import json,sys; print(json.load(sys.stdin).get('core',''))" 2>/dev/null)

    DETECTED_ROM_SYSTEM="$detected_system"
    DETECTED_ROM_CORE="$detected_core"
}

# ─── RESOLVE CORE: pinned path + version fingerprint ─────────────────────────
# Sets caller-scope vars: RESOLVED_CORE_SO  _MD5  _CHANNEL  _VER
resolve_core() {
    local core="$1"
    RESOLVED_CORE_SO=""
    RESOLVED_CORE_MD5=""
    RESOLVED_CORE_CHANNEL=""
    RESOLVED_CORE_VER=""

    if [ -f "$CORES_SCRIPT" ]; then
        local ver_json
        ver_json=$(bash "$CORES_SCRIPT" version "$core" 2>/dev/null)
        if [ -n "$ver_json" ]; then
            RESOLVED_CORE_SO=$(      echo "$ver_json" | python3 -c "import json,sys; print(json.load(sys.stdin).get('so_path',''))"        2>/dev/null)
            RESOLVED_CORE_MD5=$(     echo "$ver_json" | python3 -c "import json,sys; print(json.load(sys.stdin).get('md5',''))"             2>/dev/null)
            RESOLVED_CORE_CHANNEL=$( echo "$ver_json" | python3 -c "import json,sys; print(json.load(sys.stdin).get('channel',''))"         2>/dev/null)
            RESOLVED_CORE_VER=$(     echo "$ver_json" | python3 -c "import json,sys; print(json.load(sys.stdin).get('display_version',''))" 2>/dev/null)
        fi
    fi

    # Fallback to system core directory if channel lookup failed.
    # Try both the literal core name and an underscore-normalised variant —
    # Batocera stores mupen64plus_next_libretro.so (underscore) but the
    # internal core name uses a hyphen (mupen64plus-next).
    if [ -z "$RESOLVED_CORE_SO" ] || [ ! -f "$RESOLVED_CORE_SO" ]; then
        local fallback="/usr/lib/libretro/${core}_libretro.so"
        local fallback_us="/usr/lib/libretro/${core//-/_}_libretro.so"
        if [ ! -f "$fallback" ] && [ -f "$fallback_us" ]; then
            fallback="$fallback_us"
        elif [ ! -f "$fallback" ]; then
            fallback="/usr/lib/libretro/${core}.so"
        fi
        RESOLVED_CORE_SO="$fallback"
        RESOLVED_CORE_MD5=$(md5sum "$RESOLVED_CORE_SO" 2>/dev/null | cut -d' ' -f1)
        RESOLVED_CORE_CHANNEL="system"
        RESOLVED_CORE_VER=""
    fi
}

# ─── AUTO-DETECT NETPLAY CORE FROM ROM ───────────────────────────────────────
# Called when core=auto or core is empty. Uses core-checker.sh to detect the
# system from the ROM path/extension, then picks the recommended netplay core.
auto_detect_core() {
    local rom_path="$1"
    local CHECKER="$CORE_CHECKER"

    local system core
    [ -f "$CHECKER" ] || { echo ""; return; }
    system=$(bash "$CHECKER" detect "$rom_path" 2>/dev/null)
    if [ -z "$system" ] || [ "$system" = "unknown" ]; then
        log "Auto-core: could not detect system for $rom_path — falling back to fceumm"
        echo "fceumm"
        return
    fi

    core=$(bash "$CHECKER" recommended "$system" 2>/dev/null)
    if [ -z "$core" ]; then
        log "Auto-core: no recommended core for system '$system'"
        echo ""
        return
    fi

    log "Auto-core: $rom_path → system=$system → core=$core"
    echo "$core"
}


send_discord() {
    local action="$1" game="$2" core="$3" host_ip="$4" ping_ms="$5"
    [ -z "$DISCORD_WEBHOOK" ] && return 1

    local color timestamp title description
    timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
    case "$action" in
        broadcast) color=3066993; title="📡 NetPlay Session Starting!";  description="**$USERNAME** is hosting!\n\n🎮 **Game:** $game\n⚙️ **Core:** $core\n🌐 **Host:** $host_ip" ;;
        join)      color=3447003; title="🕹️ Player Joined!";             description="**$USERNAME** joined **$game**\n⚡ Ping: **${ping_ms}ms**" ;;
        stop)      color=15158332; title="🛑 Session Ended";             description="**$USERNAME**'s session of **$game** has ended." ;;
    esac

    curl -s -H "Content-Type: application/json" -d \
        "{\"username\":\"Arcade NetPlay\",\"embeds\":[{\"title\":\"$title\",\"description\":\"$description\",\"color\":$color,\"timestamp\":\"$timestamp\"}]}" \
        "$DISCORD_WEBHOOK" >> "$LOG_FILE" 2>&1
}

# ─── ARCADE SCREEN NOTIFICATION ──────────────────────────────────────────────
show_arcade_notification() {
    local type="$1" message="$2" duration="${3:-5}"
    echo "{\"type\":\"$type\",\"message\":\"$message\",\"duration\":$duration}" > /tmp/netplay_notification.json
    command -v batocera-es-swissknife &>/dev/null && batocera-es-swissknife --notification "$message" 2>/dev/null
    [ -S /tmp/es.sock ] && printf '<?xml version="1.0"?>\n<notification><message>%s</message></notification>\n' "$message" | nc -U /tmp/es.sock 2>/dev/null
    log "Notification: [$type] $message"
}

# ─── LOCAL GAMEPAD DETECTION ──────────────────────────────────────────────────
# Count /dev/input/js* devices present at launch time. Used to set max_users in
# the host appendconfig so RetroArch reserves those ports for local players and
# assigns joining remote clients to ports (local_players+1), (local_players+2)…
#
# Config override: if "local_players=N" (N 1-4) is set in config.cfg, that value
# is used directly. This handles Bluetooth/wireless controllers that pair AFTER
# the script runs and would otherwise be missed by the /dev/input/js* count.
# Example config.cfg line:  local_players=2
detect_local_players() {
    local cfg_val
    cfg_val=$(grep -m1 '^local_players=' "$CONFIG_FILE" 2>/dev/null | cut -d= -f2 | tr -d '"')
    if [[ "$cfg_val" =~ ^[1-4]$ ]]; then
        log "Local players from config override: $cfg_val"
        echo "$cfg_val"
        return
    fi
    local count
    count=$(ls /dev/input/js* 2>/dev/null | wc -l)
    (( count < 1 )) && count=1
    (( count > 4 )) && count=4
    echo "$count"
}

# ─── FIGHTER MODE — ROLLBACK NETPLAY DETECTION ───────────────────────────────
# Rollback (delay_frames=0) uses RetroArch's rewind buffer as the rollback
# buffer. It eliminates input delay for fighters/shooters but requires spare
# CPU cycles and a low-ping link. Two conditions must both be met:
#   1. The core supports savestates and is lightweight enough for rollback.
#      Heavy cores (N64) are excluded — their large
#      savestates and CPU load make rollback unreliable.
#   2. CPU 1-minute load average is below 75% of logical core count.
# Ping is checked separately per session at join time; the host writes
# use_rollback into the session JSON so joining clients mirror the choice.

_cpu_has_headroom() {
    local nproc load_int threshold_int
    nproc=$(nproc 2>/dev/null || echo 1)
    # Multiply load×100 so we can compare as integers without bc/awk floats
    load_int=$(awk '{printf "%d", $1 * 100}' /proc/loadavg 2>/dev/null || echo 9999)
    threshold_int=$(( nproc * 75 ))
    [ "$load_int" -lt "$threshold_int" ]
}

# Returns 0 (true) when rollback is appropriate for this host session.
# Args: core_name
_should_use_rollback() {
    local core="${1:-}"
    case "$core" in
        # Heavy cores — large savestates / high CPU, rollback unreliable
        mupen64plus*) return 1 ;;
        # Lightweight cores — rollback works well
        fbneo*|mame*) ;;                          # arcade
        flycast*) ;;                              # Dreamcast
        snes9x*|bsnes*) ;;                        # SNES
        genesis*|picodrive*) ;;                    # Genesis / Mega Drive / SMS / GG
        fceumm*|mesen*|nestopia*) ;;               # NES
        mgba*|vba*) ;;                             # GBA
        gambatte*) ;;                              # GB / GBC
        mednafen_ngp*) ;;                          # Neo Geo Pocket
        mednafen_supergrafx*) ;;                   # TurboGrafx-16 / PC Engine
        stella*) ;;                                # Atari 2600
        *) return 1 ;;
    esac
    _cpu_has_headroom || return 1
    return 0
}

# ─── NETPLAY SESSION CONFIG ───────────────────────────────────────────────────
# Writes /tmp/outbreak-session.cfg — appended to every RetroArch netplay launch.
# Enforces a consistent video/audio preset for both host and client so rendering
# differences never cause timing drift. MITM server line added for WAN hosts only.
# If core_opts_file is set, redirects core_options_path so the client uses the
# host's emulator options rather than its own (prevents emulation state divergence).
# local_players (host only): sets max_users so RetroArch assigns remote clients
# to ports above the local player slots rather than defaulting to port 2.
# Resolve the CRT shader preset path based on video driver.
# Sets RESOLVED_SHADER (global) for use with --set-shader CLI flag.
_resolve_shader() {
    RESOLVED_SHADER=""
    local _cfg_path="${_ra_cfg:-/userdata/system/configs/retroarch/retroarchcustom.cfg}"
    local _vdriver
    _vdriver=$(grep -m1 '^video_driver' "$_cfg_path" 2>/dev/null | sed 's/.*= *"\?\([^"]*\).*/\1/')
    local _ext="glslp"
    case "$_vdriver" in vulkan|glcore) _ext="slangp" ;; esac
    local _candidate
    for _candidate in \
        "/usr/share/batocera/shaders/crt/crt-easymode.${_ext}" \
        "/usr/share/batocera/shaders/crt/crt-easymode.glslp" \
        "/usr/share/batocera/shaders/crt/crt-easymode.slangp"; do
        if [ -f "$_candidate" ]; then
            RESOLVED_SHADER="$_candidate"
            return
        fi
    done
}

write_session_cfg() {
    local include_mitm="${1:-false}"
    local core_opts_file="${2:-}"
    local local_players="${3:-1}"
    local use_rollback="${4:-false}"
    {
        # Video preset — consistent timing, smooth frame pacing
        printf 'video_refresh_rate = "60.000000"\n'
        printf 'video_threaded = "false"\n'
        printf 'video_vsync = "true"\n'
        printf 'video_swap_interval = "1"\n'
        printf 'video_hard_gpu_sync = "true"\n'
        printf 'video_hard_gpu_sync_frames = "0"\n'
        printf 'video_frame_delay_auto = "false"\n'
        # CRT shader — config backup (--set-shader CLI flag is the primary mechanism)
        if [ -n "${RESOLVED_SHADER:-}" ]; then
            printf 'video_shader_enable = "true"\n'
            printf 'video_shader = "%s"\n' "$RESOLVED_SHADER"
        fi
        printf 'video_frame_delay = "0"\n'
        # Audio — sync to audio clock for smooth, consistent frame pacing
        printf 'audio_sync = "true"\n'
        # Input — late polling for consistent rollback input timing
        printf 'input_poll_type = "2"\n'
        # Ensure HK+Start exits the emulator — Batocera sets input_enable_hotkey_btn
        # in retroarchcustom.cfg but Outbreak bypasses Batocera's per-game generator,
        # so input_exit_emulator_btn is never written.  Without it the gamepad combo
        # is silently ignored (only the keyboard "escape" binding exists).
        printf 'input_exit_emulator_btn = "7"\n'
        # Unbind the rewind hotkey so accidental presses can't corrupt rollback state
        printf 'input_rewind = "nul"\n'
        printf 'input_rewind_btn = "nul"\n'
        # Runahead — must be off; one of the most common causes of instant desync
        printf 'run_ahead_enabled = "false"\n'
        printf 'run_ahead_frames = "0"\n'
        printf 'run_ahead_secondary_instance = "false"\n'
        # RetroAchievements — extra network calls and core state changes break determinism
        printf 'cheevos_enable = "false"\n'
        # Cheats — global cheat system off (core .opt mirror handles per-game options)
        printf 'cheat_enable = "false"\n'
        # Savestates — prevent auto-load/save from desyncing one side mid-session
        printf 'savestate_auto_save = "false"\n'
        printf 'savestate_auto_load = "false"\n'
        # Overlays/widgets — cleaner screen, no overlays popping during session
        printf 'overlay_enable = "false"\n'
        printf 'menu_widget_enable = "false"\n'
        # Focus — don't pause if a player alt-tabs or the display sleeps
        printf 'pause_nonfocused = "false"\n'
        # Ping display — useful feedback during WAN sessions
        printf 'netplay_ping_show = "true"\n'
        # Local player count: tells RetroArch how many input slots the host occupies
        # so remote clients are automatically assigned ports above the local slots.
        # Only written for the host (local_players > 1); clients leave it at default.
        [ "$local_players" -gt 1 ] 2>/dev/null && printf 'max_users = "%s"\n' "$local_players"
        # Disable NAT traversal — prevents the misleading "UPnP port mapping failed"
        # and "not connectable from internet" errors; MITM relay handles WAN access.
        printf 'netplay_nat_traversal = "false"\n'
        # WAN relay — both keys are required; mitm_server alone is not enough.
        if [ "$include_mitm" = "true" ]; then
            printf 'netplay_use_mitm_server = "true"\n'
            printf 'netplay_mitm_server = "nymeria"\n'
        fi
        # Core options override — client mirrors host emulator settings
        [ -n "$core_opts_file" ] && [ -f "$core_opts_file" ] && \
            printf 'core_options_path = "%s"\n' "$core_opts_file"
        # Fighter Mode — rollback netplay (delay_frames=0 + rewind buffer)
        # Enabled only when host confirms headroom; both sides must match.
        # Delay-based path explicitly disables rewind to free the buffer and RAM.
        if [ "$use_rollback" = "true" ]; then
            printf 'netplay_delay_frames = "0"\n'
            printf 'netplay_check_frames = "180"\n'
            printf 'rewind_enable = "true"\n'
            printf 'rewind_granularity = "1"\n'
        else
            printf 'rewind_enable = "false"\n'
        fi
    } > /tmp/outbreak-session.cfg
    if [ -n "${RESOLVED_SHADER:-}" ]; then
        log "Shader: --set-shader $RESOLVED_SHADER"
    else
        log "Shader: no compatible preset found — skipping"
    fi
}

# ─── BROADCAST SESSION ───────────────────────────────────────────────────────
broadcast_session() {
    local rom_path="$1"
    local core="$2"

    local game_name host_ip system_name local_players game_max_players
    game_name=$(basename "$rom_path" | sed 's/\.[^.]*$//')
    host_ip=$(timeout 2 ip route get 8.8.8.8 2>/dev/null | awk '{print $7; exit}')
    local_players=$(detect_local_players)
    detect_rom_meta "$rom_path"
    system_name="$DETECTED_ROM_SYSTEM"

    # ── Cap local_players to (game_max_players - 1) ──────────────────────────
    # Ensures at least one remote port is always available. Requires the title
    # arrays from rom-checker.sh; source it lazily if not already loaded.
    game_max_players=2
    if ! declare -p FBNEO_TITLES &>/dev/null; then
        [ -f "$ROM_CHECKER_SCRIPT" ] && source "$ROM_CHECKER_SCRIPT" 2>/dev/null
        # rom-checker.sh defines its own log() which shadows ours — restore it.
        log() { echo "[$(date '+%H:%M:%S')] $1" | tee -a "$LOG_FILE"; }
    fi
    local game_id title_entry max_local
    # Arcade: lowercased zip stem. Console: exact No-Intro name (already in game_name).
    game_id=$(basename "$rom_path" .zip | tr '[:upper:]' '[:lower:]')
    title_entry="${FBNEO_TITLES[$game_id]:-${MAME_TITLES[$game_id]:-}}"
    # Console title arrays use original-case No-Intro keys — check with game_name
    if [[ -z "$title_entry" ]]; then
        title_entry="${GENESIS_TITLES[$game_name]:-\
${SNES_TITLES[$game_name]:-\
${NES_TITLES[$game_name]:-\
${GBA_TITLES[$game_name]:-\
${GB_TITLES[$game_name]:-\
${MASTERSYSTEM_TITLES[$game_name]:-\
${GAMEGEAR_TITLES[$game_name]:-\
${NDS_TITLES[$game_name]:-\
${SEGA32X_TITLES[$game_name]:-}}}}}}}}}"
    fi
    if [[ "$title_entry" == *"|"* ]]; then
        game_max_players="${title_entry##*|}"
    fi
    max_local=$(( game_max_players - 1 ))
    (( max_local < 1 )) && max_local=1
    if (( local_players > max_local )); then
        log "Capping local_players $local_players → $max_local (game max: $game_max_players)"
        local_players=$max_local
    fi

    # Primary: use the core returned by detect_rom_meta (check-fix path)
    if [ -z "$core" ] || [ "$core" = "auto" ]; then
        core="$DETECTED_ROM_CORE"
    fi

    # Fallback: check-fix returned empty (missing DB, bad ROM path, etc.)
    # Try auto_detect_core which takes a simpler detect→recommended path.
    if [ -z "$core" ]; then
        core=$(auto_detect_core "$rom_path")
        [ -n "$core" ] && log "Core via fallback detect: $core"
    fi

    if [ -z "$core" ]; then
        show_arcade_notification "error" "❌ Unsupported game format — cannot broadcast" 6
        echo '{"error": "Could not auto-detect core", "started": false}'
        return 1
    fi

    # Resolve the pinned channel core — sets RESOLVED_CORE_* vars
    resolve_core "$core"

    # Guard: if every fallback failed, the .so path won't exist — fail early
    # rather than launching RetroArch with a nonexistent -L path.
    if [ ! -f "$RESOLVED_CORE_SO" ]; then
        log "ERROR: core .so not found for '$core' (tried: $RESOLVED_CORE_SO)"
        show_arcade_notification "error" "❌ Core not installed: $core" 6
        echo "{\"error\": \"Core not found: $core\", \"started\": false}"
        return 1
    fi

    # Fighter Mode — decide before writing session file so clients can read it
    local use_rollback=false
    if _should_use_rollback "$core"; then
        use_rollback=true
        log "⚡ Fighter Mode: rollback netplay enabled (core=$core, CPU OK)"
    fi

    log "Broadcasting: $game_name | Core: $core ${RESOLVED_CORE_VER} [ch:${RESOLVED_CORE_CHANNEL}] | IP: $host_ip | Local players: $local_players | Rollback: $use_rollback"
    log "  Core .so: $RESOLVED_CORE_SO"
    log "  Core md5: ${RESOLVED_CORE_MD5:0:12}..."

    pkill -f retroarch 2>/dev/null
    sleep 1

    # Write session file — includes full fingerprint so clients can verify
    python3 -c "
import json, sys, time
d = {
    'game':          sys.argv[1],
    'rom':           sys.argv[2],
    'core':          sys.argv[3],
    'system':        sys.argv[4],
    'core_so':       sys.argv[5],
    'core_md5':      sys.argv[6],
    'core_channel':  sys.argv[7],
    'core_version':  sys.argv[8],
    'host':          sys.argv[9],
    'port':          55435,
    'timestamp':     int(time.time()),
    'broadcaster':   sys.argv[10],
    'local_players': int(sys.argv[11]),
    'max_players':   int(sys.argv[12]),
    'use_rollback':  sys.argv[13] == 'true',
    'status':        'hosting',
    'role':          'host',
}
print(json.dumps(d, indent=2))
" "$game_name" "$rom_path" "$core" "$system_name" \
  "$RESOLVED_CORE_SO" "$RESOLVED_CORE_MD5" "$RESOLVED_CORE_CHANNEL" "$RESOLVED_CORE_VER" \
  "$host_ip" "$USERNAME" "$local_players" "$game_max_players" "$use_rollback" > "$SESSION_FILE" \
    || { log "ERROR: failed to write session file — aborting broadcast"; return 1; }

    # ── Export host core options for clients to fetch via /core-options ────────
    local ra_cfg_dir="/userdata/system/retroarch/config"
    local core_opts_src=""
    for try_path in \
        "${ra_cfg_dir}/${core}/${game_name}.opt" \
        "${ra_cfg_dir}/${core}/${core}.opt"; do
        if [ -f "$try_path" ]; then
            core_opts_src="$try_path"
            break
        fi
    done
    if [ -n "$core_opts_src" ]; then
        cp "$core_opts_src" /tmp/outbreak-core-options.opt
        log "Core options exported: $core_opts_src"
    else
        rm -f /tmp/outbreak-core-options.opt
    fi

    # ── Write session config and launch ─────────────────────────────────────
    local _ra_cfg="/userdata/system/configs/retroarch/retroarchcustom.cfg"
    _resolve_shader
    write_session_cfg "$( [ "${WAN_ENABLED:-}" = "true" ] && echo true || echo false )" "" "$local_players" "$use_rollback"
    # Use Batocera's configgen-generated config (has controller bindings) as
    # the base, then append our session overrides on top.
    local _shader_args=()
    [ -n "${RESOLVED_SHADER:-}" ] && _shader_args=(--set-shader "$RESOLVED_SHADER")
    "$RETROARCH_BIN" \
        -L "$RESOLVED_CORE_SO" \
        --config "$_ra_cfg" \
        --host --port 55435 --nick "$USERNAME" \
        --appendconfig /tmp/outbreak-session.cfg \
        "${_shader_args[@]}" \
        "$rom_path" >> "$LOG_FILE" 2>&1 &

    echo $! > /tmp/retroarch_netplay.pid
    local ra_pid
    ra_pid=$(cat /tmp/retroarch_netplay.pid)
    log "RetroArch host PID: $ra_pid"
    sleep 0.3
    if ! kill -0 "$ra_pid" 2>/dev/null; then
        log "ERROR: RetroArch exited immediately (PID $ra_pid) — check core/ROM/config"
        show_arcade_notification "error" "RetroArch failed to start -- check log" 6
        rm -f /tmp/retroarch_netplay.pid
        return 1
    fi
    send_discord "broadcast" "$game_name" "$core ${RESOLVED_CORE_VER}" "$host_ip" ""
    local mode_label="Broadcasting: $game_name | Waiting for players..."
    [ "$use_rollback" = "true" ] && mode_label="Fighter Mode: $game_name | Waiting for players..."
    show_arcade_notification "broadcast" "$mode_label" 8
}

# ─── CLEANUP: restore per-system cfg and batocera.conf after join ─────────────
_outbreak_restore_sys_cfg() {
    # Remove any symlink we placed for configgen session override injection
    for _cfg in /userdata/system/configs/retroarch/*.cfg; do
        [ -L "$_cfg" ] && [ "$(readlink "$_cfg")" = "/tmp/outbreak-session.cfg" ] && rm -f "$_cfg"
    done
    # Restore backup if one was made
    for _bak in /userdata/system/configs/retroarch/*.cfg.outbreak_bak; do
        [ -f "$_bak" ] && mv "$_bak" "${_bak%.outbreak_bak}"
    done
}
_outbreak_restore_batocera_conf() {
    local _bconf="/userdata/system/batocera.conf"
    if [ -f "${_bconf}.outbreak_bak" ]; then
        mv "${_bconf}.outbreak_bak" "$_bconf"
    fi
}

# ─── JOIN SESSION ─────────────────────────────────────────────────────────────
# Args: host_ip  rom_path  core  [remote_user]  [force=1]  [connect_ip]  [connect_port]  [core_opts_file]
join_session() {
    local host_ip="$1"
    local rom_path="$2"
    local core="$3"
    local remote_user="${4:-}"
    local force_join="${5:-0}"
    local connect_ip="${6:-$host_ip}"
    local connect_port="${7:-55435}"
    local core_opts_file="${8:-}"

    local game_name system_name
    game_name=$(basename "$rom_path" | sed 's/\.[^.]*$//')
    detect_rom_meta "$rom_path"
    system_name="$DETECTED_ROM_SYSTEM"

    # ── 1. Ping gate ────────────────────────────────────────────────────────
    local ping_ms
    ping_ms=$(get_ping "$host_ip")
    log "Ping to $host_ip: ${ping_ms}ms (max: ${MAX_PING}ms)"
    if [ "$ping_ms" -gt "$MAX_PING" ]; then
        show_arcade_notification "error" "❌ Ping too high: ${ping_ms}ms (max ${MAX_PING}ms)" 5
        return 1
    fi

    # ── 2. Fetch host session — core name + version fingerprint ────────────
    local session_json remote_core remote_md5 remote_channel remote_ver remote_rollback
    session_json=$(curl -s --max-time 3 "http://${host_ip}:8765/session" 2>/dev/null)
    if [ -n "$session_json" ]; then
        remote_core=$(     echo "$session_json" | python3 -c "import json,sys; print(json.load(sys.stdin).get('core',''))"                        2>/dev/null)
        remote_md5=$(      echo "$session_json" | python3 -c "import json,sys; print(json.load(sys.stdin).get('core_md5',''))"                    2>/dev/null)
        remote_channel=$(  echo "$session_json" | python3 -c "import json,sys; print(json.load(sys.stdin).get('core_channel',''))"                2>/dev/null)
        remote_ver=$(      echo "$session_json" | python3 -c "import json,sys; print(json.load(sys.stdin).get('core_version',''))"                2>/dev/null)
        remote_rollback=$( echo "$session_json" | python3 -c "import json,sys; print(str(json.load(sys.stdin).get('use_rollback',False)).lower())" 2>/dev/null)
    fi

    # ── 3. Core name check — auto-switch if name differs ───────────────────
    if [ -n "$remote_core" ] && [ "$remote_core" != "$core" ] && [ "$force_join" != "1" ]; then
        log "Core name mismatch: host=$remote_core local=$core — attempting auto-fix"
        show_arcade_notification "info" "⚙ Adjusting emulator settings…" 5
        local remote_system
        remote_system=$(echo "$session_json" | python3 -c "import json,sys; print(json.load(sys.stdin).get('system',''))" 2>/dev/null)
        local fix_result fixed
        fix_result=$(bash "$CORE_CHECKER" set "$remote_system" "$remote_core" 2>/dev/null)
        fixed=$(echo "$fix_result" | python3 -c "import json,sys; print(str(json.load(sys.stdin).get('success',False)).lower())" 2>/dev/null)
        if [ "$fixed" = "true" ]; then
            core="$remote_core"
            log "Auto-switched to core: $core"
            show_arcade_notification "success" "✅ Ready to join" 3
        else
            show_arcade_notification "error" "❌ Emulator mismatch — update Outbreak on both machines" 8
            echo "{\"error\": \"Emulator mismatch\", \"joined\": false}"
            return 1
        fi
    elif [ -z "$remote_core" ]; then
        log "Host unreachable — proceeding with local core $core"
    else
        log "Core name check: OK ($core)"
    fi

    # ── 4. Resolve local pinned core ────────────────────────────────────────
    resolve_core "$core"

    # ── 5. Binary hash check — warn on mismatch, never hard-block ──────────
    # If both machines downloaded from the same buildbot date (same Outbreak
    # version), hashes will always match.  A mismatch means one side used a
    # system-copy fallback (different Batocera version) or is on a different
    # Outbreak release.  We warn and give 8 s to cancel rather than blocking,
    # because minor core point-releases rarely break netplay sync in practice.
    if [ -n "$remote_md5" ] && [ "$force_join" != "1" ]; then
        if [ "$RESOLVED_CORE_MD5" != "$remote_md5" ]; then
            local _host_ver="${remote_ver:-?}" _local_ver="${RESOLVED_CORE_VER:-?}"
            log "WARN: core binary hash mismatch (host=${remote_md5:0:12} local=${RESOLVED_CORE_MD5:0:12} host_ver=$_host_ver local_ver=$_local_ver)"
            show_arcade_notification "warning" \
                "Core version may differ (host: ${_host_ver}, you: ${_local_ver}) -- desync possible. Use Stop to cancel." 6
            log "Proceeding with join despite core version mismatch"
        else
            log "Core binary hash verified: $core [${RESOLVED_CORE_MD5:0:12}…] ✓"
        fi
    elif [ -z "$remote_md5" ]; then
        log "Warning: host did not advertise core_md5 — skipping hash check"
    fi

    # ── 6. Kill existing session ────────────────────────────────────────────
    [ -f /tmp/retroarch_netplay.pid ] && { kill "$(cat /tmp/retroarch_netplay.pid)" 2>/dev/null; sleep 1; }
    pkill -f retroarch 2>/dev/null
    sleep 0.5

    # Mirror host's rollback choice; also guard with local CPU headroom
    local use_rollback=false
    if [ "$remote_rollback" = "true" ] && _cpu_has_headroom; then
        use_rollback=true
        log "⚡ Fighter Mode: rollback netplay (mirrors host)"
    fi

    local join_label="🕹️ Joining: $game_name | Ping: ${ping_ms}ms"
    [ "$use_rollback" = "true" ] && join_label="⚡ Fighter Mode: $game_name | Ping: ${ping_ms}ms"
    show_arcade_notification "join" "$join_label" 5

    # ── 7. Write session file ───────────────────────────────────────────────
    python3 -c "
import json, sys, time
d = {
    'game':         sys.argv[1],
    'rom':          sys.argv[2],
    'core':         sys.argv[3],
    'system':       sys.argv[4],
    'core_so':      sys.argv[5],
    'core_md5':     sys.argv[6],
    'core_channel': sys.argv[7],
    'core_version': sys.argv[8],
    'host':         sys.argv[9],
    'port':         55435,
    'timestamp':    int(time.time()),
    'joiner':       sys.argv[10],
    'remote_user':  sys.argv[11],
    'use_rollback': sys.argv[12] == 'true',
    'role':         'client',
    'status':       'playing',
}
print(json.dumps(d, indent=2))
" "$game_name" "$rom_path" "$core" "$system_name" \
  "$RESOLVED_CORE_SO" "$RESOLVED_CORE_MD5" "$RESOLVED_CORE_CHANNEL" "$RESOLVED_CORE_VER" \
  "$host_ip" "$USERNAME" "$remote_user" "$use_rollback" > "$SESSION_FILE" \
    || { log "ERROR: failed to write session file — aborting join"; return 1; }

    # ── 8. Launch RetroArch client ──────────────────────────────────────────
    # Batocera runs ES under X11 (startx → openbox → emulationstation).
    # Our daemon has no DISPLAY env, so RA falls back to KMS/DRM and fails.
    # Set DISPLAY=:0 so RA uses the X11/GL context that ES shares.
    local _ra_cfg="/userdata/system/configs/retroarch/retroarchcustom.cfg"
    _resolve_shader
    write_session_cfg "false" "$core_opts_file" 1 "$use_rollback"
    log "Launching: $RETROARCH_BIN -L $RESOLVED_CORE_SO --connect $connect_ip --port $connect_port"

    export DISPLAY=:0
    local _shader_args=()
    [ -n "${RESOLVED_SHADER:-}" ] && _shader_args=(--set-shader "$RESOLVED_SHADER")
    "$RETROARCH_BIN" \
        -L "$RESOLVED_CORE_SO" \
        --config "$_ra_cfg" \
        --connect "$connect_ip" --port "$connect_port" --nick "$USERNAME" \
        --appendconfig /tmp/outbreak-session.cfg \
        "${_shader_args[@]}" \
        "$rom_path" >> "$LOG_FILE" 2>&1 &

    echo $! > /tmp/retroarch_netplay.pid
    local ra_pid
    ra_pid=$(cat /tmp/retroarch_netplay.pid)
    log "RetroArch client PID: $ra_pid"
    sleep 0.5
    if ! kill -0 "$ra_pid" 2>/dev/null; then
        log "ERROR: RetroArch client exited immediately (PID $ra_pid) — check core/ROM/config"
        show_arcade_notification "error" "RetroArch failed to start -- check log" 6
        rm -f /tmp/retroarch_netplay.pid
        return 1
    fi
    send_discord "join" "$game_name" "$core" "$host_ip" "$ping_ms"
}

# ─── STOP SESSION ────────────────────────────────────────────────────────────
stop_session() {
    local game_name="" role="host" with_user=""
    if [ -f "$SESSION_FILE" ]; then
        game_name=$(python3 -c "import json; print(json.load(open('$SESSION_FILE')).get('game',''))"        2>/dev/null)
        role=$(     python3 -c "import json; print(json.load(open('$SESSION_FILE')).get('role','host'))"    2>/dev/null)
        with_user=$(python3 -c "import json; print(json.load(open('$SESSION_FILE')).get('remote_user',''))" 2>/dev/null)
    fi
    append_session_history "$role" "$with_user"
    pkill -f retroarch 2>/dev/null
    rm -f /tmp/retroarch_netplay.pid "$SESSION_FILE"
    _outbreak_restore_sys_cfg
    _outbreak_restore_batocera_conf
    [ -n "$game_name" ] && send_discord "stop" "$game_name" "" "" ""
    show_arcade_notification "success" "🛑 NetPlay session ended" 3
    log "Session stopped: $game_name"
}

# ─── MAIN DISPATCH ────────────────────────────────────────────────────────────
case "$1" in
    broadcast) broadcast_session "$2" "$3" ;;
    join)      join_session "$2" "$3" "$4" "$5" "$6" "$7" "$8" "$9" ;;
    stop)      stop_session ;;
    ping)      get_ping "$2" ;;
    notify)    show_arcade_notification "$2" "$3" "$4" ;;
    launch-and-broadcast)
        system_arg="$2"
        rom_path="$3"
        log "Launch-and-broadcast: system=$system_arg rom=$rom_path"
        # Launch via Batocera emulator launcher
        /usr/bin/emulatorlauncher -system "$system_arg" -rom "$rom_path" &
        sleep 4
        # Then broadcast using auto core detection
        broadcast_session "$rom_path" "auto"
        ;;
    *)
        echo "Usage: $0 {broadcast <rom> <core>|join <host> <rom> <core> [remote_user] [force=1]|stop|ping <host>|notify <type> <msg>|launch-and-broadcast <system> <rom>}"
        exit 1 ;;
esac
