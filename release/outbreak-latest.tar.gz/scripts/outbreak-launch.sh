#!/bin/bash
# =============================================================================
# Outbreak — ES System Launcher
# Called by EmulationStation when the user selects the Outbreak Arcade system.
# Opens the Outbreak web panel in a browser (kiosk mode) or falls back to the
# native pygame cabinet UI.
# =============================================================================

INSTALL_DIR="/userdata/system/netplay-arcade"
LOG=/tmp/outbreak-browser.log

export DISPLAY="${DISPLAY:-:0}"

echo "[$(date)] Outbreak launcher starting" >> "$LOG"

# Wait up to 10 s for the Outbreak server to be reachable
for i in $(seq 1 10); do
    curl -sf http://localhost:8765/status &>/dev/null && break
    sleep 1
done

# Browser-first: try each candidate in order
for candidate in chromium-browser chromium firefox; do
    if command -v "$candidate" &>/dev/null; then
        echo "[$(date)] Launching $candidate" >> "$LOG"
        "$candidate" --kiosk --no-sandbox "http://localhost:8765/ui" >> "$LOG" 2>&1
        echo "[$(date)] $candidate exited ($?)" >> "$LOG"
        exit 0
    fi
done

# Fallback: native pygame cabinet UI
if python3 -c "import pygame" 2>/dev/null; then
    echo "[$(date)] Launching cabinet-ui.py" >> "$LOG"
    python3 "$INSTALL_DIR/scripts/cabinet-ui.py" >> "$LOG" 2>&1
    echo "[$(date)] cabinet-ui.py exited ($?)" >> "$LOG"
    exit 0
fi

echo "[$(date)] No display method found — open http://localhost:8765/ui on another device" >> "$LOG" >&2
sleep 3
exit 1
