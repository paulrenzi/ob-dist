#!/bin/bash
# =============================================================================
# Outbreak — Netplay ES Launch
# Installed to /userdata/system/scripts/netplay-launch.sh
#
# Appears as a "User Script" in EmulationStation's game options menu.
# Checks if the selected ROM is supported for netplay, then launches
# RetroArch in broadcast mode. Shows an on-screen error if not supported.
#
# ES passes context via environment variables:
#   ES_ROM      — full ROM path   (e.g. /userdata/roms/fbneo/sf2ce.zip)
#   ES_SYSTEM   — system folder   (e.g. fbneo, snes, neogeo)
#   ES_GAMENAME — display title   (e.g. Street Fighter II)
#
# Also accepts positional args as fallback: $1=system $2=rom_path
# =============================================================================

INSTALL_DIR="/userdata/system/netplay-arcade"
BROADCAST_SCRIPT="$INSTALL_DIR/scripts/netplay-broadcast.sh"
ROM_CHECKER="$INSTALL_DIR/scripts/rom-checker.sh"

# ─── Resolve context (env vars preferred; positional args as fallback) ────────
ROM_PATH="${ES_ROM:-${2:-}}"
SYSTEM="${ES_SYSTEM:-${1:-}}"
GAMENAME="${ES_GAMENAME:-}"

# ─── Helpers ─────────────────────────────────────────────────────────────────
notify() {
    local type="$1" msg="$2" dur="${3:-5}"
    # batocera-es-swissknife overlay (if available)
    command -v batocera-es-swissknife &>/dev/null && \
        batocera-es-swissknife --notification "$msg" 2>/dev/null
    # ES socket fallback
    [ -S /tmp/es.sock ] && \
        printf '<?xml version="1.0"?>\n<notification><message>%s</message></notification>\n' "$msg" \
        | nc -U /tmp/es.sock 2>/dev/null
    # Always write to netplay notification file so panel can pick it up
    echo "{\"type\":\"$type\",\"message\":\"$msg\",\"duration\":$dur}" \
        > /tmp/netplay_notification.json
}

die() {
    notify "error" "$1" "${2:-6}"
    exit 0   # exit 0 — error was user-facing, not a script fault
}

# ─── Sanity checks ───────────────────────────────────────────────────────────
if [ ! -f "$BROADCAST_SCRIPT" ]; then
    die "Outbreak not installed -- run boot.sh install" 5
fi

if [ -z "$ROM_PATH" ] || [ ! -f "$ROM_PATH" ]; then
    die "No ROM selected" 4
fi

# ─── Lockfile guard ──────────────────────────────────────────────────────────
LOCK=/tmp/outbreak-retroarch.lock
if [ -f "$LOCK" ] && kill -0 "$(cat "$LOCK")" 2>/dev/null; then
    die "A session is already active -- stop it first" 5
fi

# ─── Normalise system ────────────────────────────────────────────────────────
# If ES didn't pass the system, derive it from the ROM's parent directory.
if [ -z "$SYSTEM" ]; then
    SYSTEM=$(basename "$(dirname "$ROM_PATH")")
fi
SYSTEM=$(echo "$SYSTEM" | tr '[:upper:]' '[:lower:]')

case "$SYSTEM" in
    genesis)             SYSTEM="megadrive" ;;
    fbneo|arcade_fbneo)  SYSTEM="arcade"    ;;
esac

# Default gamename from filename if ES didn't provide it
if [ -z "$GAMENAME" ]; then
    GAMENAME=$(basename "$ROM_PATH" | sed 's/\.[^.]*$//')
fi

# ─── Source canonical lists from rom-checker.sh ──────────────────────────────
# rom-checker.sh guards its dispatch block with:
#   [[ "${BASH_SOURCE[0]}" != "${0}" ]] && return 0
# Sourcing is safe and gives us FBNEO_TITLES, MAME_TITLES, NETPLAY_SYSTEMS.
if [ -f "$ROM_CHECKER" ]; then
    # shellcheck source=/dev/null
    source "$ROM_CHECKER"
fi

# ─── System-level support check ──────────────────────────────────────────────
SUPPORTED_SYSTEMS="${NETPLAY_SYSTEMS:-nes snes megadrive genesis gba gb gbc ngp ngpc arcade neogeo mame fbneo atari2600 mastersystem gamegear turbografx16 pcengine nds 32x}"

if ! echo " $SUPPORTED_SYSTEMS " | grep -qw "$SYSTEM"; then
    SYS_UPPER=$(echo "$SYSTEM" | tr '[:lower:]' '[:upper:]')
    die "$SYS_UPPER is not supported for netplay" 6
fi

# ─── Arcade title check ───────────────────────────────────────────────────────
# Arcade ROMs must be in the curated FBNEO_TITLES or MAME_TITLES lists.
# The canonical zip name (without extension) is the lookup key.
GAME_ID=$(basename "$ROM_PATH" | sed 's/\.[^.]*$//' | tr '[:upper:]' '[:lower:]')

if [[ "$SYSTEM" == "arcade" || "$SYSTEM" == "neogeo" || "$SYSTEM" == "mame" ]]; then
    if [[ -z "${FBNEO_TITLES[$GAME_ID]+x}" && -z "${MAME_TITLES[$GAME_ID]+x}" ]]; then
        die "\"$GAMENAME\" is not in the verified netplay arcade list" 7
    fi
fi

# ─── Console ROM: no title-level block ───────────────────────────────────────
# Console ROMs are verified at boot via No-Intro DATs. If the user has the
# file it's treated as launchable — individual title filtering isn't needed
# since the DAT hash check already ensures canonical provenance.

# ─── All checks passed — launch RetroArch in broadcast mode ──────────────────
notify "broadcast" "Launching netplay: $GAMENAME..." 4

# Brief pause so the notification is visible before RetroArch takes focus
sleep 1

exec bash "$BROADCAST_SCRIPT" broadcast "$ROM_PATH" "auto"
