#!/usr/bin/env python3
"""
Batocera NetPlay Arcade - Session Discovery Server  v1.2
Adds: session history log, fixed IA downloader, core mismatch guard,
      fuzzy ROM finder + smart one-button join.
"""

import fcntl
import json
import os
import queue
import socket
import subprocess
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

# Local extension modules
try:
    from netplay_extensions import WanLobby, LogWatcher, get_gamepad_map
    EXTENSIONS_AVAILABLE = True
except ImportError:
    EXTENSIONS_AVAILABLE = False
    print("[WARN] netplay_extensions.py not found — WAN/log features disabled")

try:
    from rom_finder import find_rom, find_rom_candidates, invalidate_rom_index
    ROM_FINDER_AVAILABLE = True
except ImportError:
    ROM_FINDER_AVAILABLE = False
    print("[WARN] rom_finder.py not found — smart join disabled")

PORT = 8765
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# ─── DOWNLOAD PROGRESS (Task 2) ───────────────────────────────────────────────
download_progress = {}  # keyed by filename/key, value = dict with percent, status, filename
DEFAULT_INSTALL_DIR = "/userdata/system/netplay-arcade"
LOCAL_INSTALL_DIR = os.path.abspath(os.path.join(SCRIPT_DIR, ".."))
INSTALL_DIR = DEFAULT_INSTALL_DIR
if not os.path.isdir(DEFAULT_INSTALL_DIR) and not os.access("/userdata/system", os.W_OK):
    INSTALL_DIR = LOCAL_INSTALL_DIR
SESSION_FILE  = "/tmp/netplay_session.json"
CONFIG_FILE   = f"{INSTALL_DIR}/config.cfg"
LOG_FILE      = "/tmp/netplay-arcade.log"
NOTIF_FILE    = "/tmp/netplay_notification.json"
NOTIF_SEEN    = "/tmp/netplay_notification_seen.txt"
HISTORY_FILE  = f"{INSTALL_DIR}/session_history.json"


def _script_path(name):
    installed = os.path.join(DEFAULT_INSTALL_DIR, "scripts", name)
    local = os.path.join(SCRIPT_DIR, name)
    return installed if os.path.exists(installed) else local


NETPLAY_CORES_SCRIPT = _script_path("netplay-cores.sh")
NETPLAY_BROADCAST_SCRIPT = _script_path("netplay-broadcast.sh")
CORE_CHECKER_SCRIPT = _script_path("core-checker.sh")
ROM_CHECKER_SCRIPT = _script_path("rom-checker.sh")
DOWNLOAD_FLAG       = "/tmp/netplay_downloading.json"
DOWNLOAD_QUEUE_FILE = "/tmp/rom_download_queue.json"
UI_FILE = os.path.join(DEFAULT_INSTALL_DIR, "ui", "index.html")
if not os.path.exists(UI_FILE):
    UI_FILE = os.path.abspath(os.path.join(SCRIPT_DIR, "..", "ui", "index.html"))


def _atomic_write_text(path, text):
    """Write text to path atomically: write temp file, then rename into place."""
    dir_ = os.path.dirname(path) or "."
    fd, tmp = tempfile.mkstemp(dir=dir_, suffix=".tmp")
    try:
        with os.fdopen(fd, "w") as f:
            f.write(text)
        os.replace(tmp, path)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def _atomic_write_json(path, data):
    """Serialize data as JSON and write atomically."""
    _atomic_write_text(path, json.dumps(data, indent=2))


def log(msg):
    ts = time.strftime("%H:%M:%S")
    line = f"[{ts}] SERVER: {msg}\n"
    with open(LOG_FILE, "a") as f:
        f.write(line)
    print(line, end="")


def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def load_config():
    config = {
        "max_ping":           "40",
        "username":           socket.gethostname(),
        "discord_webhook":    "",
        "ra_username":        "",
        "rgsx_api_key":       "",
        "wan_enabled":        "true",
        "auto_download_roms": "true",
        "cabinet_mode":       "false",
    }
    try:
        with open(CONFIG_FILE) as f:
            for line in f:
                line = line.strip()
                if "=" in line and not line.startswith("#"):
                    k, v = line.split("=", 1)
                    config[k.strip().lower()] = v.strip().strip('"').strip("'")
    except Exception:
        pass
    return config


_config_cache = {}
_config_mtime = 0.0

def get_config():
    global _config_cache, _config_mtime
    try:
        mtime = os.path.getmtime(CONFIG_FILE)
        if mtime != _config_mtime:
            _config_cache = load_config()
            _config_mtime = mtime
    except Exception:
        if not _config_cache:
            _config_cache = load_config()
    return _config_cache


def get_session():
    try:
        with open(SESSION_FILE) as f:
            return json.load(f)
    except Exception:
        return None


_ra_cmdlines_cache: tuple = ([], 0.0)
_RA_CMDLINES_TTL = 2.0  # seconds — shared across all RA proc inspectors per loop tick

def _scan_ra_cmdlines() -> list:
    """Run pgrep -f retroarch once and return parsed cmdline arg lists for all matching
    PIDs.  Cached for _RA_CMDLINES_TTL seconds so multiple callers in the same
    _external_session_loop tick share a single fork instead of spawning three."""
    global _ra_cmdlines_cache
    cmds, ts = _ra_cmdlines_cache
    if time.time() - ts < _RA_CMDLINES_TTL:
        return cmds
    result_cmds = []
    try:
        result = subprocess.run(
            ['pgrep', '-f', 'retroarch'],
            capture_output=True, text=True, timeout=2
        )
        pids = [p.strip() for p in result.stdout.strip().split('\n') if p.strip()]
        for pid in pids:
            try:
                with open(f'/proc/{pid}/cmdline', 'rb') as f:
                    raw = f.read().split(b'\x00')
                result_cmds.append([a.decode('utf-8', errors='replace') for a in raw if a])
            except Exception:
                continue
    except Exception:
        pass
    _ra_cmdlines_cache = (result_cmds, time.time())
    return result_cmds


_active_rom_cache: tuple = (None, 0.0)
_ACTIVE_ROM_TTL = 4.0  # seconds — cache ROM result for /status polls under I/O load

def get_active_retroarch_rom():
    """Return the ROM path of the currently running RetroArch process, or None.
    Result is cached for _ACTIVE_ROM_TTL seconds to avoid stalling /status polls
    during the initial boot ROM scan when the system is under high I/O load.
    """
    global _active_rom_cache
    rom, ts = _active_rom_cache
    if time.time() - ts < _ACTIVE_ROM_TTL:
        return rom
    found = None
    for args in _scan_ra_cmdlines():
        for arg in reversed(args):
            if arg and not arg.startswith('-') and os.path.exists(arg):
                found = arg
                break
        if found:
            break
    _active_rom_cache = (found, time.time())
    return found


def _get_active_ra_core() -> str:
    """Return the bare core name (e.g. 'fbneo') of the running RetroArch, or ''."""
    for args in _scan_ra_cmdlines():
        for i, arg in enumerate(args):
            if arg in ('-L', '--libretro') and i + 1 < len(args):
                name = os.path.basename(args[i + 1])
                return name.replace('_libretro.so', '').replace('.so', '')
    return ''


_SESSION_ES_BUILTIN = "es_builtin"   # marker written to session files we auto-create


def _is_ra_hosting() -> bool:
    """Return True if RetroArch is currently running with the --host flag."""
    for args in _scan_ra_cmdlines():
        if '--host' in args:
            return True
    return False


def _external_session_loop():
    """
    Detect netplay host sessions started via the built-in Batocera ES flow
    (long-press B → Host a Netplay Game) and register them with Outbreak so
    they get announced to the WAN lobby and tracked in session history.

    Detects --host in RetroArch's /proc cmdline — does not rely on log output,
    which goes to anonymous pipes when launched via the ES built-in flow and
    is never written to es_launch_stderr.log.
    """
    was_hosting = False
    while True:
        time.sleep(2)

        sess = get_session()

        # Don't touch a session Outbreak's broadcast script is managing.
        # Do NOT reset was_hosting here — it tracks ES-native session state only.
        if sess and sess.get("source") != _SESSION_ES_BUILTIN:
            continue

        hosting = _is_ra_hosting()

        needs_update = (hosting and not sess) or (
            hosting and sess
            and sess.get("source") == _SESSION_ES_BUILTIN
            and sess.get("game", "Unknown") in ("Unknown", "")
        )

        if needs_update:
            # RA is hosting via the built-in ES flow — create/update session file
            rom  = get_active_retroarch_rom()
            core = _get_active_ra_core()
            lw   = log_watcher.get_state() if log_watcher else {}
            game = (lw.get("game_name")
                    or (os.path.splitext(os.path.basename(rom))[0] if rom else "Unknown"))
            system = (os.path.basename(os.path.dirname(rom)) if rom else "")
            session = {
                "status":       "hosting",
                "game":         game,
                "core":         core,
                "system":       system,
                "rom":          rom or "",
                "host":         get_local_ip(),
                "broadcaster":  get_config().get("username", socket.gethostname()),
                "timestamp":    int(time.time()) if not sess else sess.get("timestamp", int(time.time())),
                "local_players": 1,
                "source":       _SESSION_ES_BUILTIN,
            }
            _atomic_write_json(SESSION_FILE, session)
            log(f"ES host detected: '{game}' core={core or '?'} — session registered")

        elif not hosting and was_hosting:
            # RA exited — clean up the auto-created session file
            if sess and sess.get("source") == _SESSION_ES_BUILTIN:
                try:
                    os.remove(SESSION_FILE)
                    log("ES host session ended — session file cleared")
                except Exception:
                    pass

        was_hosting = hosting


_channel_cache     = {}
_channel_cache_ts  = 0.0
_CHANNEL_CACHE_TTL = 30   # seconds — channel manifest rarely changes
_channel_cache_lock = threading.Lock()   # guards check-then-set across threads

def get_core_channel_status():
    """
    Call netplay-cores.sh status and cache the result.
    Returns the parsed JSON or an error dict.
    Lock prevents thundering herd: concurrent /core-channel requests that all
    pass the TTL check would otherwise each spawn a netplay-cores.sh subprocess.
    """
    global _channel_cache, _channel_cache_ts
    now = time.time()
    with _channel_cache_lock:
        if _channel_cache and (now - _channel_cache_ts) < _CHANNEL_CACHE_TTL:
            return _channel_cache
        try:
            r = subprocess.run(
                ["bash", NETPLAY_CORES_SCRIPT, "status"],
                capture_output=True, text=True, timeout=5
            )
            _channel_cache    = json.loads(r.stdout)
            _channel_cache_ts = time.time()
        except Exception as e:
            _channel_cache    = {"error": str(e)}
            _channel_cache_ts = time.time()
        return _channel_cache


def _bust_channel_cache():
    with _channel_cache_lock:
        global _channel_cache_ts
        _channel_cache_ts = 0.0


def get_scan_summary():
    try:
        with open("/tmp/rom_scan_summary.json") as f:
            return json.load(f)
    except Exception:
        return None


def get_scan_progress():
    try:
        with open("/tmp/rom_scan_progress.json") as f:
            return json.load(f)
    except Exception:
        return None


# ─── SERVER-SENT EVENTS ───────────────────────────────────────────────────────
_sse_clients: list[queue.Queue] = []
_sse_lock = threading.Lock()
_notif_lock = threading.Lock()   # guards get_notification() dedup across threads


def _sse_push(data: dict):
    """Broadcast a status dict to all connected SSE clients."""
    msg = ("data: " + json.dumps(data) + "\n\n").encode()
    with _sse_lock:
        dead = []
        for q in _sse_clients:
            try:
                q.put_nowait(msg)
            except queue.Full:
                dead.append(q)
        for q in dead:
            _sse_clients.remove(q)


def _build_status_dict() -> dict:
    """Build the same payload served by GET /status (shared by SSE and REST)."""
    config  = get_config()
    session = get_session()
    scan    = get_scan_summary()
    notif   = get_notification()
    np      = log_watcher.get_state() if log_watcher else {}
    if session and np.get("phase") not in (None, "idle"):
        session["player_count"] = np.get("player_count", 0)
        session["max_players"]  = np.get("max_players", session.get("max_players", 2))
        session["np_phase"]     = np.get("phase")
        session["np_players"]   = np.get("players", {})
    elif session and "player_count" not in session:
        session["player_count"] = session.get("local_players", 1)
    if session and _idle_since > 0:
        timeout_min = int(config.get("idle_timeout_minutes", "8"))
        if timeout_min > 0:
            session["idle_seconds"] = int(time.time() - _idle_since)
            session["idle_timeout_seconds"] = timeout_min * 60
    version_file = os.path.join(INSTALL_DIR, ".version")
    try:
        with open(version_file) as _vf:
            installed_version = _vf.read().strip()
    except Exception:
        installed_version = "unknown"
    try:
        import json as _j
        with open("/tmp/es_browsing.json") as _bf:
            es_browsing = _j.load(_bf)
    except Exception:
        es_browsing = None
    return {
        "status":        "running",
        "version":       installed_version,
        "local_ip":      get_local_ip(),
        "username":      config["username"],
        "max_ping":      config["max_ping"],
        "wan_enabled":   config.get("wan_enabled", "true") == "true",
        "session":       session,
        "active_game":   get_active_retroarch_rom(),
        "rom_scan":      scan,
        "scan_progress": get_scan_progress(),
        "notification":  notif,
        "peers_count":   len(peer_discovery.get_active()),
        "lobby_id":      wan_lobby.get_lobby_id() if wan_lobby else None,
        "es_browsing":   es_browsing,
        "downloading":   get_download_status(),
        "timestamp":     int(time.time()),
    }


def _sse_broadcaster_loop():
    """Push status updates to SSE clients every 3 seconds."""
    while True:
        time.sleep(3)
        with _sse_lock:
            if not _sse_clients:
                continue
        try:
            _sse_push(_build_status_dict())
        except Exception:
            pass


ROMS_BASE   = "/userdata/roms"
_rom_watcher_lock   = threading.Lock()
_rom_watcher_status = {"running": False, "last_scan": 0, "rom_count": 0}
_boot_scan_active   = threading.Event()     # set while _boot_scan() subprocess is running

_ROM_EXTENSIONS = frozenset(('.nes','.sfc','.smc','.md','.gen','.gba','.gb','.gbc',
                             '.pce','.sms','.gg','.a26',
                             '.zip','.7z','.iso','.chd','.neo','.rom'))
_KNOWN_SYSTEMS = ("fbneo", "mame", "nes", "snes", "megadrive",
                  "gba", "gb", "gbc", "mastersystem", "gamegear",
                  "sega32x", "atari2600", "pcengine", "neogeo",
                  "ngp", "ngpc", "supergrafx", "psx", "dreamcast")

def count_roms():
    """Count ROM files in known system dirs — used by the watcher to detect new ROMs."""
    total = 0
    try:
        for sys_name in _KNOWN_SYSTEMS:
            sys_dir = os.path.join(ROMS_BASE, sys_name)
            try:
                for entry in os.scandir(sys_dir):
                    if entry.is_file(follow_symlinks=False):
                        ext = os.path.splitext(entry.name)[1].lower()
                        if ext in _ROM_EXTENSIONS:
                            total += 1
            except (FileNotFoundError, PermissionError):
                continue
    except Exception:
        pass
    return total

def _rom_watcher_loop():
    """
    Background thread: re-runs rom-checker.sh boot every 5 minutes, and
    immediately whenever the ROM count changes (e.g. after a download).
    Uses blocking subprocess.run() — this thread owns the child process.
    """
    global _rom_watcher_status
    INTERVAL = 300   # 5 min normal cycle
    CHECK    = 60    # check for count change every 60 s

    # Initial delay so boot scan (started in __main__) can finish first
    time.sleep(10)
    last_count = count_roms()
    with _rom_watcher_lock:
        _rom_watcher_status["rom_count"] = last_count

    cycles_until_full = INTERVAL // CHECK
    cycle = 0
    while True:
        time.sleep(CHECK)
        current_count = count_roms()
        changed = current_count != last_count
        cycle += 1

        if changed or cycle >= cycles_until_full:
            if _boot_scan_active.is_set():
                last_count = current_count     # acknowledge the change
                cycle = 0
                continue
            with _rom_watcher_lock:
                _rom_watcher_status["running"] = True
                _rom_watcher_status["rom_count"] = current_count
            log(f"ROM watcher: triggering scan (count={current_count}, changed={changed})")
            try:
                subprocess.run(
                    ["bash", ROM_CHECKER_SCRIPT, "boot"],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                    timeout=3600)
            except subprocess.TimeoutExpired:
                log("ROM watcher: scan timed out after 60 min")
            except Exception as e:
                log(f"ROM watcher error: {e}")
            finally:
                with _rom_watcher_lock:
                    _rom_watcher_status["running"] = False
                    _rom_watcher_status["last_scan"] = int(time.time())
                if ROM_FINDER_AVAILABLE:
                    invalidate_rom_index()
            last_count = current_count
            cycle = 0


def get_download_status():
    """Return the contents of the download flag file, or None if not downloading."""
    try:
        with open(DOWNLOAD_FLAG) as f:
            return json.load(f)
    except Exception:
        return None


def get_activity():
    """Aggregate boot scan, download, and scraper status into one dict."""
    activity = {"boot_scan": None, "downloads": None, "scraper": None}

    # ── Boot scan ──
    progress = get_scan_progress()
    if progress:
        activity["boot_scan"] = progress
    else:
        # Check if rom-checker boot is still running (no pgrep on Batocera)
        try:
            result = subprocess.run(
                ["sh", "-c", "ps -eo pid,args | grep '[r]om-checker.sh boot'"],
                capture_output=True, text=True, timeout=3)
            if result.stdout.strip():
                activity["boot_scan"] = {"phase": "running", "detail": "scan in progress"}
        except Exception:
            pass

    # ── Downloads ──
    dl_status = get_download_status()
    if dl_status:
        activity["downloads"] = dl_status
    else:
        # Check queue for summary
        try:
            with open(DOWNLOAD_QUEUE_FILE) as f:
                q = json.load(f)
            queued = sum(1 for e in q if e.get("status") == "queued")
            complete = sum(1 for e in q if e.get("status") == "complete")
            error = sum(1 for e in q if e.get("status") == "error")
            activity["downloads"] = {
                "active": False, "queued": queued,
                "complete": complete, "error": error, "total": len(q)
            }
        except Exception:
            pass

    # ── Media scraper ── (python lock or bash lock)
    scraper_running = False
    for scraper_lock in ("/tmp/outbreak-media-scraper.lock", "/tmp/outbreak-media-scrape.lock"):
        try:
            with open(scraper_lock) as f:
                pid = f.read().strip()
            if pid and os.path.exists(f"/proc/{pid}"):
                scraper_running = True
                activity["scraper"] = {"running": True, "pid": int(pid)}
                break
        except Exception:
            pass
    if not scraper_running:
        activity["scraper"] = {"running": False}

    return activity


def _run_scraper_if_needed():
    """Run media scraper if it's not already running. Called from the download
    worker thread so it blocks that thread (single-process architecture)."""
    # Skip if boot scan is still running — scraper should wait
    if _boot_scan_active.is_set():
        return

    # Skip if scraper is already running
    for lock in ("/tmp/outbreak-media-scraper.lock", "/tmp/outbreak-media-scrape.lock"):
        try:
            with open(lock) as f:
                pid = f.read().strip()
            if pid and os.path.exists(f"/proc/{pid}"):
                return  # already running
        except Exception:
            pass

    log("Download worker: running media scraper")
    try:
        subprocess.run(
            ["bash", ROM_CHECKER_SCRIPT, "scrape"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            timeout=3600)  # 1 hour limit
    except subprocess.TimeoutExpired:
        log("Download worker: media scraper timed out")
    except Exception as e:
        log(f"Download worker: media scraper error: {e}")


def _download_worker_loop():
    """
    Background thread: processes the ROM download queue whenever there is no
    active netplay session, pausing between files to avoid bandwidth contention.
    Sends ES notifications via rom-checker.sh which writes/clears the flag file.
    """
    POLL_INTERVAL = 30   # seconds between queue checks

    # Initial delay — let boot scan finish writing the queue first
    time.sleep(25)

    while True:
        time.sleep(POLL_INTERVAL)

        # Skip if a download is already in progress (flag file exists).
        # Treat as stale if older than 25 minutes — the subprocess likely crashed.
        if os.path.exists(DOWNLOAD_FLAG):
            try:
                age = time.time() - os.path.getmtime(DOWNLOAD_FLAG)
                if age < 1500:  # 25 minutes
                    continue
                log("Download worker: stale flag (>25 min), clearing and resuming")
                os.unlink(DOWNLOAD_FLAG)
            except OSError:
                pass

        # Skip if a netplay session is active — don't compete for bandwidth
        session = get_session()
        if session and session.get("status") in ("hosting", "joining"):
            continue

        # Skip if core downloads are in progress (lock file held)
        try:
            _lf = open("/tmp/outbreak_download.lock", "w")
            fcntl.flock(_lf, fcntl.LOCK_EX | fcntl.LOCK_NB)
            fcntl.flock(_lf, fcntl.LOCK_UN)
            _lf.close()
        except (IOError, OSError):
            try:
                _lf.close()
            except Exception:
                pass
            continue

        # Check if there are pending items in the queue
        try:
            with open(DOWNLOAD_QUEUE_FILE) as f:
                dl_queue = json.load(f)
            if not any(e.get("status") == "queued" for e in dl_queue):
                # No downloads pending — but scraper may still need to run
                # (e.g. interrupted by reinstall, or never triggered yet)
                _run_scraper_if_needed()
                continue
        except Exception:
            continue

        log("Download worker: processing queue")
        try:
            subprocess.run(
                ["bash", ROM_CHECKER_SCRIPT, "queue"],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                timeout=1800,  # 30 min hard limit
            )
        except subprocess.TimeoutExpired:
            log("Download worker: timed out after 30 min")
        except Exception as e:
            log(f"Download worker error: {e}")

        # After processing downloads, check if queue is fully done.
        # If so, run the media scraper synchronously within this thread.
        try:
            with open(DOWNLOAD_QUEUE_FILE) as f:
                dl_queue = json.load(f)
            if not any(e.get("status") == "queued" for e in dl_queue):
                _run_scraper_if_needed()
        except Exception:
            pass


def get_notification():
    """Return a notification only once per write (seen-file dedup).
    Lock ensures two concurrent callers (SSE broadcaster + /notification endpoint)
    can't both pass the dedup check and deliver the same notification twice."""
    with _notif_lock:
        try:
            with open(NOTIF_FILE) as _nf:
                notif = json.loads(_nf.read())
            notif_ts = str(os.path.getmtime(NOTIF_FILE))
            try:
                with open(NOTIF_SEEN) as _sf:
                    seen_ts = _sf.read().strip()
            except Exception:
                seen_ts = ""
            if notif_ts == seen_ts:
                return {"type": "none"}
            with open(NOTIF_SEEN, "w") as f:
                f.write(notif_ts)
            return notif
        except Exception:
            return {"type": "none"}


# ─── PING CACHE ───────────────────────────────────────────────────────────────

class PingCache:
    TTL = 8

    def __init__(self):
        self._cache = {}
        self._lock  = threading.Lock()
        self._queue = set()
        threading.Thread(target=self._worker, daemon=True, name="ping-cache").start()

    def get(self, ip):
        with self._lock:
            entry = self._cache.get(ip)
            self._queue.add(ip)
        if entry and (time.time() - entry["ts"]) < self.TTL:
            return entry["ms"]
        return 999

    def _worker(self):
        while True:
            with self._lock:
                todo = set(self._queue)
                self._queue.clear()
            for ip in todo:
                ms = self._ping_one(ip)
                with self._lock:
                    self._cache[ip] = {"ms": ms, "ts": time.time()}
            time.sleep(2)

    @staticmethod
    def _ping_one(ip):
        try:
            r = subprocess.run(
                ["ping", "-c", "2", "-W", "1", ip],
                capture_output=True, text=True, timeout=4
            )
            for line in r.stdout.split("\n"):
                if "avg" in line or "rtt" in line:
                    parts = line.split("/")
                    if len(parts) >= 5:
                        return int(float(parts[4]))
        except Exception:
            pass
        return 999


ping_cache = PingCache()


# ─── PEER DISCOVERY ──────────────────────────────────────────────────────────

class PeerDiscovery:
    def __init__(self):
        self.peers   = {}
        self.running = False
        self._lock   = threading.Lock()

    def start(self):
        self.running = True
        threading.Thread(target=self._broadcast_loop, daemon=True, name="lan-bcast").start()
        threading.Thread(target=self._listen_loop,    daemon=True, name="lan-listen").start()

    def _broadcast_loop(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        while self.running:
            try:
                cfg = get_config()
                session = get_session()
                if session:
                    session = dict(session)  # copy — don't mutate the cached object
                    np = log_watcher.get_state() if log_watcher else {}
                    if np.get("phase") not in (None, "idle"):
                        # Active netplay: use live counts from the log watcher
                        session["player_count"] = np.get("player_count", 0)
                        session["max_players"]  = np.get("max_players",
                                                         session.get("max_players", 2))
                    elif "player_count" not in session:
                        # Session started, no one joined yet: at minimum local_players are seated
                        session["player_count"] = session.get("local_players", 1)
                payload = json.dumps({
                    "type":        "netplay_arcade_beacon",
                    "host":        get_local_ip(),
                    "port":        PORT,
                    "username":    cfg["username"],
                    "session":     session,
                    "pin_required": bool(cfg.get("session_pin", "").strip()),
                    "timestamp":   int(time.time()),
                }).encode()
                sock.sendto(payload, ("<broadcast>", 8766))
            except Exception as e:
                log(f"Broadcast error: {e}")
            time.sleep(5)
        sock.close()

    def _listen_loop(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            sock.bind(("", 8766))
            sock.settimeout(1.0)
        except Exception as e:
            log(f"Listen bind error: {e}")
            return
        local = get_local_ip()
        while self.running:
            try:
                data, addr = sock.recvfrom(4096)
                msg = json.loads(data.decode())
                if msg.get("type") == "netplay_arcade_beacon":
                    ip = addr[0]
                    if ip != local:
                        with self._lock:
                            self.peers[ip] = {**msg, "last_seen": int(time.time()), "ip": ip}
            except socket.timeout:
                pass
            except Exception:
                pass
        sock.close()

    def get_active(self, max_age=15):
        now = int(time.time())
        with self._lock:
            return {ip: p for ip, p in self.peers.items()
                    if now - p.get("last_seen", 0) < max_age}


peer_discovery = PeerDiscovery()
log_watcher    = LogWatcher()                         if EXTENSIONS_AVAILABLE else None
wan_lobby      = WanLobby(get_config, get_session, log_watcher=log_watcher) if EXTENSIONS_AVAILABLE else None


# ─── HTTP HANDLER ─────────────────────────────────────────────────────────────

class NetPlayHandler(BaseHTTPRequestHandler):

    # Endpoints that never require authentication — the UI page itself (serves
    # the login form), health/ping probes, and the auth-check endpoint.
    _PUBLIC_PATHS = frozenset({"/ui", "/ping", "/health", "/auth-check", "/fonts/"})

    def log_message(self, fmt, *args):
        pass

    def send_json(self, data, status=200):
        body = json.dumps(data, indent=2).encode()
        self.send_response(status)
        self.send_header("Content-Type",                "application/json")
        self.send_header("Content-Length",              str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _check_auth(self) -> bool:
        """Return True if the request is authorised.  If panel_password is not
        configured, all requests pass.  Otherwise the client must supply the
        password as a Bearer token (Authorization header) or as a ?token= query
        parameter (needed for SSE EventSource which can't set headers)."""
        cfg = get_config()
        pw = cfg.get("panel_password", "").strip()
        if not pw:
            return True  # no password configured — open access
        path = self.path.split("?")[0]
        if path in self._PUBLIC_PATHS or any(path.startswith(p) for p in self._PUBLIC_PATHS if p.endswith("/")):
            return True
        # Check Authorization: Bearer <token>
        auth = self.headers.get("Authorization", "")
        if auth.startswith("Bearer ") and auth[7:] == pw:
            return True
        # Fallback: ?token= query param (for SSE EventSource)
        from urllib.parse import parse_qs, urlparse
        qs = parse_qs(urlparse(self.path).query)
        if (qs.get("token") or [""])[0] == pw:
            return True
        return False

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin",  "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.end_headers()

    def do_GET(self):
        # Explicit local import — prevents Python 3.12 UnboundLocalError when
        # the compiler treats parse_qs as local due to nested import statements
        # elsewhere in the method body (import glob as _glob, etc.).
        from urllib.parse import parse_qs, urlparse
        path = self.path.split("?")[0]

        # ── Panel authentication gate ────────────────────────────────────────
        if path == "/auth-check":
            cfg = get_config()
            pw = cfg.get("panel_password", "").strip()
            if not pw:
                self.send_json({"auth_required": False})
                return
            # Check token directly (can't use _check_auth — this path is public)
            auth = self.headers.get("Authorization", "")
            token_from_header = auth[7:] if auth.startswith("Bearer ") else ""
            qs = parse_qs(urlparse(self.path).query)
            token_from_qs = (qs.get("token") or [""])[0]
            if token_from_header == pw or token_from_qs == pw:
                self.send_json({"auth_required": True, "authenticated": True})
            else:
                self.send_json({"auth_required": True, "authenticated": False}, 401)
            return

        if not self._check_auth():
            self.send_json({"error": "unauthorized", "auth_required": True}, 401)
            return

        if path == "/session":
            config      = get_config()
            session_pin = config.get("session_pin", "").strip()
            if session_pin:
                qs       = parse_qs(urlparse(self.path).query)
                provided = (qs.get("pin") or [""])[0]
                if provided != session_pin:
                    self.send_json({"error": "pin_required"}, 403)
                    return
            s = get_session()
            self.send_json(s if s else {"status": "idle"})

        elif path == "/peers":
            config   = get_config()
            max_ping = int(config.get("max_ping", 130))
            peers    = peer_discovery.get_active()
            peer_list = []
            for ip, peer in peers.items():
                ms = ping_cache.get(ip)
                peer_list.append({**peer, "ping_ms": ms,
                                  "eligible": ms <= max_ping, "source": "lan"})
            # Only show actively hosting peers
            peer_list = [p for p in peer_list
                         if p.get("session") and p["session"].get("status") == "hosting"]
            peer_list.sort(key=lambda x: x.get("ping_ms", 999))
            self.send_json({"peers": peer_list, "max_ping": max_ping})

        elif path == "/wan-peers":
            if not wan_lobby:
                self.send_json({"error": "WAN not available", "rooms": []})
                return
            config    = get_config()
            max_ping  = int(config.get("max_ping", 130))
            own_id    = wan_lobby.get_lobby_id()
            rooms     = [r for r in wan_lobby.get_wan_rooms()
                         if own_id is None or r.get("id") != own_id]
            for r in rooms:
                ms = r.get("ping_ms")
                r["eligible"] = (ms is not None) and (ms <= max_ping)
            rooms.sort(key=lambda x: x.get("ping_ms") or 999)
            self.send_json({"rooms": rooms, "max_ping": max_ping})

        elif path == "/status":
            self.send_json(_build_status_dict())

        elif path == "/health":
            # Process health check — reports rom-checker process counts
            try:
                r = subprocess.run(
                    ["bash", "-c",
                     "ps aux | grep 'rom-checker.sh' | grep -v grep | "
                     "awk '{print $NF}' | sort | uniq -c | sort -rn"],
                    capture_output=True, text=True, timeout=5,
                )
                lines = [l.strip() for l in r.stdout.strip().splitlines() if l.strip()]
                procs = {}
                total = 0
                for line in lines:
                    parts = line.split(None, 1)
                    if len(parts) == 2:
                        count = int(parts[0])
                        name = parts[1]
                        procs[name] = count
                        total += count
                # Expected max: boot(1) + sync-arcade(1) + queue(1) + media-scrape(1) = 4
                healthy = total <= 4
                self.send_json({
                    "healthy": healthy,
                    "process_count": total,
                    "processes": procs,
                    "warning": None if healthy else f"{total} rom-checker processes running (expected ≤4)",
                })
            except Exception as e:
                self.send_json({"healthy": False, "error": str(e)})

        elif path == "/events":
            # Server-Sent Events stream — client subscribes once and receives
            # pushed status updates every 3 s without repeated polling.
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            q: queue.Queue = queue.Queue(maxsize=10)
            with _sse_lock:
                _sse_clients.append(q)
            # Send initial state immediately so the client doesn't wait 3 s
            try:
                initial = ("data: " + json.dumps(_build_status_dict()) + "\n\n").encode()
                self.wfile.write(initial)
                self.wfile.flush()
            except Exception:
                with _sse_lock:
                    try: _sse_clients.remove(q)
                    except ValueError: pass
                return
            try:
                while True:
                    try:
                        msg = q.get(timeout=20)
                        self.wfile.write(msg)
                        self.wfile.flush()
                    except queue.Empty:
                        # Heartbeat comment keeps proxies from closing the connection
                        self.wfile.write(b": heartbeat\n\n")
                        self.wfile.flush()
            except Exception:
                pass
            finally:
                with _sse_lock:
                    try: _sse_clients.remove(q)
                    except ValueError: pass

        elif path == "/netplay-state":
            self.send_json(log_watcher.get_state() if log_watcher
                           else {"error": "extensions not loaded"})

        elif path == "/gamepad-map":
            self.send_json(get_gamepad_map() if EXTENSIONS_AVAILABLE
                           else {"error": "extensions not loaded"})

        elif path == "/notification":
            self.send_json(get_notification())

        elif path == "/close-ui":
            # Kill the cabinet browser launched by the Ports script so the
            # player is returned to EmulationStation after pressing EXIT TO MENU.
            pid_file = "/tmp/outbreak_chrome.pid"
            try:
                with open(pid_file) as f:
                    pid = int(f.read().strip())
                import signal as _sig
                os.kill(pid, _sig.SIGTERM)
                self.send_json({"ok": True, "pid": pid})
            except FileNotFoundError:
                self.send_json({"ok": False, "error": "no browser PID file"}, 404)
            except ProcessLookupError:
                self.send_json({"ok": False, "error": "process already gone"}, 404)
            except Exception as e:
                self.send_json({"ok": False, "error": str(e)}, 500)

        elif path == "/rom-scan":
            s = get_scan_summary()
            self.send_json(s if s else {"status": "not_run"})

        elif path == "/rom-status":
            # Combined: scan summary + background watcher state + current ROM count
            s = get_scan_summary() or {"status": "not_run"}
            with _rom_watcher_lock:
                w = dict(_rom_watcher_status)
            s["watcher"] = w
            self.send_json(s)

        elif path == "/config":
            cfg = get_config()
            result = {k: v for k, v in cfg.items()
                      if k not in ("discord_webhook", "rgsx_api_key", "panel_password")}
            # Always include opt-in flags even if not yet in config file
            result.setdefault("auto_download_roms", "true")
            result.setdefault("cabinet_mode", "false")
            result["panel_password_set"] = bool(cfg.get("panel_password", "").strip())
            self.send_json(result)

        elif path == "/history":
            # Session history log — append-only, written by stop_session
            try:
                with open(HISTORY_FILE) as f:
                    history = json.load(f)
            except Exception:
                history = []
            # Enrich with duration string for the UI
            for entry in history:
                s = entry.get("duration_s", 0)
                h, rem = divmod(s, 3600)
                m, sec = divmod(rem, 60)
                if h:
                    entry["duration_str"] = f"{h}h {m}m"
                elif m:
                    entry["duration_str"] = f"{m}m {sec}s"
                else:
                    entry["duration_str"] = f"{sec}s"
            self.send_json({"history": list(reversed(history)),  # newest first
                            "total": len(history)})

        elif path == "/find-rom":
            # Fuzzy ROM search — ?q=<title>&system=<hint>
            qs = parse_qs(urlparse(self.path).query)
            query  = qs.get("q",      [""])[0]
            hint   = qs.get("system", [""])[0]
            if not query:
                self.send_json({"error": "q parameter required"}, 400)
                return
            if ROM_FINDER_AVAILABLE:
                result     = find_rom(query, hint)
                candidates = find_rom_candidates(query, 5)
                self.send_json({
                    "query":      query,
                    "best":       result,
                    "candidates": candidates,
                })
            else:
                self.send_json({"error": "rom_finder not available"})

        elif path == "/core-channel":
            # Full channel status: all managed cores, versions, hashes
            self.send_json(get_core_channel_status())

        elif path == "/core-version":
            # Quick version lookup for a single core  ?core=snes9x
            qs   = parse_qs(urlparse(self.path).query)
            core = qs.get("core", [""])[0].replace("_libretro", "").replace(".so", "")
            if not core:
                self.send_json({"error": "core parameter required"}, 400)
                return
            r = subprocess.run(
                ["bash", NETPLAY_CORES_SCRIPT,
                 "version", core],
                capture_output=True, text=True, timeout=5
            )
            try:
                self.send_json(json.loads(r.stdout))
            except Exception:
                self.send_json({"output": r.stdout})

        elif path == "/core-options":
            # Return the active core's .opt file contents so joining clients can
            # mirror the host's emulator options and avoid emulation state divergence.
            s = get_session()
            if not s or not s.get("core"):
                self.send_json({"options": "", "source": None})
                return
            core      = s.get("core", "")
            game_name = s.get("game", "")
            ra_cfg    = "/userdata/system/retroarch/config"
            candidates = [
                os.path.join(ra_cfg, core, f"{game_name}.opt"),
                os.path.join(ra_cfg, core, f"{core}.opt"),
            ]
            for path_try in candidates:
                if os.path.isfile(path_try):
                    try:
                        with open(path_try) as f:
                            content = f.read()
                        self.send_json({"options": content, "source": path_try})
                    except Exception:
                        self.send_json({"options": "", "source": None})
                    return
            self.send_json({"options": "", "source": None})

        elif path == "/ping":
            self.send_json({"pong": True, "time": int(time.time())})

        elif path == "/api/download-progress":
            self.send_json(download_progress)

        elif path == "/api/activity":
            self.send_json(get_activity())

        elif path == "/api/top-games":
            import xml.etree.ElementTree as _ET
            import glob as _glob
            qs    = parse_qs(urlparse(self.path).query)
            limit = int(qs.get("limit", ["15"])[0])
            games = []
            for gl_path in sorted(_glob.glob("/userdata/roms/*/gamelist.xml")):
                system = os.path.basename(os.path.dirname(gl_path))
                try:
                    root = _ET.parse(gl_path).getroot()
                    for gentry in root.iter("game"):
                        path_el = gentry.find("path")
                        if path_el is None:
                            continue
                        playcount = 0
                        pc_el = gentry.find("playcount")
                        if pc_el is not None and pc_el.text:
                            try:
                                playcount = int(pc_el.text)
                            except ValueError:
                                pass
                        if playcount == 0:
                            continue
                        rom_path = (path_el.text or "").strip()
                        if not rom_path.startswith("/"):
                            rom_path = os.path.normpath(
                                os.path.join(f"/userdata/roms/{system}", rom_path))
                        name_el = gentry.find("name")
                        games.append({
                            "stem":      os.path.splitext(os.path.basename(rom_path))[0],
                            "name":      name_el.text if name_el is not None else None,
                            "system":    system,
                            "path":      rom_path,
                            "playcount": playcount,
                        })
                except Exception:
                    continue
            games.sort(key=lambda g: g["playcount"], reverse=True)
            self.send_json({"games": games[:limit]})

        elif path == "/api/core-drift-warning":
            warning_file = '/tmp/outbreak_core_drift_warning'
            if os.path.exists(warning_file):
                with open(warning_file) as f:
                    return self.send_json({'warning': f.read().strip()})
            self.send_json({'warning': None})

        elif path == "/game-info":
            import xml.etree.ElementTree as _ET
            import glob as _glob
            qs     = parse_qs(urlparse(self.path).query)
            game   = qs.get("game",   [""])[0].strip()
            system = qs.get("system", [""])[0].strip()
            game_stem = os.path.splitext(os.path.basename(game))[0] if game else ""
            if not game_stem:
                self.send_json({"display_name": None, "image": None})
                return
            systems_to_check = []
            if system and system not in ("cmdfiles", ""):
                systems_to_check.append(system)
            for gl in sorted(_glob.glob("/userdata/roms/*/gamelist.xml")):
                sn = os.path.basename(os.path.dirname(gl))
                if sn not in systems_to_check:
                    systems_to_check.append(sn)
            for sys_name in systems_to_check:
                gl_path = f"/userdata/roms/{sys_name}/gamelist.xml"
                if not os.path.isfile(gl_path):
                    continue
                try:
                    for gentry in _ET.parse(gl_path).getroot().iter("game"):
                        path_el = gentry.find("path")
                        if path_el is None:
                            continue
                        stem = os.path.splitext(os.path.basename(path_el.text or ""))[0]
                        if stem.lower() != game_stem.lower():
                            continue
                        name_el  = gentry.find("name")
                        # Prefer thumbnail (box art) over image (screenshot)
                        thumb_el = gentry.find("thumbnail")
                        image_el = gentry.find("image")
                        best_el  = thumb_el if thumb_el is not None and thumb_el.text else image_el
                        image_text = best_el.text if best_el is not None else None
                        image_abs  = None
                        if image_text:
                            rom_dir = f"/userdata/roms/{sys_name}"
                            resolved = os.path.normpath(os.path.join(rom_dir, image_text))
                            if os.path.isfile(resolved):
                                image_abs = resolved
                        # Also look up CDN thumb from game-names.json as fallback
                        cdn_thumb = None
                        try:
                            _gn_path = os.path.join(LOCAL_INSTALL_DIR, "docs", "game-names.json")
                            with open(_gn_path) as _gf:
                                _gn = json.load(_gf)
                            _meta = _gn.get(game_stem)
                            if isinstance(_meta, dict):
                                cdn_thumb = _meta.get("thumb")
                        except Exception:
                            pass
                        self.send_json({
                            "display_name": name_el.text if name_el is not None else None,
                            "image":        image_text,
                            "image_abs":    image_abs,
                            "system":       sys_name,
                            "thumb":        cdn_thumb,
                        })
                        return
                except Exception:
                    continue
            # Fall back to game-names.json for arcade titles not in gamelist.xml
            gn_path = os.path.join(LOCAL_INSTALL_DIR, "docs", "game-names.json")
            try:
                with open(gn_path) as _f:
                    _names = json.load(_f)
                meta = _names.get(game_stem)
                if isinstance(meta, dict):
                    display = meta.get("name")
                    thumb   = meta.get("thumb")
                else:
                    display = meta
                    thumb   = None
                if display:
                    self.send_json({"display_name": display, "image": None, "thumb": thumb})
                    return
            except Exception:
                pass
            self.send_json({"display_name": None, "image": None})

        elif path == "/game-art":
            import glob as _glob
            qs       = parse_qs(urlparse(self.path).query)
            game     = qs.get("game",    [""])[0].strip()
            system   = qs.get("system",  [""])[0].strip()
            imgpath  = qs.get("imgpath", [""])[0].strip()
            game_stem = os.path.splitext(os.path.basename(game))[0] if game else ""
            if not game_stem:
                self.send_response(404); self.end_headers(); return
            candidates = []
            # box-2D is the explicit 2D box art folder; media/images is the general
            # scraper image (also box art by default in Batocera). Prefer box-2D first.
            if system and system not in ("cmdfiles", ""):
                for ext in ("png", "jpg"):
                    candidates += [
                        f"/userdata/roms/{system}/media/box-2D/{game_stem}.{ext}",
                        f"/userdata/roms/{system}/images/{game_stem}-thumb.{ext}",
                        f"/userdata/roms/{system}/media/images/{game_stem}.{ext}",
                        f"/userdata/roms/{system}/images/{game_stem}.{ext}",
                    ]
                # Fuzzy: thumb files often have region tags the ROM doesn't
                # e.g. ROM "Streets of Rage 3.zip" → thumb "Streets of Rage 3 (E)-thumb.png"
                for ext in ("png", "jpg"):
                    candidates += sorted(_glob.glob(
                        f"/userdata/roms/{system}/images/{_glob.escape(game_stem)}*-thumb.{ext}"))
            # Fallback: gamelist.xml resolved path (may point to screenshot; accepted if
            # no box-2D art was found above)
            if imgpath and imgpath.startswith("/userdata/") and ".." not in imgpath:
                candidates.append(imgpath)
            for ext in ("png", "jpg"):
                candidates += sorted(_glob.glob(f"/userdata/roms/*/media/box-2D/{game_stem}.{ext}"))
                candidates += sorted(_glob.glob(f"/userdata/roms/*/images/{game_stem}-thumb.{ext}"))
                candidates += sorted(_glob.glob(f"/userdata/roms/*/images/{_glob.escape(game_stem)}*-thumb.{ext}"))
                candidates += sorted(_glob.glob(f"/userdata/roms/*/media/images/{game_stem}.{ext}"))
                candidates += sorted(_glob.glob(f"/userdata/roms/*/images/{game_stem}.{ext}"))
            seen = set()
            for img_path in candidates:
                if img_path in seen:
                    continue
                seen.add(img_path)
                if not os.path.isfile(img_path):
                    continue
                ctype = "image/jpeg" if img_path.endswith(".jpg") else "image/png"
                try:
                    mtime = str(int(os.path.getmtime(img_path)))
                    etag = f'"{game_stem}-{mtime}"'
                    if self.headers.get("If-None-Match") == etag:
                        self.send_response(304)
                        self.end_headers()
                        return
                    with open(img_path, "rb") as f:
                        body = f.read()
                    self.send_response(200)
                    self.send_header("Content-Type",   ctype)
                    self.send_header("Content-Length", str(len(body)))
                    self.send_header("ETag",           etag)
                    self.send_header("Cache-Control",  "public, max-age=86400")
                    self.end_headers()
                    self.wfile.write(body)
                    return
                except Exception:
                    continue
            self.send_response(404); self.end_headers()

        elif path == "/ui":
            try:
                with open(UI_FILE, "rb") as f:
                    body = f.read()
                self.send_response(200)
                self.send_header("Content-Type",   "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            except Exception:
                self.send_json({"error": "UI file not found"}, 404)

        elif path.startswith("/fonts/"):
            # Serve locally cached font files — no CDN needed after first install
            filename = os.path.basename(path)
            font_path = os.path.join(INSTALL_DIR, "ui", "fonts", filename)
            if os.path.exists(font_path) and filename.endswith(".woff2"):
                with open(font_path, "rb") as f:
                    body = f.read()
                self.send_response(200)
                self.send_header("Content-Type",   "font/woff2")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control",  "public, max-age=31536000")
                self.end_headers()
                self.wfile.write(body)
            else:
                self.send_json({"error": "Font not found"}, 404)

        else:
            self.send_json({"error": "Not found"}, 404)

    def do_POST(self):
        if not self._check_auth():
            self.send_json({"error": "unauthorized", "auth_required": True}, 401)
            return

        length = int(self.headers.get("Content-Length", 0))
        body   = self.rfile.read(length) if length > 0 else b"{}"
        try:
            data = json.loads(body)
        except Exception:
            data = {}

        path = self.path.split("?")[0]

        if path == "/broadcast":
            # core is optional — omit or send "auto" to let the server
            # detect the right netplay core from the ROM's system/extension.
            if not data.get("core"):
                data["core"] = "auto"
            dl = get_download_status()
            extra = ({"download_warning": "ROM updates downloading — network latency may be higher than usual"}
                     if dl else {})
            self._shell_action("broadcast", data, ["rom", "core"], extra=extra)

        elif path == "/join":
            # Standard join — caller supplies rom/core explicitly.
            # Also threads remote_user through to the shell for history logging.
            self._shell_join(data)

        elif path == "/join-smart":
            # One-button join: given host IP + remote game name, we:
            # 1. Query the host's /session for game name + core
            # 2. Fuzzy-search the local ROM library
            # 3. Auto-switch core if needed (core-checker.sh set)
            # 4. Launch join_session with the resolved paths
            self._handle_smart_join(data)

        elif path == "/verify-core":
            # Verify local core matches a given hash
            # Body: {"core": "snes9x", "md5": "abc123...", "channel": "stable-1"}
            core     = data.get("core", "").replace("_libretro", "").replace(".so", "")
            expected = data.get("md5", "")
            channel  = data.get("channel", "")
            if not core:
                self.send_json({"error": "core required"}, 400)
                return
            r = subprocess.run(
                ["bash", NETPLAY_CORES_SCRIPT,
                 "verify", core, expected, channel],
                capture_output=True, text=True, timeout=5
            )
            try:
                result = json.loads(r.stdout)
                _bust_channel_cache()
                self.send_json(result)
            except Exception:
                self.send_json({"output": r.stdout})

        elif path == "/update-channel":
            # Admin: re-copy core(s) from system into the channel
            # Body: {"core": "snes9x"}  or {} to update all
            core = data.get("core", "")
            r = subprocess.run(
                ["bash", NETPLAY_CORES_SCRIPT,
                 "update-channel", core],
                capture_output=True, text=True, timeout=30
            )
            _bust_channel_cache()
            try:
                self.send_json(json.loads(r.stdout))
            except Exception:
                self.send_json({"output": r.stdout})

        elif path == "/api/fix-games":
            paths = data.get("paths", [])
            if not isinstance(paths, list) or not paths:
                self.send_json({"error": "paths list required"}, 400)
                return
            # Validate each path is under /userdata/ and exists
            safe = [p for p in paths if isinstance(p, str)
                    and p.startswith("/userdata/") and ".." not in p
                    and os.path.isfile(p)]
            if safe:
                def _fix_games_bg(fix_paths):
                    try:
                        subprocess.run(
                            ["bash", ROM_CHECKER_SCRIPT, "fix"] + fix_paths,
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                            timeout=300)
                    except subprocess.TimeoutExpired:
                        log("fix-games: timed out after 5 min")
                    except Exception as e:
                        log(f"fix-games error: {e}")
                threading.Thread(target=_fix_games_bg, args=(safe,),
                                 daemon=True, name="fix-games").start()
            self.send_json({"queued": len(safe), "skipped": len(paths) - len(safe)})

        elif path == "/stop":
            r = subprocess.run(
                ["bash", NETPLAY_BROADCAST_SCRIPT, "stop"],
                capture_output=True, text=True
            )
            self.send_json({"stopped": r.returncode == 0})

        elif path == "/check-core":
            rom = data.get("rom", "")
            if not rom:
                self.send_json({"error": "rom required"}, 400)
                return
            r = subprocess.run(
                ["bash", CORE_CHECKER_SCRIPT, "check-fix", rom],
                capture_output=True, text=True
            )
            try:
                self.send_json(json.loads(r.stdout))
            except Exception:
                self.send_json({"output": r.stdout})

        elif path == "/download-rom":
            system = data.get("system", "")
            game   = data.get("game",   "")
            r = subprocess.run(
                ["bash", ROM_CHECKER_SCRIPT,
                 "download", system, game],
                capture_output=True, text=True
            )
            # Invalidate ROM finder index so next smart-join picks up new files
            if ROM_FINDER_AVAILABLE:
                invalidate_rom_index()
            try:
                self.send_json(json.loads(r.stdout))
            except Exception:
                self.send_json({"output": r.stdout})

        elif path == "/api/download-progress":
            key = data.get('key', 'download')
            download_progress[key] = data
            self.send_json({'ok': True})

        elif path == "/cancel-download":
            identifier = data.get("identifier", "").strip()
            if not identifier:
                self.send_json({"error": "identifier required"}, 400)
                return
            cancel_file = f"/tmp/netplay-cancel-{identifier}"
            try:
                with open(cancel_file, "w") as f:
                    f.write(identifier)
                self.send_json({"cancelling": True, "identifier": identifier})
            except Exception as e:
                self.send_json({"error": str(e)}, 500)

        elif path == "/api/launch":
            system = data.get('system', '')
            rom    = data.get('rom', '')
            if not system or not rom:
                self.send_json({'error': 'system and rom required'}, 400)
                return
            subprocess.Popen(['bash', NETPLAY_BROADCAST_SCRIPT, 'launch-and-broadcast', system, rom])
            self.send_json({'status': 'launching'})

        elif path == "/save-config":
            allowed = ("username", "max_ping", "discord_webhook",
                       "ra_username", "rgsx_api_key", "wan_enabled", "session_pin",
                       "panel_password", "idle_timeout_minutes")
            cfg = get_config()
            for k in allowed:
                if k in data:
                    cfg[k] = str(data[k])
            self._write_config(cfg)
            if wan_lobby:
                if data.get("wan_enabled") == "true":
                    wan_lobby.start()   # idempotent — ignored if already running
                    log("WAN lobby enabled from config save")
                elif data.get("wan_enabled") == "false":
                    wan_lobby.stop()
                    log("WAN lobby disabled from config save")
            self.send_json({"saved": True})

        else:
            self.send_json({"error": "Unknown endpoint"}, 404)

    def _shell_join(self, data: dict):
        """
        Standard join: validates fields, sanitises, passes remote_user + force
        to the shell script for history and core-mismatch handling.
        """
        required = ["host", "rom", "core"]
        missing  = [k for k in required if not data.get(k)]
        if missing:
            self.send_json({"error": f"Missing: {', '.join(missing)}"}, 400)
            return
        for k in required:
            v = data.get(k, "")
            if any(c in v for c in (";", "`", "$", "|", "&", ">", "<", "\n")):
                self.send_json({"error": f"Invalid chars in {k}"}, 400)
                return

        remote_user = data.get("remote_user", "")
        force       = "1" if data.get("force") else "0"
        script      = NETPLAY_BROADCAST_SCRIPT
        r = subprocess.run(
            ["bash", script, "join", data["host"], data["rom"], data["core"],
             remote_user, force],
            capture_output=True, text=True
        )
        self.send_json({"joined": r.returncode == 0, "output": r.stdout})

    def _handle_smart_join(self, data: dict):
        """
        One-button join flow:
          1. Fetch /session from host to get game name + core + system
          2. Fuzzy-search local ROM library for that game
          3. If no local ROM → return download instructions
          4. If core mismatch → auto-fix via core-checker.sh set
          5. Launch join with resolved rom path + core
        """
        host      = data.get("host", "")
        pin       = data.get("pin",  "").strip()
        mitm_ip   = data.get("mitm_ip", "").strip()
        mitm_port = str(data.get("mitm_port", "")).strip()
        connect_ip = mitm_ip if mitm_ip else host
        if not host:
            self.send_json({"error": "host required"}, 400)
            return

        # Step 1: query host session (include PIN if supplied)
        try:
            import urllib.request
            url = f"http://{host}:8765/session"
            if pin:
                url += f"?pin={pin}"
            with urllib.request.urlopen(url, timeout=4) as resp:
                remote_sess = json.loads(resp.read().decode())
        except Exception as e:
            self.send_json({"error": f"Could not reach host: {e}",
                            "smart_join": False})
            return

        if remote_sess.get("error") == "pin_required":
            self.send_json({"error": "pin_required", "smart_join": False}, 403)
            return

        remote_game         = remote_sess.get("game", "")
        remote_core         = remote_sess.get("core", "")
        remote_system       = remote_sess.get("system", "")
        remote_user         = remote_sess.get("broadcaster", "")
        host_local_players  = int(remote_sess.get("local_players", 1))

        if host_local_players > 1:
            log(f"Smart join: host has {host_local_players} local players — "
                f"remote clients auto-assigned to port {host_local_players + 1}+")

        if not remote_game:
            self.send_json({"error": "Host has no active session",
                            "smart_join": False})
            return

        log(f"Smart join: host={host} game='{remote_game}' core={remote_core}")

        # Step 2: fuzzy ROM search
        if not ROM_FINDER_AVAILABLE:
            self.send_json({
                "error":       "ROM search unavailable — reinstall Outbreak",
                "smart_join":  False,
                "remote_game": remote_game,
            })
            return

        match = find_rom(remote_game, remote_system)

        if not match:
            candidates = find_rom_candidates(remote_game, 3)
            # Queue download — the download worker thread will process it
            try:
                subprocess.run(
                    ["bash", ROM_CHECKER_SCRIPT, "download", remote_system, remote_game],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                    timeout=30)
                download_queued = True
            except Exception:
                download_queued = False
            self.send_json({
                "smart_join":      False,
                "needs_rom":       True,
                "download_queued": download_queued,
                "remote_game":     remote_game,
                "remote_core":     remote_core,
                "remote_system":   remote_system,
                "candidates":      candidates,
            })
            return

        rom_path   = match["path"]
        use_core   = remote_core or match["core"]
        use_system = match["system"]
        log(f"Smart join: matched '{match['name']}' "
            f"(score={match['score']}) → {rom_path}")

        # Step 3: if remote core differs from local recommendation, switch it
        if remote_core and remote_core != match["core"]:
            r = subprocess.run(
                ["bash", CORE_CHECKER_SCRIPT, "set", use_system, remote_core],
                capture_output=True, text=True
            )
            try:
                result = json.loads(r.stdout)
                if not result.get("success"):
                    self.send_json({
                        "smart_join":  False,
                        "needs_core":  True,
                        "remote_core": remote_core,
                        "rom_found":   rom_path,
                        "hint": (
                            f"Core '{remote_core}' is not installed. "
                            f"Run: batocera-store install libretro-{remote_core}"
                        ),
                    })
                    return
                log(f"Smart join: switched core to {remote_core}")
            except Exception:
                pass

        # Step 4: fetch host core options so client uses identical emulator settings
        core_opts_file = ""
        try:
            import urllib.request
            opts_url = f"http://{host}:8765/core-options"
            with urllib.request.urlopen(opts_url, timeout=3) as resp:
                opts_data = json.loads(resp.read().decode())
            core_opts = opts_data.get("options", "")
            if core_opts:
                core_opts_file = "/tmp/outbreak-core-options.opt"
                with open(core_opts_file, "w") as f:
                    f.write(core_opts)
                log(f"Core options fetched from host ({len(core_opts)} bytes) → {core_opts_file}")
        except Exception as e:
            log(f"Core options fetch skipped: {e}")

        # Step 5: execute join (core mismatch guard runs inside shell script)
        script = NETPLAY_BROADCAST_SCRIPT
        r      = subprocess.run(
            ["bash", script, "join", host, rom_path, use_core, remote_user, "0", connect_ip,
             mitm_port if mitm_port else "55435", core_opts_file],
            capture_output=True, text=True
        )

        self.send_json({
            "smart_join":         True,
            "joined":             r.returncode == 0,
            "rom":                rom_path,
            "core":               use_core,
            "game":               match["name"],
            "score":              match["score"],
            "remote_user":        remote_user,
            "host_local_players": host_local_players,
            "output":             r.stdout,
        })

    def _shell_action(self, action, data, required, extra=None):
        missing = [k for k in required if not data.get(k)]
        if missing:
            self.send_json({"error": f"Missing: {', '.join(missing)}"}, 400)
            return
        for k in required:
            v = data.get(k, "")
            if any(c in v for c in (";", "`", "$", "|", "&", ">", "<", "\n")):
                self.send_json({"error": f"Invalid chars in {k}"}, 400)
                return
        script = NETPLAY_BROADCAST_SCRIPT
        args   = [script, action] + [data[k] for k in required]
        args   = ["bash"] + args
        r      = subprocess.run(args, capture_output=True, text=True)
        key    = "started" if action == "broadcast" else "joined"
        result = {key: r.returncode == 0, "output": r.stdout}
        if extra:
            result.update(extra)
        self.send_json(result)

    @staticmethod
    def _write_config(cfg):
        os.makedirs(INSTALL_DIR, exist_ok=True)
        lines = ["# Batocera NetPlay Arcade Config\n"]
        for k, v in cfg.items():
            clean = str(v).replace("\r", " ").replace("\n", " ").strip()
            lines.append(f"{k}={clean}\n")
        _atomic_write_text(CONFIG_FILE, "".join(lines))


# ─── AUTO-UPDATE THREAD ──────────────────────────────────────────────────────
# Replaces the old bash _auto_update loop.  Lives inside the server so there
# is exactly ONE process responsible for checking, downloading, and restarting.
# After applying an update, the server replaces itself via os.execv (same PID,
# no orphan, no duplicate).

VERSION_STAMP = os.path.join(INSTALL_DIR, ".version")
REPO = "paulrenzi/ob-dist"
SETUP_SCRIPT = _script_path("setup.sh")

def _read_version():
    try:
        with open(VERSION_STAMP) as f:
            return f.read().strip()
    except Exception:
        return ""

def _auto_update_loop():
    """Background thread: check GitHub for new releases, apply, self-restart."""
    import shutil
    interval = 15  # first check after 15s, then every 6h
    while True:
        time.sleep(interval)
        interval = 21600  # 6 hours

        cfg = get_config()
        if cfg.get("auto_update", "true") == "false":
            log("[auto-update] Disabled via config — sleeping until next check")
            continue

        current = _read_version()
        gh_headers = {"User-Agent": "Outbreak/1.0"}

        try:
            import urllib.request
            req = urllib.request.Request(
                f"https://api.github.com/repos/{REPO}/releases/latest",
                headers=gh_headers)
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read())
                latest = data.get("tag_name", "")
        except Exception as e:
            log(f"[auto-update] Failed to check releases: {e}")
            continue

        if not latest:
            log("[auto-update] No release found — will retry")
            continue
        if latest == current:
            log(f"[auto-update] Already on {latest}")
            continue

        log(f"[auto-update] New release {latest} (installed: {current or 'unknown'}) — updating...")

        import tempfile as _tf
        tmp_dir = _tf.mkdtemp()
        tarball_url = f"https://github.com/{REPO}/releases/download/{latest}/outbreak-{latest}.tar.gz"
        tar_path = os.path.join(tmp_dir, "outbreak.tar.gz")

        try:
            req = urllib.request.Request(tarball_url, headers=gh_headers)
            with urllib.request.urlopen(req, timeout=120) as resp:
                with open(tar_path, "wb") as f:
                    f.write(resp.read())
        except Exception as e:
            log(f"[auto-update] Download failed: {e}")
            shutil.rmtree(tmp_dir, ignore_errors=True)
            continue

        try:
            import tarfile
            with tarfile.open(tar_path) as tf:
                tf.extractall(tmp_dir)
        except Exception as e:
            log(f"[auto-update] Extract failed: {e}")
            shutil.rmtree(tmp_dir, ignore_errors=True)
            continue

        # Find extracted directory (ob-dist tarballs extract as "Outbreak/")
        extracted = None
        for d in os.listdir(tmp_dir):
            if d.startswith("Outbreak") and os.path.isdir(os.path.join(tmp_dir, d)):
                extracted = os.path.join(tmp_dir, d)
                break
        if not extracted:
            log("[auto-update] No Outbreak directory found in tarball")
            shutil.rmtree(tmp_dir, ignore_errors=True)
            continue

        # Copy new files (preserve config.cfg)
        scripts_src = os.path.join(extracted, "scripts")
        ui_src = os.path.join(extracted, "ui")
        scripts_dst = os.path.join(INSTALL_DIR, "scripts")
        ui_dst = os.path.join(INSTALL_DIR, "ui")
        if os.path.isdir(scripts_src):
            for fn in os.listdir(scripts_src):
                if fn == "config.cfg":
                    continue
                src = os.path.join(scripts_src, fn)
                dst = os.path.join(scripts_dst, fn)
                if os.path.isfile(src):
                    shutil.copy2(src, dst)
        if os.path.isdir(ui_src):
            for root, dirs, files in os.walk(ui_src):
                rel = os.path.relpath(root, ui_src)
                dst_dir = os.path.join(ui_dst, rel)
                os.makedirs(dst_dir, exist_ok=True)
                for fn in files:
                    shutil.copy2(os.path.join(root, fn), os.path.join(dst_dir, fn))

        # chmod +x on scripts
        for fn in os.listdir(scripts_dst):
            fp = os.path.join(scripts_dst, fn)
            if fn.endswith(".sh") or fn == "service":
                os.chmod(fp, 0o755)

        shutil.rmtree(tmp_dir, ignore_errors=True)

        # Write version stamp
        _atomic_write_text(VERSION_STAMP, latest)
        log(f"[auto-update] Files updated to {latest}")

        # Run bash post-update (exit overrides, core channel, ES system, ports launcher)
        new_setup = os.path.join(scripts_dst, "setup.sh")
        try:
            subprocess.run(["bash", new_setup, "post-update", latest],
                           timeout=120, capture_output=True)
        except Exception as e:
            log(f"[auto-update] post-update warning: {e}")

        log(f"[auto-update] Restarting server via os.execv (same PID {os.getpid()})...")

        # Self-restart: replace this process with a fresh copy of ourselves.
        # Same PID, same PID file, no orphan, no duplicate.
        server_script = os.path.join(scripts_dst, "netplay-server.py")
        try:
            os.execv("/usr/bin/python3",
                     ["python3", server_script])
        except Exception as e:
            log(f"[auto-update] os.execv failed: {e} — server continues on old code")


def _boot_scan():
    """Run rom-checker.sh boot if the last scan is stale (>24h or ROM files changed)."""
    stamp = "/tmp/rom_scan_last_run"
    run_scan = True
    if os.path.exists(stamp):
        try:
            age = time.time() - os.path.getmtime(stamp)
            if age < 86400:
                # Check if any ROM files changed since stamp
                result = subprocess.run(
                    ["find", "/userdata/roms", "(", "-name", "*.zip", "-o", "-name", "*.7z", ")",
                     "-newer", stamp],
                    capture_output=True, text=True, timeout=10)
                if not result.stdout.strip():
                    run_scan = False
                    log("Skipping ROM scan — last scan < 24h old and no ROM files changed")
        except Exception:
            pass

    if run_scan:
        log("Starting boot ROM scan...")
        _boot_scan_active.set()
        try:
            subprocess.run(
                ["bash", ROM_CHECKER_SCRIPT, "boot"],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=3600)
        except subprocess.TimeoutExpired:
            log("Boot ROM scan timed out after 60 min")
        except Exception as e:
            log(f"Boot ROM scan error: {e}")
        finally:
            _boot_scan_active.clear()
        # Touch stamp after scan completes
        try:
            with open(stamp, "w") as f:
                f.write("")
        except Exception:
            pass


# ─── IDLE TIMEOUT WATCHDOG ────────────────────────────────────────────────────
# Automatically stops abandoned host sessions.  A session is "idle" when there
# are zero remote players connected.  After idle_timeout_minutes of continuous
# idle (default 8, 0 = disabled), the watchdog kills RetroArch and clears the
# session so the lobby listing disappears and the cabinet returns to ES.

_idle_since: float = 0.0          # epoch when remote player count last dropped to 0

def _idle_timeout_loop():
    """Background thread: auto-stop sessions with no remote players."""
    global _idle_since
    while True:
        time.sleep(30)
        try:
            cfg = get_config()
            timeout_min = int(cfg.get("idle_timeout_minutes", "8"))
            if timeout_min <= 0:
                continue  # disabled

            session = get_session()
            if not session or session.get("status") != "hosting":
                _idle_since = 0.0
                continue

            # Get live player count from LogWatcher
            np_state = log_watcher.get_state() if log_watcher else {}
            remote_players = 0
            if np_state.get("phase") not in (None, "idle"):
                # player_count includes the host; remote = total - local
                total = np_state.get("player_count", 0)
                local = session.get("local_players", 1)
                remote_players = max(0, total - local)

            now = time.time()
            if remote_players > 0:
                _idle_since = 0.0  # reset — someone is playing
                continue

            # No remote players — start or continue the idle clock
            if _idle_since == 0.0:
                _idle_since = now

            idle_seconds = now - _idle_since
            timeout_seconds = timeout_min * 60

            # Warn at 1 minute before timeout
            if timeout_seconds - idle_seconds <= 60 and timeout_seconds - idle_seconds > 30:
                game = session.get("game", "session")
                _es_notify(f"No players for {int(idle_seconds // 60)}m — stopping in 1 min")

            if idle_seconds >= timeout_seconds:
                game = session.get("game", "session")
                log(f"[idle-timeout] Stopping idle session: {game} "
                    f"(no remote players for {int(idle_seconds)}s)")
                _es_notify("Session stopped — no players joined")
                subprocess.run(
                    ["bash", NETPLAY_BROADCAST_SCRIPT, "stop"],
                    capture_output=True, text=True, timeout=15)
                _idle_since = 0.0

        except Exception as e:
            log(f"[idle-timeout] Error: {e}")


def _es_notify(msg):
    """Send a toast notification to EmulationStation."""
    try:
        import urllib.request
        req = urllib.request.Request(
            "http://127.0.0.1:1234/notify",
            data=msg.encode(),
            headers={"Content-Type": "text/plain"},
            method="POST")
        urllib.request.urlopen(req, timeout=2)
    except Exception:
        pass


# ─── MAIN ─────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import signal

    MASTER_PID = "/tmp/outbreak_master.pid"

    def _cleanup_and_exit(signum=None, frame=None):
        """Clean up PID file on exit. Called by SIGTERM/SIGINT."""
        try:
            os.unlink(MASTER_PID)
        except OSError:
            pass
        if wan_lobby:
            wan_lobby.stop()
        log(f"Server stopped (signal {signum})")
        os._exit(0)

    signal.signal(signal.SIGTERM, _cleanup_and_exit)
    signal.signal(signal.SIGINT, _cleanup_and_exit)

    # Write master PID — the server IS the master process.
    # boot.sh exec's into us, so our PID is the one Batocera tracks.
    with open(MASTER_PID, "w") as f:
        f.write(str(os.getpid()))
    # Compat: status() in boot.sh reads this
    with open("/tmp/netplay_server.pid", "w") as f:
        f.write(str(os.getpid()))

    os.makedirs(INSTALL_DIR, exist_ok=True)

    log(f"NetPlay Arcade v1.1 starting on :{PORT} (PID {os.getpid()})")
    log(f"Local IP: {get_local_ip()}")

    peer_discovery.start()
    log("LAN peer discovery started")

    if log_watcher:
        log_watcher.start()
        log("RetroArch log watcher started")

    if wan_lobby and get_config().get("wan_enabled", "false") == "true":
        wan_lobby.start()
        log("WAN lobby started")
    elif wan_lobby:
        log("WAN lobby disabled (set wan_enabled=true in config to re-enable)")

    # Boot scan: check if ROM library needs re-indexing (owned by server, not boot.sh)
    threading.Thread(target=_boot_scan, daemon=True, name="boot-scan").start()

    # Background ROM watcher: re-scans every 5 min and after any new download
    threading.Thread(target=_rom_watcher_loop, daemon=True, name="rom-watcher").start()
    log("ROM background watcher started")

    # Background download worker: processes queue when no session is active
    threading.Thread(target=_download_worker_loop, daemon=True, name="dl-worker").start()
    log("ROM download worker started")

    # Detect netplay sessions started via the built-in Batocera ES host flow
    # and register them with Outbreak so the WAN lobby can announce them.
    threading.Thread(target=_external_session_loop, daemon=True, name="es-host-detector").start()
    log("ES host session detector started")

    # SSE broadcaster: pushes status updates to connected /events clients
    threading.Thread(target=_sse_broadcaster_loop, daemon=True, name="sse-broadcaster").start()
    log("SSE broadcaster started")

    # Auto-update: checks GitHub for new releases, applies, self-restarts via os.execv
    threading.Thread(target=_auto_update_loop, daemon=True, name="auto-update").start()
    log("Auto-update thread started")

    # Idle timeout watchdog: auto-stops sessions with no remote players
    threading.Thread(target=_idle_timeout_loop, daemon=True, name="idle-timeout").start()
    log("Idle timeout watchdog started")

    # Notify ES that Outbreak is ready
    version = _read_version()
    _es_notify(f"Outbreak{' ' + version if version else ''} ready")

    server = ThreadingHTTPServer(("0.0.0.0", PORT), NetPlayHandler)
    log(f"ThreadingHTTPServer ready — http://0.0.0.0:{PORT}/ui")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        _cleanup_and_exit()
