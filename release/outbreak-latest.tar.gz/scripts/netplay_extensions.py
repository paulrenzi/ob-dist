#!/usr/bin/env python3
"""
netplay-extensions.py
─────────────────────
Three focused subsystems that bolt onto netplay-server.py:

  1. WanLobby   — registers sessions with lobby.libretro.com (/add),
                  polls /list for WAN rooms, merges with LAN peers.

  2. LogWatcher — tails RetroArch's stderr log from Batocera's known
                  path (/userdata/system/logs/es_launch_stderr.log),
                  parses [netplay] lines to track connected players
                  and session state in real-time.

  3. GamepadMapper — reference mapping table for xinput (standard
                  gamepad API layout) used by the browser UI.

Import and instantiate from netplay-server.py:
    from netplay_extensions import WanLobby, LogWatcher
"""

import json
import os
import re
import select
import socket
import subprocess
import threading
import time
import urllib.parse
import urllib.request
from typing import Optional

# ─── PATHS ────────────────────────────────────────────────────────────────────
# RetroArch stdout ends up in es_launch_stderr.log on Batocera because ES
# captures both streams there.  Confirmed at:
# https://wiki.batocera.org/troubleshooting
RA_LOG_PRIMARY   = "/userdata/system/logs/es_launch_stderr.log"
RA_LOG_SECONDARY = "/userdata/system/logs/es_launch_stdout.log"
# RetroArch also writes its own log when --verbose is set, to:
RA_LOG_VERBOSE   = "/tmp/retroarch.log"

LOBBY_LIST_URL  = "http://lobby.libretro.com/list/"
LOBBY_ADD_URL   = "http://lobby.libretro.com/add/"

LOG_FILE = "/tmp/netplay-arcade.log"


def _log(msg):
    ts = time.strftime("%H:%M:%S")
    line = f"[{ts}] EXT: {msg}\n"
    with open(LOG_FILE, "a") as f:
        f.write(line)


# ═══════════════════════════════════════════════════════════════════════════════
# 1.  WAN LOBBY
# ═══════════════════════════════════════════════════════════════════════════════

class WanLobby:
    """
    Handles two-way communication with lobby.libretro.com.

    REGISTRATION (host side)
    ─────────────────────────
    RetroArch itself POSTs to /add/ every 10 s when publicly_announce_netplay
    is true.  We don't duplicate that — instead, when the user has NOT set
    publicly_announce_netplay in retroarchcustom.cfg, we register on their
    behalf using the same field set RetroArch uses, derived entirely from
    data already available on disk in Batocera.

    The lobby response is newline-delimited key=value:
        status=OK
        id=354444
        username=…
        core_name=…
        …

    DISCOVERY (client side)
    ────────────────────────
    GET http://lobby.libretro.com/list/ returns a JSON array.
    Each element has the same fields as above.  We cache this list and
    expose it via /wan-peers so the UI can show LAN + WAN in one panel.

    Source of field values on Batocera
    ────────────────────────────────────
    username        → config.cfg  username
    ip              → public IP via checkip service (stun-free)
    port            → 55435 (default) or from retroarchcustom.cfg
    core_name       → session_file "core" field
    core_version    → scraped from /usr/lib/libretro/<core>.so strings or
                      the retroarch --features output, fallback "0.0"
    game_name       → session_file "game" field
    game_crc        → md5/crc of ROM, cached at broadcast time
    retroarch_version → `retroarch --version` stdout first line
    frontend        → "batocera linux"
    has_password    → 0 (we don't support passwords yet)
    """

    ANNOUNCE_INTERVAL = 25   # seconds between keep-alive POSTs to lobby
    POLL_INTERVAL     = 30   # seconds between full list refreshes
    PING_TIMEOUT      = 2    # seconds for per-WAN-peer ping

    def __init__(self, config_loader, session_getter, log_watcher=None):
        """
        config_loader  : callable → dict with keys username, max_ping …
        session_getter : callable → dict or None (current session state)
        log_watcher    : optional LogWatcher instance for relay IP detection
        """
        self._config       = config_loader
        self._session      = session_getter
        self._log_watcher  = log_watcher
        self._wan_rooms: list  = []
        self._lobby_id: Optional[int] = None
        self._running = False
        self._started = False   # guards against duplicate thread pairs on repeated start()
        self._lock = threading.Lock()
        self._ra_version: Optional[str] = None

    # ── PUBLIC API ────────────────────────────────────────────────────────────

    def start(self):
        with self._lock:
            if self._started:
                _log("WanLobby.start() called while already running — ignored")
                return
            self._running = True
            self._started = True
        threading.Thread(target=self._announce_loop, daemon=True, name="lobby-announce").start()
        threading.Thread(target=self._poll_loop,     daemon=True, name="lobby-poll").start()
        _log("WanLobby started")

    def stop(self):
        with self._lock:
            self._running = False
            self._started = False
        self._deregister()

    def get_wan_rooms(self, max_ping: int = 40) -> list:
        """Return cached WAN rooms, each annotated with measured ping_ms."""
        with self._lock:
            return list(self._wan_rooms)

    def get_lobby_id(self) -> Optional[int]:
        with self._lock:
            return self._lobby_id

    # ── RETROARCH VERSION ────────────────────────────────────────────────────

    def _get_ra_version(self) -> str:
        if self._ra_version:
            return self._ra_version
        try:
            r = subprocess.run(
                ["/usr/bin/retroarch", "--version"],
                capture_output=True, text=True, timeout=3
            )
            # "RetroArch 1.19.1 (Git 9a3fc23)"
            m = re.search(r'RetroArch\s+([\d.]+)', r.stdout + r.stderr)
            if m:
                self._ra_version = m.group(1)
                return self._ra_version
        except Exception as e:
            _log(f"RA version check failed: {e}")
        return "0.0.0"

    # ── PUBLIC IP ────────────────────────────────────────────────────────────

    @staticmethod
    def _get_public_ip() -> str:
        """
        Uses checkip.amazonaws.com — plain text, no JS, reliable.
        Falls back to local IP if offline.
        """
        for url in [
            "https://checkip.amazonaws.com",
            "https://api4.my-ip.io/ip",
            "https://ipv4.icanhazip.com",
        ]:
            try:
                req = urllib.request.Request(url, headers={"User-Agent": "retroarch"})
                with urllib.request.urlopen(req, timeout=5) as resp:
                    ip = resp.read().decode().strip()
                    if re.match(r'^\d+\.\d+\.\d+\.\d+$', ip):
                        return ip
            except Exception:
                pass
        # Offline fallback: LAN IP
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "127.0.0.1"

    # ── GAME CRC ─────────────────────────────────────────────────────────────

    @staticmethod
    def _get_game_crc(rom_path: str) -> str:
        """
        RetroArch uses CRC32 of the ROM for lobby matching.
        We compute it from the file; for ZIPs we hash the inner ROM.
        Falls back to MD5[:8].upper() if zlib is unavailable.
        """
        import zlib
        try:
            ext = rom_path.rsplit(".", 1)[-1].lower()
            if ext == "zip":
                import zipfile
                with zipfile.ZipFile(rom_path) as z:
                    names = [n for n in z.namelist()
                             if not n.endswith("/")]
                    if names:
                        with z.open(names[0]) as f:
                            data = f.read()
                        crc = zlib.crc32(data) & 0xFFFFFFFF
                        return f"{crc:08X}"
            with open(rom_path, "rb") as f:
                data = f.read()
            crc = zlib.crc32(data) & 0xFFFFFFFF
            return f"{crc:08X}"
        except Exception as e:
            _log(f"CRC error for {rom_path}: {e}")
            return "00000000"

    # ── CORE VERSION ─────────────────────────────────────────────────────────

    @staticmethod
    def _get_core_version(core_name: str) -> str:
        """
        Try to extract version from the .so's embedded string.
        Pattern: RetroArch embeds "core_version" near "core_name" in .so.
        Fallback: parse the core's info file.
        """
        for so_path in [
            f"/usr/lib/libretro/{core_name}_libretro.so",
            f"/usr/lib/libretro/{core_name}.so",
        ]:
            if not os.path.exists(so_path):
                continue
            try:
                r = subprocess.run(
                    ["strings", so_path],
                    capture_output=True, text=True, timeout=5
                )
                for line in r.stdout.split("\n"):
                    if re.match(r'^\d+\.\d+', line):
                        return line.strip()[:16]
            except Exception:
                pass
        # Try info file
        info = f"/usr/share/libretro/info/{core_name}_libretro.info"
        if os.path.exists(info):
            try:
                with open(info) as f:
                    for line in f:
                        if line.startswith("core_version"):
                            return line.split("=", 1)[1].strip().strip('"')[:16]
            except Exception:
                pass
        return "0.0"

    # ── REGISTER WITH LOBBY ──────────────────────────────────────────────────

    def _register(self, session: dict, config: dict) -> Optional[int]:
        """
        POST to lobby.libretro.com/add/ with the same fields RetroArch uses.
        Returns the lobby room id on success, None on failure.

        The lobby accepts POST with Content-Type application/x-www-form-urlencoded.
        Fields documented in libretro-netplay-registry and confirmed via
        live lobby debug output (issue #2 netplay-lobby-server-go).
        """
        rom   = session.get("rom", "")
        core  = session.get("core", "")
        game  = session.get("game", "")
        port  = session.get("port", 55435)

        public_ip    = self._get_public_ip()
        core_version = self._get_core_version(core)
        game_crc     = self._get_game_crc(rom) if rom else "00000000"
        ra_version   = self._get_ra_version()

        # Append Outbreak marker so WAN lobby filtering can distinguish our
        # sessions from the thousands of unrelated public RetroArch rooms.
        tagged_game = f"{game} [OB]" if game else "[OB]"

        fields = {
            "username":            config.get("username", socket.gethostname()),
            "ip":                  public_ip,
            "port":                str(port),
            "core_name":           core,
            "core_version":        core_version,
            "game_name":           tagged_game,
            "game_crc":            game_crc,
            "retroarch_version":   ra_version,
            "frontend":            "batocera linux",
            "host_method":         "0",   # 0=direct, 1=mitm relay; overridden below if relay active
            "has_password":        "0",
            "has_spectate_password": "0",
            "subsystem_name":      "N/A",
            "mitm_ip":             "",
            "mitm_port":           "0",
        }

        if self._log_watcher:
            lw_state   = self._log_watcher.get_state()
            relay_ip   = lw_state.get("relay_ip")
            relay_port = lw_state.get("relay_port")
            if relay_ip and relay_port:
                fields["host_method"] = "1"
                fields["mitm_ip"]     = relay_ip
                fields["mitm_port"]   = str(relay_port)

        data = urllib.parse.urlencode(fields).encode()
        try:
            req = urllib.request.Request(
                LOBBY_ADD_URL,
                data=data,
                headers={
                    "Content-Type": "application/x-www-form-urlencoded",
                    "User-Agent":   f"RetroArch/{ra_version}",
                }
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                body = resp.read().decode()

            # Parse newline-delimited key=value response
            result = {}
            for line in body.strip().split("\n"):
                if "=" in line:
                    k, v = line.split("=", 1)
                    result[k.strip()] = v.strip()

            if result.get("status") == "OK":
                lobby_id = int(result.get("id", 0))
                _log(f"Registered with lobby: id={lobby_id} game={game}")
                return lobby_id
            else:
                _log(f"Lobby registration failed: {result}")
        except Exception as e:
            _log(f"Lobby POST error: {e}")
        return None

    def _deregister(self):
        """
        There is no explicit DELETE endpoint — lobbies expire naturally
        when keep-alive POSTs stop.  We simply stop announcing.
        """
        with self._lock:
            self._lobby_id = None
        _log("Lobby registration stopped (will expire)")

    # ── ANNOUNCE LOOP ────────────────────────────────────────────────────────

    def _announce_loop(self):
        """Re-register every ANNOUNCE_INTERVAL while a session is active."""
        while self._running:
            session = self._session()
            if session and session.get("status") == "hosting":
                config = self._config()
                # Only register if user hasn't set publicly_announce_netplay
                # in retroarchcustom.cfg (avoid double-posting)
                if not self._ra_already_announcing():
                    lobby_id = self._register(session, config)
                    with self._lock:
                        self._lobby_id = lobby_id
                else:
                    _log("RA is self-announcing; skipping external registration")
            else:
                # No active session — ensure we don't hold a stale id
                with self._lock:
                    self._lobby_id = None

            time.sleep(self.ANNOUNCE_INTERVAL)

    @staticmethod
    def _ra_already_announcing() -> bool:
        """
        Check retroarchcustom.cfg for netplay_public_announce = "true".
        Batocera writes RA config to /userdata/system/configs/retroarch/.
        """
        cfg_paths = [
            "/userdata/system/configs/retroarch/retroarchcustom.cfg",
            "/userdata/system/configs/retroarch/retroarch.cfg",
        ]
        for path in cfg_paths:
            try:
                with open(path) as f:
                    for line in f:
                        stripped = line.strip()
                        # Skip comments
                        if stripped.startswith("#"):
                            continue
                        if "=" not in stripped:
                            continue
                        key, _, val = stripped.partition("=")
                        if key.strip() == "netplay_public_announce" \
                                and val.strip().strip('"') == "true":
                            return True
            except Exception:
                pass
        return False

    # ── POLL LOOP ────────────────────────────────────────────────────────────

    def _poll_loop(self):
        """Fetch full WAN room list periodically and cache it."""
        while self._running:
            self._refresh_wan_rooms()
            time.sleep(self.POLL_INTERVAL)

    def _refresh_wan_rooms(self):
        """
        GET /list/ returns a JSON array of room objects.
        We annotate each with ping_ms (async, best-effort).
        """
        try:
            req = urllib.request.Request(
                LOBBY_LIST_URL,
                headers={"User-Agent": "retroarch", "Accept": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                rooms = json.loads(resp.read().decode())

            # lobby.libretro.com wraps each entry: {"fields": {...}}
            # Unwrap before filtering so field access works correctly.
            # Only show Outbreak-registered sessions (tagged with " [OB]" suffix)
            # to avoid surfacing hundreds of unrelated public RetroArch lobbies.
            annotated = []
            for raw in rooms:
                room = dict(raw.get("fields", raw))  # unwrap fields wrapper
                if not str(room.get("game_name", "")).endswith(" [OB]"):
                    continue
                # Strip the marker before exposing to the UI
                room["game_name"] = room["game_name"][:-5].strip()
                room["source"] = "wan"
                room["ping_ms"] = None   # will be filled async
                annotated.append(room)

            # Fire off background pings
            def _ping_rooms(rooms_list):
                for r in rooms_list:
                    ip = r.get("ip") or r.get("mitm_ip", "")
                    if not ip:
                        r["ping_ms"] = 999
                        continue
                    try:
                        res = subprocess.run(
                            ["ping", "-c", "1", "-W", "2", ip],
                            capture_output=True, text=True, timeout=3
                        )
                        for line in res.stdout.split("\n"):
                            if "avg" in line or "rtt" in line:
                                parts = line.split("/")
                                if len(parts) >= 5:
                                    r["ping_ms"] = int(float(parts[4]))
                                    break
                        else:
                            r["ping_ms"] = 999
                    except Exception:
                        r["ping_ms"] = 999

            t = threading.Thread(target=_ping_rooms, args=(annotated,), daemon=True)
            t.start()

            with self._lock:
                prev = len(self._wan_rooms)
                self._wan_rooms = annotated

            # Only log when rooms are present or count changes
            n = len(annotated)
            if n > 0 or n != prev:
                _log(f"WAN lobby: {n} rooms fetched")

        except Exception as e:
            _log(f"WAN poll error: {e}")


# ═══════════════════════════════════════════════════════════════════════════════
# 2.  LOG WATCHER  (player count / session state from RetroArch log)
# ═══════════════════════════════════════════════════════════════════════════════

class LogWatcher:
    """
    Tails the RetroArch log file emitted by Batocera via es_launch_stderr.log.
    Parses [netplay] lines to track:
      - connected players and their slots
      - disconnects
      - session lifecycle (announcing → waiting → running → ended)

    Log patterns confirmed from:
      grimore.org/retroarch/announcing_netplay_activity_using_iot
      and live RetroArch 1.9.x - 1.19.x output.

    The log is written by ES by capturing RetroArch's stderr. Batocera
    rotates it at each game launch (new process → new stderr capture).
    We handle rotation by re-opening the file if the inode changes.

    RetroArch log format:
        [INFO] [netplay] Waiting for client
        [INFO] [netplay] PlayerName has joined as player 2
        [INFO] [netplay] PlayerName has disconnected
        [INFO] [netplay] You have joined as player 1
        [INFO] [netplay] announcing netplay game "Game (Region)" with CRC ...
        [INFO] [netplay] Netplay is not initialized
    """

    # Compiled patterns
    _PATTERNS = {
        "announcing":      re.compile(
            r'\[INFO\].*\[netplay\] announcing netplay game\s+"(.+?)"\s+with\s+CRC\s+([0-9A-Fa-f]+)',
            re.IGNORECASE
        ),
        "waiting":         re.compile(
            r'\[INFO\].*\[netplay\] Waiting for client',
            re.IGNORECASE
        ),
        "player_joined":   re.compile(
            r'\[INFO\].*\[netplay\] (\S+) has joined as player (\d+)',
            re.IGNORECASE
        ),
        "player_left":     re.compile(
            r'\[INFO\].*\[netplay\] (\S+) has disconnected',
            re.IGNORECASE
        ),
        "you_joined":      re.compile(
            r'\[INFO\].*\[netplay\] You have joined as player (\d+)',
            re.IGNORECASE
        ),
        "connecting":      re.compile(
            r'\[INFO\].*\[netplay\] Connecting to netplay host',
            re.IGNORECASE
        ),
        "not_initialized": re.compile(
            r'\[INFO\].*\[netplay\] Netplay is not initialized',
            re.IGNORECASE
        ),
        "desync":          re.compile(
            r'\[INFO\].*\[netplay\] Desyncing',
            re.IGNORECASE
        ),
        "relay":           re.compile(
            r'\[INFO\].*\[netplay\].*relay\s+server\s+([\d.]+):(\d+)',
            re.IGNORECASE
        ),
    }

    def __init__(self):
        self._state: dict = {
            "phase":        "idle",      # idle|announcing|waiting|playing|client
            "game_name":    None,        # set when RetroArch announces a netplay game
            "players":      {},          # slot → username
            "player_count": 0,
            "max_players":  2,           # RetroArch default; could be >2
            "game_crc":     None,
            "relay_ip":     None,
            "relay_port":   None,
            "last_event":   None,
            "events":       [],          # ring buffer, last 20 events
        }
        self._running = False
        self._lock = threading.Lock()

    def start(self):
        self._running = True
        threading.Thread(target=self._tail_loop, daemon=True, name="log-watcher").start()
        _log("LogWatcher started")

    def get_state(self) -> dict:
        with self._lock:
            return dict(self._state)

    # ── TAIL LOOP ─────────────────────────────────────────────────────────────

    def _find_log(self) -> Optional[str]:
        """Return path to the most recently modified eligible log file."""
        candidates = [RA_LOG_PRIMARY, RA_LOG_SECONDARY, RA_LOG_VERBOSE]
        best = None
        best_mtime = 0
        for path in candidates:
            if os.path.exists(path):
                mtime = os.path.getmtime(path)
                if mtime > best_mtime:
                    best_mtime = mtime
                    best = path
        return best

    def _tail_loop(self):
        """
        Robust tail implementation without inotify dependency.
        - Detects file rotation by comparing inode.
        - Falls back to polling every 0.5 s.
        - Seeks to end of file on open (don't replay history).
        """
        log_path = None
        log_inode = None
        fh = None
        pos = 0

        while self._running:
            # Find or re-find the log
            current_path = self._find_log()

            if current_path != log_path:
                # New log file (game launched or path changed)
                if fh:
                    fh.close()
                log_path = current_path
                if not log_path:
                    time.sleep(1)
                    continue
                try:
                    fh = open(log_path, "r", encoding="utf-8", errors="replace")
                    fh.seek(0, 2)    # Seek to end — don't replay old history
                    log_inode = os.stat(log_path).st_ino
                    _log(f"Tailing: {log_path}")
                except Exception as e:
                    _log(f"Cannot open log {log_path}: {e}")
                    fh = None
                    time.sleep(2)
                    continue

            # Detect rotation (new inode = new file)
            try:
                current_inode = os.stat(log_path).st_ino
                if current_inode != log_inode:
                    _log("Log rotated, reopening")
                    fh.close()
                    fh = open(log_path, "r", encoding="utf-8", errors="replace")
                    log_inode = current_inode
            except Exception:
                pass

            # Read new lines
            if fh:
                try:
                    for line in fh:
                        self._parse_line(line)
                except Exception as e:
                    _log(f"Log read error: {e}")

            time.sleep(0.5)

    # ── LINE PARSER ───────────────────────────────────────────────────────────

    def _parse_line(self, line: str):
        """Match line against all patterns and update state."""
        with self._lock:
            state = self._state

            for event_name, pattern in self._PATTERNS.items():
                m = pattern.search(line)
                if not m:
                    continue

                ts = time.strftime("%H:%M:%S")

                if event_name == "announcing":
                    game_name, crc = m.group(1), m.group(2).upper()
                    state["phase"]     = "announcing"
                    state["game_name"] = game_name
                    state["game_crc"]  = crc
                    state["players"]   = {}
                    state["player_count"] = 0
                    state["last_event"] = f"{ts} Announcing: {game_name}"
                    self._push_event(state, "announce", {"game": game_name, "crc": crc})

                elif event_name == "waiting":
                    state["phase"] = "waiting"
                    state["last_event"] = f"{ts} Waiting for players…"
                    self._push_event(state, "waiting", {})

                elif event_name == "player_joined":
                    username, slot = m.group(1), int(m.group(2))
                    state["players"][slot] = username
                    state["player_count"] = len(state["players"])
                    state["phase"] = "playing"
                    state["last_event"] = f"{ts} {username} joined (P{slot})"
                    self._push_event(state, "join", {"username": username, "slot": slot})

                elif event_name == "player_left":
                    username = m.group(1)
                    # Remove from any slot
                    state["players"] = {
                        slot: u for slot, u in state["players"].items()
                        if u != username
                    }
                    state["player_count"] = len(state["players"])
                    if not state["players"]:
                        state["phase"] = "waiting"
                    state["last_event"] = f"{ts} {username} disconnected"
                    self._push_event(state, "leave", {"username": username})

                elif event_name == "you_joined":
                    slot = int(m.group(1))
                    state["phase"] = "client"
                    state["last_event"] = f"{ts} You joined as P{slot}"
                    self._push_event(state, "self_join", {"slot": slot})

                elif event_name == "connecting":
                    state["phase"] = "connecting"
                    state["last_event"] = f"{ts} Connecting…"

                elif event_name == "not_initialized":
                    state["phase"]     = "idle"
                    state["game_name"] = None
                    state["players"]   = {}
                    state["player_count"] = 0
                    state["last_event"] = f"{ts} Netplay ended"
                    self._push_event(state, "end", {})

                elif event_name == "desync":
                    state["last_event"] = f"{ts} ⚠ Desync detected"
                    self._push_event(state, "desync", {})

                elif event_name == "relay":
                    state["relay_ip"]   = m.group(1)
                    state["relay_port"] = int(m.group(2))

                break   # only first match per line

    @staticmethod
    def _push_event(state: dict, kind: str, data: dict):
        """Append to ring-buffer of last 20 events."""
        state["events"].append({
            "kind": kind,
            "data": data,
            "ts":   time.strftime("%H:%M:%S"),
        })
        if len(state["events"]) > 20:
            state["events"].pop(0)


# ═══════════════════════════════════════════════════════════════════════════════
# 3.  GAMEPAD MAPPER  (xinput / standard layout reference for browser UI)
# ═══════════════════════════════════════════════════════════════════════════════

# This is not a runtime class — it's the authoritative mapping table that the
# browser UI JavaScript imports as a static JSON blob from /gamepad-map.
#
# The W3C Gamepad API "standard" mapping maps xinput exactly:
#   https://www.w3.org/TR/gamepad/#dfn-standard-gamepad-layout
#
# When navigator.getGamepads()[n].mapping === "standard", these indices apply.
# Xbox controllers on Linux via xpad/hid-microsoft report mapping:"standard".
#
# Actions are defined for the NetPlay Arcade UI.

XINPUT_MAP = {
    "mapping": "standard",
    "note": "W3C Standard Gamepad = XInput layout. Xbox controllers on Linux via xpad/hid-microsoft.",
    "buttons": {
        0:  {"name": "A",            "action": "confirm"},
        1:  {"name": "B",            "action": "cancel_back"},
        2:  {"name": "X",            "action": "check_core"},
        3:  {"name": "Y",            "action": "toggle_wan_filter"},
        4:  {"name": "LB",           "action": "prev_peer"},
        5:  {"name": "RB",           "action": "next_peer"},
        6:  {"name": "LT",           "action": None},
        7:  {"name": "RT",           "action": None},
        8:  {"name": "Select/Back",  "action": "open_config"},
        9:  {"name": "Start",        "action": "broadcast"},
        10: {"name": "L3",           "action": None},
        11: {"name": "R3",           "action": None},
        12: {"name": "DPad Up",      "action": "cursor_up"},
        13: {"name": "DPad Down",    "action": "cursor_down"},
        14: {"name": "DPad Left",    "action": "cursor_left"},
        15: {"name": "DPad Right",   "action": "cursor_right"},
        16: {"name": "Guide/Home",   "action": None},
    },
    "axes": {
        # [0]=LX  [1]=LY  [2]=RX  [3]=RY
        # Values range -1.0 to +1.0; threshold 0.5 for digital actions
        0: {"name": "Left Stick X",  "action_neg": "cursor_left",  "action_pos": "cursor_right"},
        1: {"name": "Left Stick Y",  "action_neg": "cursor_up",    "action_pos": "cursor_down"},
        2: {"name": "Right Stick X", "action_neg": None,           "action_pos": None},
        3: {"name": "Right Stick Y", "action_neg": None,           "action_pos": None},
    },
    "combos": {
        # Chord shortcuts — checked before individual buttons
        # Format: sorted list of button indices → action
        "start+A":     {"buttons": [0, 9],  "action": "broadcast"},
        "start+B":     {"buttons": [1, 9],  "action": "stop_session"},
        "LB+RB":       {"buttons": [4, 5],  "action": "join_selected"},
    },
    "ui_actions": {
        # Maps action names to their descriptions for the help overlay
        "broadcast":        "Start/announce a netplay session",
        "join_selected":    "Join the highlighted peer's session (LB+RB)",
        "stop_session":     "Stop current session (Start+B)",
        "confirm":          "Select / confirm",
        "cancel_back":      "Cancel / go back",
        "cursor_up":        "Move selection up",
        "cursor_down":      "Move selection down",
        "prev_peer":        "Previous peer in list",
        "next_peer":        "Next peer in list",
        "check_core":       "Check core compatibility for selected peer",
        "open_config":      "Open settings panel",
        "toggle_wan_filter":"Toggle LAN-only / LAN+WAN view",
    }
}


def get_gamepad_map() -> dict:
    """Return the xinput mapping dict for the /gamepad-map endpoint."""
    return XINPUT_MAP
