#!/bin/bash
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
IMAGE_TAG="${IMAGE_TAG:-umbrellaarcades-installer-smoke}"

log() {
    printf '[installer-smoke] %s\n' "$1"
}

log "Building ${IMAGE_TAG}"
docker build -t "$IMAGE_TAG" "$REPO_ROOT" >/dev/null

log "Running installer validation in a clean container"
docker run --rm -i --entrypoint bash "$IMAGE_TAG" <<'EOF'
set -euo pipefail

mkdir -p /usr/lib/libretro /usr/share/libretro/info
printf "fake-snes9x-core" > /usr/lib/libretro/snes9x_libretro.so
cat > /usr/share/libretro/info/snes9x_libretro.info <<'INFOEOF'
display_version = "1.61"
corename = "Snes9x"
INFOEOF

bash /app/scripts/boot.sh install >/tmp/install.log
bash /app/scripts/boot.sh install >/tmp/install-rerun.log

test -x /userdata/system/netplay-arcade/scripts/boot.sh
test -x /userdata/system/netplay-arcade/scripts/config-parser.sh
test -x /userdata/system/netplay-arcade/scripts/core-checker.sh
test -x /userdata/system/netplay-arcade/scripts/netplay-broadcast.sh
test -x /userdata/system/netplay-arcade/scripts/netplay-cores.sh
test -x /userdata/system/netplay-arcade/scripts/rom-checker.sh
test -f /userdata/system/netplay-arcade/ui/index.html
test -x /userdata/system/emulationstation/resources/services/netplay-arcade.sh

count="$(grep -F -c "/userdata/system/netplay-arcade/scripts/boot.sh boot &" /userdata/system/custom.sh)"
[ "$count" -eq 1 ]

python3 - <<'PYEOF'
import json
from pathlib import Path

install_dir = Path("/userdata/system/netplay-arcade")
config_text = (install_dir / "config.cfg").read_text()
for line in (
    "username=",
    "max_ping=40",
    "discord_webhook=",
    "ra_username=",
    "rgsx_api_key=",
    "wan_enabled=false",
    "retroarch_bin=/usr/bin/retroarch",
):
    assert line in config_text, f"missing config line: {line}"

manifest = json.loads((install_dir / "cores" / "manifest.json").read_text())
assert manifest["channel"] == "stable-1"
assert "snes9x" in manifest["cores"]
assert manifest["cores"]["snes9x"]["display_version"] == "1.61"
assert manifest["cores"]["snes9x"]["source"] == "system"

compat = json.loads((install_dir / "core_compat.json").read_text())
assert compat["snes"]["recommended"] == "snes9x"
assert "snes9x" in compat["snes"]["installed"]
PYEOF
EOF

log "Installer smoke test passed"
