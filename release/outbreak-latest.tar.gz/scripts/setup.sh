#!/bin/bash
# =============================================================================
# Batocera NetPlay Arcade - Setup & Install Helpers
# Pure setup work: no process management, no daemon loops.
# Called by boot.sh (pre-server) and netplay-server.py (post-update, install).
# =============================================================================

INSTALL_DIR="/userdata/system/netplay-arcade"
SCRIPTS_DIR="$INSTALL_DIR/scripts"
UI_DIR="$INSTALL_DIR/ui"
CONFIG_FILE="$INSTALL_DIR/config.cfg"
VERSION_STAMP="$INSTALL_DIR/.version"   # tracks the installed release tag
REPO="paulrenzi/ob-dist"

# Load config (GH_TOKEN used only for core channel downloads from private repo)
. "$SCRIPTS_DIR/config-parser.sh"
load_netplay_config "$CONFIG_FILE"
GH_AUTH=()
[ -n "${GH_TOKEN:-}" ] && GH_AUTH=(-H "Authorization: token $GH_TOKEN")

# ─── ES NOTIFICATION / WINDOW HELPERS ────────────────────────────────────────
_es_notify() {
    local msg="$1"
    curl -s --max-time 2 -X POST \
        -H "Content-Type: text/plain" \
        -d "$msg" \
        http://127.0.0.1:1234/notify >/dev/null 2>&1
    local _rc=$?
    echo "[es-notify] rc=$_rc msg=$msg" >> "$INSTALL_DIR/logs/server.log" 2>/dev/null || true
    return 0
}

_es_show() {
    [ -p /tmp/es-resume.fifo ] && \
        { echo "resume" > /tmp/es-resume.fifo & } 2>/dev/null
    return 0
}

# ─── PER-CORE NETPLAY OVERRIDES ─────────────────────────────────────────────
# Configgen wipes retroarchcustom.cfg every launch. Per-core override files
# at config/<CoreName>/<CoreName>.cfg load AFTER retroarchcustom.cfg and are
# the ONLY place settings survive configgen's regeneration cycle.
# These settings are safe defaults for non-netplay too.
CANONICAL_CORES=(
    "FinalBurn Neo" "FCEUmm" "Flycast" "Gambatte" "Genesis Plus GX"
    "gpSP" "MAME 2003-Plus" "Beetle NeoPop" "Beetle PSX"
    "Beetle SuperGrafx" "Mesen" "mGBA" "Nestopia" "PCSX-ReARMed"
    "PicoDrive" "Snes9x" "Snes9x 2010" "Stella"
)

# Canonical RA settings written to every per-core override file.
# Keys listed here are forcibly set; any existing value is replaced.
_CANONICAL_RA_OVERRIDES='input_exit_emulator_btn = "7"
video_threaded = "false"
video_vsync = "true"
video_swap_interval = "1"
video_hard_gpu_sync = "true"
video_hard_gpu_sync_frames = "0"
video_frame_delay = "0"
video_frame_delay_auto = "false"
audio_sync = "true"
run_ahead_enabled = "false"
run_ahead_frames = "0"
run_ahead_secondary_instance = "false"
preemptive_frames = "0"
rewind_enable = "false"
savestate_auto_save = "false"
savestate_auto_load = "false"
cheevos_enable = "false"
netplay_public_announce = "false"
notification_show_config_override_load = "false"'

_ensure_exit_overrides() {
    local _ra_cfg_dir="/userdata/system/configs/retroarch/config"
    local _core_name _cfg_dir _cfg_file _key _line
    for _core_name in "${CANONICAL_CORES[@]}"; do
        _cfg_dir="$_ra_cfg_dir/$_core_name"
        _cfg_file="$_cfg_dir/$_core_name.cfg"
        mkdir -p "$_cfg_dir"
        [ -f "$_cfg_file" ] || touch "$_cfg_file"
        while IFS= read -r _line; do
            [ -z "$_line" ] && continue
            _key="${_line%% =*}"
            # Remove any existing line for this key, then append canonical value
            sed -i "/^${_key} /d" "$_cfg_file" 2>/dev/null
            echo "$_line" >> "$_cfg_file"
        done <<< "$_CANONICAL_RA_OVERRIDES"
    done

    # ── FBNeo core options — prevent desync from mismatched emulation settings ──
    # Every option here affects emulation determinism. Mismatches between host
    # and client cause rollback state divergence → desync → disconnect.
    local _core_opts="/userdata/system/configs/retroarch/cores/retroarch-core-options.cfg"
    local _fbneo_keys=(
        fbneo-cpu-speed-adjust fbneo-force-60hz fbneo-hiscores
        fbneo-allow-patched-romsets fbneo-memcard-mode fbneo-neogeo-mode
        fbneo-samplerate fbneo-sample-interpolation fbneo-fm-interpolation
        fbneo-lowpass-filter fbneo-analog-speed fbneo-frameskip-type
        fbneo-diagnostic-input
    )
    # ── CRT shader — applied to ALL per-core overrides ────────────────────────
    # Resolve the correct preset format based on the video driver.
    # RetroArch requires a .glslp/.slangp preset file, NOT a raw .glsl source.
    local _ra_custom="/userdata/system/configs/retroarch/retroarchcustom.cfg"
    local _vdriver
    _vdriver=$(grep -m1 '^video_driver' "$_ra_custom" 2>/dev/null | sed 's/.*= *"\?\([^"]*\).*/\1/')
    local _ext="glslp"
    case "$_vdriver" in vulkan|glcore) _ext="slangp" ;; esac
    local _shader=""
    local _candidate
    for _candidate in \
        "/usr/share/batocera/shaders/crt/crt-easymode.${_ext}" \
        "/usr/share/batocera/shaders/crt/crt-easymode.glslp" \
        "/usr/share/batocera/shaders/crt/crt-easymode.slangp"; do
        [ -f "$_candidate" ] && { _shader="$_candidate"; break; }
    done
    if [ -n "$_shader" ]; then
        for _core_name in "${CANONICAL_CORES[@]}"; do
            _cfg_file="$_ra_cfg_dir/$_core_name/$_core_name.cfg"
            [ -f "$_cfg_file" ] || continue
            sed -i '/^video_shader_enable /d; /^video_shader /d' "$_cfg_file" 2>/dev/null
            echo "video_shader_enable = \"true\"" >> "$_cfg_file"
            echo "video_shader = \"$_shader\"" >> "$_cfg_file"
        done
    fi

    [ -f "$_core_opts" ] || touch "$_core_opts"
    for _key in "${_fbneo_keys[@]}"; do
        sed -i "/^${_key} /d" "$_core_opts" 2>/dev/null
    done
    cat >> "$_core_opts" <<'FBNEO_OPTS'
fbneo-cpu-speed-adjust = "100%"
fbneo-force-60hz = "disabled"
fbneo-hiscores = "disabled"
fbneo-allow-patched-romsets = "disabled"
fbneo-memcard-mode = "disabled"
fbneo-neogeo-mode = "MVS_EUR"
fbneo-samplerate = "48000"
fbneo-sample-interpolation = "4-point 3rd order"
fbneo-fm-interpolation = "4-point 3rd order"
fbneo-lowpass-filter = "disabled"
fbneo-analog-speed = "100%"
fbneo-frameskip-type = "disabled"
fbneo-diagnostic-input = "Hold Start"
FBNEO_OPTS
}

# ─── DNS AUTO-HEAL ────────────────────────────────────────────────────────────
_ensure_dns() {
    if [ ! -s /etc/resolv.conf ] || ! grep -q '^nameserver' /etc/resolv.conf 2>/dev/null; then
        printf 'nameserver 8.8.8.8\nnameserver 1.1.1.1\n' > /etc/resolv.conf
        echo "  [DNS] Empty resolv.conf — added Google/Cloudflare nameservers"
        return
    fi
    if ! python3 -c "import socket; socket.setdefaulttimeout(4); socket.getaddrinfo('raw.githubusercontent.com', 443)" &>/dev/null; then
        printf 'nameserver 8.8.8.8\nnameserver 1.1.1.1\n' > /etc/resolv.conf
        echo "  [DNS] Resolution failed — overrode with Google/Cloudflare nameservers"
    fi
}

# ─── PROGRESS HELPERS ─────────────────────────────────────────────────────────
_spin() {
    local pid=$1
    while kill -0 "$pid" 2>/dev/null; do
        printf "."
        sleep 2
    done
}

# ─── DAT HELPERS ──────────────────────────────────────────────────────────────
_fetch_dat() {
    local url="$1" dest="$2"
    local name; name=$(basename "$dest")
    [ -f "$dest" ] && [ -s "$dest" ] && { echo "  ✓ $name (cached)"; return 0; }
    printf "  ↓ %s " "$name"
    local tmp="$dest.tmp"
    (while true; do sleep 2; printf "."; done) &
    local _dot=$!
    curl -fsL --max-time 30 -A "Outbreak/1.0" "$url" -o "$tmp" 2>/dev/null
    local _rc=$?
    kill "$_dot" 2>/dev/null; wait "$_dot" 2>/dev/null
    if [ $_rc -eq 0 ] && [ -s "$tmp" ]; then
        mv "$tmp" "$dest"
        echo " ✓"
    else
        rm -f "$tmp"
        echo " ✗ (download failed — skipping)"
    fi
}

_fetch_redump() {
    local url="$1" dest="$2" label="$3"
    [ -f "$dest" ] && [ -s "$dest" ] && { echo "  ✓ $label (cached)"; return 0; }
    printf "  ↓ %s (large file) " "$label"
    local zip_tmp
    zip_tmp=$(mktemp /tmp/redump_XXXXXX.zip)
    (while true; do sleep 3; printf "."; done) &
    local _dot=$!
    curl -sL --max-time 60 -A "Mozilla/5.0" "$url" -o "$zip_tmp" 2>/dev/null
    local _curl_rc=$?
    kill "$_dot" 2>/dev/null; wait "$_dot" 2>/dev/null
    if [ $_curl_rc -eq 0 ] && [ -s "$zip_tmp" ]; then
        local result
        result=$(python3 - "$zip_tmp" "$dest" <<'PYEOF'
import zipfile, sys, os, shutil
zip_path, dest = sys.argv[1], sys.argv[2]
try:
    with zipfile.ZipFile(zip_path) as z:
        names = [n for n in z.namelist() if n.lower().endswith(('.dat', '.xml'))]
        if not names:
            print("no-dat")
            sys.exit(1)
        tmp_dir = zip_path + "_ex"
        z.extract(names[0], tmp_dir)
        src = os.path.join(tmp_dir, names[0])
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        shutil.move(src, dest)
        shutil.rmtree(tmp_dir, ignore_errors=True)
        print("ok")
except Exception as e:
    print(f"error:{e}")
PYEOF
)
        rm -f "$zip_tmp"
        if [ -f "$dest" ] && [ -s "$dest" ]; then
            echo "  ✓ $label"
        else
            echo "  ✗ $label (extraction failed — skipping)"
        fi
    else
        rm -f "$zip_tmp"
        echo "  ✗ $label (download failed — skipping)"
    fi
}

fetch_dats() {
    local DATS="$INSTALL_DIR/dats"
    mkdir -p "$DATS"

    local _n=0 _total=14
    _dat() {
        _n=$((_n + 1))
        printf "[%d/%d] " "$_n" "$_total"
        _fetch_dat "$@"
    }
    _rdump() {
        _n=$((_n + 1))
        printf "[%d/%d] " "$_n" "$_total"
        _fetch_redump "$@"
    }

    local BASE="https://raw.githubusercontent.com/libretro/libretro-database/master/metadat/no-intro"
    _dat "$BASE/Nintendo%20-%20Nintendo%20Entertainment%20System.dat"                  "$DATS/Nintendo - Nintendo Entertainment System.dat"
    _dat "$BASE/Nintendo%20-%20Super%20Nintendo%20Entertainment%20System.dat"          "$DATS/Nintendo - Super Nintendo Entertainment System.dat"
    _dat "$BASE/Nintendo%20-%20Game%20Boy.dat"                                         "$DATS/Nintendo - Game Boy.dat"
    _dat "$BASE/Nintendo%20-%20Game%20Boy%20Advance.dat"                               "$DATS/Nintendo - Game Boy Advance.dat"
    _dat "$BASE/Nintendo%20-%20Game%20Boy%20Color.dat"                                 "$DATS/Nintendo - Game Boy Color.dat"
    _dat "$BASE/Sega%20-%20Mega%20Drive%20-%20Genesis.dat"                             "$DATS/Sega - Mega Drive - Genesis.dat"
    _dat "$BASE/Sega%20-%20Master%20System%20-%20Mark%20III.dat"                       "$DATS/Sega - Master System - Mark III.dat"
    _dat "$BASE/Sega%20-%20Game%20Gear.dat"                                            "$DATS/Sega - Game Gear.dat"
    _dat "$BASE/NEC%20-%20PC%20Engine%20-%20TurboGrafx%2016.dat"                      "$DATS/NEC - PC Engine - TurboGrafx 16.dat"
    _dat "$BASE/SNK%20-%20Neo%20Geo%20Pocket.dat"                                     "$DATS/SNK - Neo Geo Pocket.dat"
    _dat "$BASE/SNK%20-%20Neo%20Geo%20Pocket%20Color.dat"                             "$DATS/SNK - Neo Geo Pocket Color.dat"
    _dat "$BASE/Atari%20-%202600.dat"                                                  "$DATS/Atari - 2600.dat"

    _dat "https://raw.githubusercontent.com/libretro/FBNeo/master/dats/FinalBurn%20Neo%20%28ClrMame%20Pro%20XML%2C%20Arcade%20only%29.dat" \
         "$DATS/FinalBurn Neo (ClrMame Pro XML, Arcade only).dat"

    _dat "https://raw.githubusercontent.com/libretro/mame2003-plus-libretro/master/metadata/mame2003-plus.xml" \
         "$DATS/mame2003-plus.xml"

    _rdump "https://redump.org/datfile/psx/" "$DATS/Redump - Sony - PlayStation.dat"  "Redump PlayStation"
    _rdump "https://redump.org/datfile/dc/"  "$DATS/Redump - Sega - Dreamcast.dat"    "Redump Dreamcast"
}

# ─── ES SYSTEM CAROUSEL ENTRY ─────────────────────────────────────────────────
_install_es_system() {
    local ES_CFG_DIR="/userdata/system/configs/emulationstation"
    local ES_SETTINGS="$ES_CFG_DIR/es_settings.cfg"
    local SRC_DIR="$INSTALL_DIR/ui/es-system"

    mkdir -p "$ES_CFG_DIR"
    cp "$SRC_DIR/es_systems_outbreak.cfg" "$ES_CFG_DIR/es_systems_outbreak.cfg"
    echo "  ES system cfg: $ES_CFG_DIR/es_systems_outbreak.cfg"

    mkdir -p /userdata/roms/outbreak/images
    touch "/userdata/roms/outbreak/Launch Outbreak.outbreak"
    echo "  Dummy ROM: /userdata/roms/outbreak/Launch Outbreak.outbreak"

    # Create gamelist entry with logo and description so the game list
    # inside the Outbreak Lobby system looks polished (not a blank entry)
    local _ob_gl="/userdata/roms/outbreak/gamelist.xml"
    if ! grep -q '<image>' "$_ob_gl" 2>/dev/null; then
        cat > "$_ob_gl" <<'OBGL'
<?xml version="1.0"?>
<gameList>
  <game>
    <path>./Launch Outbreak.outbreak</path>
    <name>Outbreak Lobby</name>
    <desc>Browse and join netplay sessions. See who's hosting on your network, pick a game, and jump in — no manual RetroArch configuration needed.</desc>
    <image>./images/Launch Outbreak-image.png</image>
    <genre>Network</genre>
  </game>
</gameList>
OBGL
    fi

    local ACTIVE_THEME="art-book-next"
    if [ -f "$ES_SETTINGS" ]; then
        local _t
        _t=$(grep -o 'ThemeSet[^<]*value="[^"]*"' "$ES_SETTINGS" 2>/dev/null \
             | grep -o 'value="[^"]*"' | cut -d'"' -f2)
        [ -n "$_t" ] && ACTIVE_THEME="$_t"
    fi

    local THEME_BASE=""
    if [ -d "/userdata/themes/$ACTIVE_THEME" ]; then
        THEME_BASE="/userdata/themes/$ACTIVE_THEME"
    elif [ -d "$ES_CFG_DIR/themes/$ACTIVE_THEME" ]; then
        THEME_BASE="$ES_CFG_DIR/themes/$ACTIVE_THEME"
    else
        THEME_BASE="/userdata/themes/$ACTIVE_THEME"
    fi

    # Inject Outbreak Lobby theme assets
    local THEME_DIR="$THEME_BASE/outbreak"
    mkdir -p "$THEME_DIR"
    cp "$SRC_DIR/logo.svg" "$THEME_DIR/logo.svg"
    cp "$SRC_DIR/theme.xml" "$THEME_DIR/theme.xml"
    if [ -f "$SRC_DIR/custom.xml" ]; then
        cp "$SRC_DIR/custom.xml" "$THEME_DIR/custom.xml"
    fi
    # Artflix carousel logos are PNG (assets/logos/${system.theme}.png)
    if [ -d "$THEME_BASE/assets/logos" ] && command -v rsvg-convert &>/dev/null; then
        rsvg-convert -w 1419 -h 485 "$SRC_DIR/logo.svg" -o "$THEME_BASE/assets/logos/outbreak.png"
        # Also use the logo as the game entry image inside the Outbreak Lobby system
        cp "$THEME_BASE/assets/logos/outbreak.png" "/userdata/roms/outbreak/images/Launch Outbreak-image.png"
    fi
    # System background art (assets/arts/${system.theme}.jpg) — reuse fbneo art for arcade feel
    if [ -d "$THEME_BASE/assets/arts" ] && [ -f "$THEME_BASE/assets/arts/fbneo.jpg" ]; then
        cp "$THEME_BASE/assets/arts/fbneo.jpg" "$THEME_BASE/assets/arts/outbreak.jpg"
    fi

    # Inject Outbreak Host collection theme assets
    local COLL_SRC="$INSTALL_DIR/ui/es-collection"
    if [ -f "$COLL_SRC/custom.xml" ]; then
        local COLL_THEME_DIR="$THEME_BASE/Outbreak Host"
        mkdir -p "$COLL_THEME_DIR"
        cp "$COLL_SRC/custom.xml" "$COLL_THEME_DIR/custom.xml"
        [ -f "$COLL_SRC/logo.svg" ] && cp "$COLL_SRC/logo.svg" "$COLL_THEME_DIR/logo.svg"
        # Artflix carousel logo (must be PNG)
        if [ -d "$THEME_BASE/assets/logos" ] && [ -f "$COLL_SRC/logo.svg" ] && command -v rsvg-convert &>/dev/null; then
            rsvg-convert -w 1419 -h 485 "$COLL_SRC/logo.svg" -o "$THEME_BASE/assets/logos/Outbreak Host.png"
        fi
        # Collection background art — use custom-collections default
        if [ -d "$THEME_BASE/assets/arts" ] && [ -f "$THEME_BASE/assets/arts/custom-collections.jpg" ]; then
            cp "$THEME_BASE/assets/arts/custom-collections.jpg" "$THEME_BASE/assets/arts/Outbreak Host.jpg"
        fi
        # Stub theme.xml so ES recognises this as a themed folder
        cat > "$COLL_THEME_DIR/theme.xml" <<'STUB'
<theme><formatVersion>7</formatVersion><include>./../theme.xml</include></theme>
STUB
        echo "  Collection theme: $COLL_THEME_DIR/"
    fi

    # Clean ALL shadow theme dirs that only contain our injected folders.
    # ES checks configs/emulationstation/themes/ FIRST — a shadow with only
    # our folders hides the real 400+ folder theme in /userdata/themes/.
    local _shadow_root="$ES_CFG_DIR/themes"
    if [ -d "$_shadow_root" ]; then
        local _d
        for _d in "$_shadow_root"/*/; do
            [ -d "$_d" ] || continue
            # Count non-outbreak items; if everything is ours, it's a shadow
            local _total _ours
            _total=$(find "$_d" -maxdepth 1 -mindepth 1 | wc -l)
            _ours=0
            [ -d "${_d}outbreak" ] && ((_ours++))
            [ -d "${_d}Outbreak Host" ] && ((_ours++))
            if [ "$_total" -gt 0 ] && [ "$_total" -le "$_ours" ]; then
                rm -rf "$_d"
                echo "  Cleaned shadow theme dir: $_d"
            fi
        done
    fi
    echo "  Theme assets:  $THEME_DIR/ (theme.xml + custom.xml)"

    if pgrep -x emulationstation &>/dev/null; then
        echo "  NOTE: Run 'Update Gamelist' from the ES menu to see the new system."
    fi
}

# ─── PORTS LAUNCHER ───────────────────────────────────────────────────────────
_write_ports_launcher() {
    local PORTS_DIR="/userdata/roms/ports"
    mkdir -p "$PORTS_DIR"
    cat > "$PORTS_DIR/Outbreak Arcade.sh" <<'PORTSAPP'
#!/bin/bash
# Outbreak Arcade — cabinet launcher
# Runs the native Python cabinet UI (no browser required).

INSTALL_DIR="/userdata/system/netplay-arcade"
UI_SCRIPT="$INSTALL_DIR/scripts/cabinet-ui.py"
LOG=/tmp/outbreak-browser.log

export DISPLAY="${DISPLAY:-:0}"
echo "[$(date)] Outbreak Arcade launcher starting" >> "$LOG"

# Wait up to 15 s for the Outbreak server to be reachable
for i in $(seq 1 15); do
    curl -sf http://localhost:8765/status &>/dev/null && break
    sleep 1
done

if ! python3 -c "import pygame" 2>/dev/null; then
    echo "[$(date)] pygame not found — trying pip install" >> "$LOG"
    pip install pygame --quiet 2>>"$LOG" || true
fi

if python3 -c "import pygame" 2>/dev/null; then
    echo "[$(date)] Launching cabinet-ui.py" >> "$LOG"
    python3 "$UI_SCRIPT" >> "$LOG" 2>&1
    echo "[$(date)] cabinet-ui.py exited with code $?" >> "$LOG"
else
    echo "[$(date)] pygame unavailable — falling back to browser" >> "$LOG"
    for candidate in chromium-browser chromium firefox netsurf; do
        if command -v "$candidate" &>/dev/null; then
            "$candidate" --kiosk --no-sandbox "http://localhost:8765/ui" &
            wait $!
            exit 0
        fi
    done
    echo "No display method found. Open http://localhost:8765/ui on another device." >&2
    sleep 5
    exit 1
fi
PORTSAPP
    chmod +x "$PORTS_DIR/Outbreak Arcade.sh"

    local GAMELIST="$PORTS_DIR/gamelist.xml"
    if [ ! -f "$GAMELIST" ]; then
        cat > "$GAMELIST" <<'GMXML'
<?xml version="1.0"?>
<gameList></gameList>
GMXML
    fi
    if ! grep -q "Outbreak Arcade" "$GAMELIST" 2>/dev/null; then
        sed -i 's|</gameList>|  <game>\n    <path>./Outbreak Arcade.sh</path>\n    <name>Outbreak Arcade</name>\n    <desc>Browse and join netplay sessions from the cabinet. Select a game with your arcade stick and Outbreak handles the rest.</desc>\n    <genre>Network</genre>\n  </game>\n</gameList>|' "$GAMELIST"
    fi
    echo "Ports launcher updated: $PORTS_DIR/Outbreak Arcade.sh"
}

# ─── RETROARCH CONFIG HELPER ─────────────────────────────────────────────────
_set_opt() {
    local cfg="$1" key="$2" val="$3"
    mkdir -p "$(dirname "$cfg")"
    touch "$cfg"
    if grep -q "^${key} " "$cfg" 2>/dev/null; then
        sed -i "s|^${key} = .*|${key} = \"${val}\"|" "$cfg"
    else
        echo "${key} = \"${val}\"" >> "$cfg"
    fi
}

# ─── PRE-SERVER SETUP ────────────────────────────────────────────────────────
# Everything that must happen BEFORE the Python server starts.
# Called by boot.sh right before exec'ing into Python.
pre_server() {
    echo "[$(date '+%H:%M:%S')] NetPlay Arcade pre-server setup..."

    # Wait for network
    local retries=0
    if ! ping -c 1 -W 1 8.8.8.8 &>/dev/null; then
        printf "[$(date '+%H:%M:%S')] Waiting for network"
        while ! ping -c 1 -W 1 8.8.8.8 &>/dev/null && [ $retries -lt 10 ]; do
            printf "."
            sleep 2
            ((retries++))
        done
        echo ""
    fi

    _ensure_dns

    # Disable WiFi power save
    if command -v iw &>/dev/null && iw dev wlan0 info &>/dev/null 2>&1; then
        iw dev wlan0 set power_save off 2>/dev/null && \
            echo "[$(date '+%H:%M:%S')] WiFi power save disabled"
    fi

    _ensure_exit_overrides
    echo "[$(date '+%H:%M:%S')] Core exit hotkey overrides verified"

    # Initialize core DB if needed
    [ ! -f "$INSTALL_DIR/core_compat.json" ] && \
        bash "$SCRIPTS_DIR/core-checker.sh" init

    # Initialize netplay core channel if manifest is stale
    if ! bash "$SCRIPTS_DIR/netplay-cores.sh" check-channel 2>/dev/null; then
        bash "$SCRIPTS_DIR/netplay-cores.sh" init
    fi

    # Bind-mount pinned cores over system cores
    local PINNED_DIR="$INSTALL_DIR/cores"
    local _mounted=0
    local _LOG="/tmp/netplay-arcade.log"
    if [ -d "$PINNED_DIR" ]; then
        for pinned_so in "$PINNED_DIR"/*_libretro.so; do
            [ -f "$pinned_so" ] || continue
            local core_name
            core_name=$(basename "$pinned_so")
            local system_so="/usr/lib/libretro/$core_name"
            [ ! -f "$system_so" ] && continue
            local _sys_md5 _pin_md5
            _sys_md5=$(md5sum "$system_so" 2>/dev/null | cut -d' ' -f1)
            _pin_md5=$(md5sum "$pinned_so" 2>/dev/null | cut -d' ' -f1)
            [ "$_sys_md5" = "$_pin_md5" ] && continue
            if mount --bind "$pinned_so" "$system_so" 2>/dev/null; then
                ((_mounted++))
            else
                echo "[$(date '+%H:%M:%S')] CORE: WARN bind mount failed for $core_name" >> "$_LOG"
            fi
        done
        echo "[$(date '+%H:%M:%S')] CORE: $_mounted core(s) bind-mounted" >> "$_LOG"
    fi

    # Flycast overrides
    local FLYCAST_INFO="/usr/share/libretro/info/flycast_libretro.info"
    if [ -f "$FLYCAST_INFO" ]; then
        sed -i 's/savestate_features = "serialized"/savestate_features = "deterministic"/' \
            "$FLYCAST_INFO" 2>/dev/null && \
            echo "[$(date '+%H:%M:%S')] Flycast .info: savestate_features → deterministic"
    fi
    local ES_FEAT_DC="/userdata/system/configs/emulationstation/es_features_dreamcast.cfg"
    if [ ! -f "$ES_FEAT_DC" ]; then
        cat > "$ES_FEAT_DC" << 'ESXML'
<?xml version="1.0" encoding="UTF-8" ?>
<features>
  <emulator name="libretro" features="">
    <cores>
      <core name="flycast" features="netplay, cheevos">
      </core>
    </cores>
  </emulator>
</features>
ESXML
        echo "[$(date '+%H:%M:%S')] ES Dreamcast netplay override created"
    fi
    local FLYCAST_OPT="/userdata/system/configs/retroarch/config/Flycast/Flycast.opt"
    if [ -f "$FLYCAST_OPT" ]; then
        sed -i \
            -e 's/reicast_threaded_rendering = "enabled"/reicast_threaded_rendering = "disabled"/' \
            -e 's/reicast_mipmapping = "enabled"/reicast_mipmapping = "disabled"/' \
            "$FLYCAST_OPT" 2>/dev/null
    fi

    # Write netplay RetroArch settings
    local RA_CFG=""
    for _candidate in \
        "/userdata/system/configs/retroarch/retroarch.cfg" \
        "/userdata/system/retroarch/retroarch.cfg"; do
        [ -f "$_candidate" ] && { RA_CFG="$_candidate"; break; }
    done
    [ -z "$RA_CFG" ] && RA_CFG="/userdata/system/configs/retroarch/retroarch.cfg"

    _set_opt "$RA_CFG" "netplay_delay_frames"    "0"
    _set_opt "$RA_CFG" "netplay_check_frames"    "0"
    _set_opt "$RA_CFG" "rewind_enable"           "true"
    _set_opt "$RA_CFG" "rewind_buffer_size"      "256"
    _set_opt "$RA_CFG" "runahead_enabled"        "false"
    _set_opt "$RA_CFG" "runahead_frames"         "0"
    _set_opt "$RA_CFG" "preemptive_frames"       "0"
    _set_opt "$RA_CFG" "savestate_auto_load"     "false"
    _set_opt "$RA_CFG" "audio_sync"              "true"
    _set_opt "$RA_CFG" "cheats_enable"           "false"
    _set_opt "$RA_CFG" "netplay_public_announce" "false"
    _set_opt "$RA_CFG" "netplay_stateless_mode"  "false"
    _set_opt "$RA_CFG" "netplay_use_mitm_server" "true"
    _set_opt "$RA_CFG" "netplay_mitm_server"     "nymeria"
    _set_opt "$RA_CFG" "netplay_nat_traversal"   "false"
    echo "[$(date '+%H:%M:%S')] Netplay settings written to $RA_CFG"

    local RA_CUSTOM="/userdata/system/configs/retroarch/retroarchcustom.cfg"
    _set_opt "$RA_CUSTOM" "netplay_use_mitm_server" "true"
    _set_opt "$RA_CUSTOM" "netplay_mitm_server"     "nymeria"
    _set_opt "$RA_CUSTOM" "netplay_nat_traversal"   "false"
    _set_opt "$RA_CUSTOM" "core_info_savestate_bypass" "true"
    echo "[$(date '+%H:%M:%S')] Relay override stamped into $RA_CUSTOM"

    # DAT cache rebuild
    local DAT_CHECKER="$SCRIPTS_DIR/dat_checker.py"
    local DATS_DIR="$INSTALL_DIR/dats"
    local DAT_CACHE="$DATS_DIR/.cache.json"
    if [ -f "$DAT_CHECKER" ] && [ -d "$DATS_DIR" ]; then
        local newer_dat
        newer_dat=$(find "$DATS_DIR" \( -name "*.dat" -o -name "*.xml" \) \
                    -newer "$DAT_CACHE" 2>/dev/null | head -1)
        if [ -n "$newer_dat" ] || [ ! -f "$DAT_CACHE" ]; then
            local dat_count
            dat_count=$(find "$DATS_DIR" \( -name "*.dat" -o -name "*.xml" \) 2>/dev/null | wc -l)
            if [ "$dat_count" -gt 0 ]; then
                echo "[$(date '+%H:%M:%S')] Rebuilding DAT cache ($dat_count file(s))..."
                python3 "$DAT_CHECKER" build-cache "$DATS_DIR" "$DAT_CACHE" \
                    >> "$INSTALL_DIR/logs/server.log" 2>&1
            fi
        fi
    fi

    echo "[$(date '+%H:%M:%S')] Pre-server setup complete"
}

# ─── POST-UPDATE ──────────────────────────────────────────────────────────────
# Called by the Python server's auto-update thread after new files are on disk.
# Does bash-specific refresh work, then returns (server restarts via os.execv).
post_update() {
    local _tag="${1:-}"

    _ensure_exit_overrides
    echo "[update] Per-core exit hotkey overrides verified"

    _write_ports_launcher 2>/dev/null || true
    _install_es_system 2>/dev/null || true

    # Refresh core channel if PINNED_BUILD_DATE changed
    if ! bash "$SCRIPTS_DIR/netplay-cores.sh" check-channel 2>/dev/null; then
        echo "[update] Canonical build date changed — re-initializing core channel..."
        bash "$SCRIPTS_DIR/netplay-cores.sh" init
    fi
    rm -f /tmp/rom_scan_last_run

    _es_notify "Outbreak updated to ${_tag:-latest}"
    echo "[update] Post-update complete"
}

# ─── INSTALL ──────────────────────────────────────────────────────────────────
install() {
    local _release_tag="${1:-}"

    echo "=== Installing Batocera NetPlay Arcade ==="

    # Reject installs on Batocera < 38
    local _VER_FILE="/usr/share/batocera/batocera.version"
    if [ -f "$_VER_FILE" ]; then
        local _VER; _VER=$(cat "$_VER_FILE" | tr -d '[:alpha:][:space:]' | cut -d'.' -f1)
        if [ -n "$_VER" ] && [ "$_VER" -lt 38 ] 2>/dev/null; then
            echo "ERROR: Outbreak requires Batocera v38+. Detected: $(cat "$_VER_FILE")"
            echo "       Run: batocera-upgrade"
            exit 1
        fi
    fi

    mkdir -p "$SCRIPTS_DIR" "$UI_DIR" "$INSTALL_DIR/dats" "$INSTALL_DIR/logs"

    SCRIPT_SOURCE="$(cd "$(dirname "$0")" && pwd -P)"
    local _dest_resolved
    _dest_resolved="$(cd "$SCRIPTS_DIR" 2>/dev/null && pwd -P)" || _dest_resolved=""

    # Only copy files if source differs from destination (install.sh already
    # rsync'd the tarball contents into INSTALL_DIR before calling boot.sh).
    if [ "$SCRIPT_SOURCE" != "$_dest_resolved" ]; then
        for f in boot.sh setup.sh config-parser.sh core-checker.sh netplay-broadcast.sh netplay-cores.sh rom-checker.sh netplay-es-launch.sh netplay-es-event.sh outbreak-launch.sh enforce-canonical.sh service; do
            if [ -f "$SCRIPT_SOURCE/$f" ]; then
                cp "$SCRIPT_SOURCE/$f" "$SCRIPTS_DIR/$f"
                chmod +x "$SCRIPTS_DIR/$f"
            fi
        done

        for f in netplay-server.py netplay_extensions.py rom_finder.py dat_checker.py cabinet-ui.py media-scraper.py; do
            if [ -f "$SCRIPT_SOURCE/$f" ]; then
                cp "$SCRIPT_SOURCE/$f" "$SCRIPTS_DIR/$f"
                chmod +x "$SCRIPTS_DIR/$f"
            fi
        done

        [ -f "$SCRIPT_SOURCE/../ui/index.html" ] && \
            cp "$SCRIPT_SOURCE/../ui/index.html" "$UI_DIR/"

        if [ -d "$SCRIPT_SOURCE/../ui/es-system" ]; then
            mkdir -p "$UI_DIR/es-system"
            cp -r "$SCRIPT_SOURCE/../ui/es-system/." "$UI_DIR/es-system/"
        fi
    fi

    # Ensure scripts are executable regardless of copy path
    chmod +x "$SCRIPTS_DIR/"*.sh "$SCRIPTS_DIR/service" 2>/dev/null || true

    # Download fonts
    FONTS_DIR="$UI_DIR/fonts"
    mkdir -p "$FONTS_DIR"
    _dl_font() {
        # Download a Google Font as TTF (for cabinet-ui.py / pygame) and woff2 (for web UI).
        # Google Fonts returns TTF or woff2 depending on User-Agent.
        local name="$1" family="$2"
        local dest_ttf="$FONTS_DIR/$name.ttf"
        local dest_woff2="$FONTS_DIR/$name.woff2"

        # Skip if both already cached
        if [ -f "$dest_ttf" ] && [ -f "$dest_woff2" ]; then
            echo "  ✓ font: $name (cached)"
            return 0
        fi

        printf "  ↓ font: %s " "$name"
        local css url

        # TTF: CSS2 with default user-agent returns real .ttf URLs on Batocera
        if [ ! -f "$dest_ttf" ]; then
            css=$(curl -sf -A "Mozilla/5.0" \
                "https://fonts.googleapis.com/css2?family=${family}&display=swap" 2>/dev/null)
            url=$(echo "$css" | grep -o 'https://fonts.gstatic.com[^)]*\.ttf' | head -1)
            [ -n "$url" ] && curl -sf -o "$dest_ttf" "$url" 2>/dev/null
        fi

        # woff2: use Chrome user-agent so Google returns woff2 format
        if [ ! -f "$dest_woff2" ]; then
            css=$(curl -sf -A "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/120" \
                "https://fonts.googleapis.com/css2?family=${family}&display=swap" 2>/dev/null)
            url=$(echo "$css" | grep -o 'https://fonts.gstatic.com[^)]*\.woff2' | head -1)
            [ -n "$url" ] && curl -sf -o "$dest_woff2" "$url" 2>/dev/null
        fi

        if [ -f "$dest_ttf" ] || [ -f "$dest_woff2" ]; then
            echo "✓"
        else
            echo "✗ (download failed)"
        fi
    }
    _dl_font "press-start-2p"  "Press+Start+2P"
    _dl_font "share-tech-mono" "Share+Tech+Mono"

    # Initialize default config
    if [ ! -f "$CONFIG_FILE" ]; then
        cat > "$CONFIG_FILE" <<DEFAULTCFG
# Batocera NetPlay Arcade Configuration
username=$(hostname)

# Optional: post a message to Discord when you start broadcasting.
# Create a webhook at: Discord Server Settings > Integrations > Webhooks
# discord_webhook=https://discord.com/api/webhooks/YOUR_ID/YOUR_TOKEN
discord_webhook=

retroarch_bin=/usr/bin/retroarch

# Set to false to disable automatic ROM downloads from Internet Archive
auto_download_roms=true

# Enlarge buttons for controller/cabinet use
cabinet_mode=false

# WAN lobby — broadcast your session to the public libretro lobby so players
# anywhere can find you. Uses libretro's relay servers; no port forwarding needed.
# Set to false to restrict to local network only.
wan_enabled=true

# Optional 4-digit PIN — leave blank to allow anyone to join your session
session_pin=

# Panel password — protects the web panel and all API endpoints.
# Leave blank for open access (default). Set a password for public/bar deployments.
# panel_password=

# Idle timeout — auto-stop hosting sessions with no remote players (minutes).
# Default: 8 minutes. Set to 0 to disable.
idle_timeout_minutes=8

# Local player count override — set this if you use Bluetooth or wireless
# controllers that pair AFTER the game launches and are not detected automatically.
# Valid values: 1, 2, 3, or 4. Leave commented out to use auto-detection.
# local_players=2
DEFAULTCFG
        echo "Created default config: $CONFIG_FILE"
    fi

    # Initialize core database
    echo "Initializing core database..."
    bash "$SCRIPTS_DIR/core-checker.sh" init

    echo "Pinning netplay core channel..."
    bash "$SCRIPTS_DIR/netplay-cores.sh" init

    echo ""
    echo "=== Downloading ROM databases [14 files — one-time only] ==="
    _ensure_dns
    fetch_dats

    # Install as a Batocera service
    SERVICE_DEST="/userdata/system/services/netplay_arcade"
    mkdir -p /userdata/system/services
    rm -f "/userdata/system/services/netplay-arcade"
    cp "$SCRIPTS_DIR/service" "$SERVICE_DEST"
    chmod +x "$SERVICE_DEST"
    batocera-services enable netplay_arcade 2>/dev/null || true
    echo "Service installed: $SERVICE_DEST"

    # ES event hooks
    ES_SCRIPTS_DIR="/userdata/system/scripts"
    mkdir -p "$ES_SCRIPTS_DIR"
    rm -f "$ES_SCRIPTS_DIR/netplay-launch.sh"
    ln -sf "$SCRIPTS_DIR/netplay-es-event.sh" "$ES_SCRIPTS_DIR/netplay-event.sh"
    chmod +x "$SCRIPTS_DIR/netplay-es-event.sh"
    chmod +x "$SCRIPTS_DIR/netplay-es-launch.sh"
    echo "ES event hook installed: $ES_SCRIPTS_DIR/netplay-event.sh"

    _write_ports_launcher
    _install_es_system
    _ensure_exit_overrides
    echo "Per-core exit hotkey overrides created"

    local _IP
    _IP=$(hostname -I 2>/dev/null | awk '{print $1}')
    [ -z "$_IP" ] && _IP=$(ip route get 1 2>/dev/null | awk '{print $7;exit}')
    [ -z "$_IP" ] && _IP="<your-ip>"
    local _URL="http://$_IP:8765/ui"

    echo ""
    echo "╔══════════════════════════════════════════════════╗"
    echo "║           Outbreak installed!                    ║"
    echo "║                                                  ║"
    printf  "║  Open: %-42s║\n" "$_URL"
    echo "║                                                  ║"
    echo "║  Open on the cabinet or from another Batocera   ║"
    echo "╚══════════════════════════════════════════════════╝"
    echo ""

    # Resolve version: explicit arg > parent directory name > GitHub API > unknown
    if [ -z "$_release_tag" ]; then
        # Try to infer from extracted directory name (e.g. Outbreak-v2.3.2/scripts/)
        local _parent_dir
        _parent_dir="$(basename "$(cd "$SCRIPT_SOURCE/.." 2>/dev/null && pwd)")"
        if [[ "$_parent_dir" == Outbreak-v* ]]; then
            _release_tag="${_parent_dir#Outbreak-}"
        fi
    fi
    if [ -z "$_release_tag" ]; then
        _release_tag=$(curl -sf --max-time 5 \
            "https://api.github.com/repos/$REPO/releases/latest" \
            | grep '"tag_name"' | head -1 \
            | sed 's/.*"tag_name": *"\([^"]*\)".*/\1/')
    fi
    echo "${_release_tag:-unknown}" > "$VERSION_STAMP"

    echo "Starting server..."
    bash "$SCRIPTS_DIR/boot.sh" boot >> "$INSTALL_DIR/logs/server.log" 2>&1 </dev/null &
    echo ""
}

# ─── UPDATE (download + apply) ───────────────────────────────────────────────
# Manual update: pulls latest release, copies files, triggers post-update.
# The auto-update thread in the server handles this automatically;
# this entry point is for manual CLI use.
do_update() {
    echo "=== Outbreak update ==="
    local TMP_DIR
    TMP_DIR=$(mktemp -d)
    local LATEST_TAG
    LATEST_TAG=$(curl -sf "https://api.github.com/repos/$REPO/releases/latest" \
        | grep '"tag_name"' | head -1 | sed 's/.*"tag_name": *"\([^"]*\)".*/\1/')
    if [ -z "$LATEST_TAG" ]; then
        echo "ERROR: Could not find latest release."
        rm -rf "$TMP_DIR"
        exit 1
    fi
    local TARBALL_URL="https://github.com/$REPO/releases/download/$LATEST_TAG/outbreak-${LATEST_TAG}.tar.gz"
    echo "Downloading Outbreak $LATEST_TAG..."
    _ensure_dns
    printf "Downloading"
    curl -sfL --max-time 120 "$TARBALL_URL" -o "$TMP_DIR/outbreak.tar.gz" &
    local _dl_pid=$!
    _spin $_dl_pid
    wait $_dl_pid || {
        echo ""
        echo "ERROR: Download failed."
        rm -rf "$TMP_DIR"
        exit 1
    }
    echo " ✓"
    echo "Extracting..."
    tar xzf "$TMP_DIR/outbreak.tar.gz" -C "$TMP_DIR"
    local EXTRACTED
    EXTRACTED=$(find "$TMP_DIR" -maxdepth 1 -type d -name "Outbreak*" | head -1)
    if [ -z "$EXTRACTED" ]; then
        echo "ERROR: Could not find extracted directory."
        rm -rf "$TMP_DIR"
        exit 1
    fi
    rsync -a --exclude="config.cfg" "$EXTRACTED/scripts/" "$INSTALL_DIR/scripts/" 2>/dev/null || \
        cp -r "$EXTRACTED/scripts/." "$INSTALL_DIR/scripts/"
    rsync -a "$EXTRACTED/ui/" "$INSTALL_DIR/ui/" 2>/dev/null || \
        cp -r "$EXTRACTED/ui/." "$INSTALL_DIR/ui/"
    chmod +x "$INSTALL_DIR/scripts/"*.sh "$INSTALL_DIR/scripts/service" 2>/dev/null || true
    # Infer version from extracted dir name if API didn't return a tag
    if [ -z "$LATEST_TAG" ]; then
        local _dir_name
        _dir_name="$(basename "$EXTRACTED")"
        [[ "$_dir_name" == Outbreak-v* ]] && LATEST_TAG="${_dir_name#Outbreak-}"
    fi
    rm -rf "$TMP_DIR"
    echo "${LATEST_TAG:-unknown}" > "$VERSION_STAMP"
    echo "Files updated — running post-update..."
    # Run post-update from the NEW setup.sh
    bash "$INSTALL_DIR/scripts/setup.sh" post-update "${LATEST_TAG:-}"
    echo "Update complete. Restart the server: bash boot.sh restart"
}

# ─── DISPATCH ─────────────────────────────────────────────────────────────────
case "${1:-}" in
    pre-server)          pre_server ;;
    post-update)         post_update "$2" ;;
    install)             install "$2" ;;
    update)              do_update ;;
    _write_ports_launcher) _write_ports_launcher ;;
    _install_es_system)    _install_es_system ;;
    *)
        echo "Usage: $0 {pre-server|post-update|install|update}"
        ;;
esac
