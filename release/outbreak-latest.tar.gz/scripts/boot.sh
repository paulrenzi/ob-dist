#!/bin/bash
# =============================================================================
# Batocera NetPlay Arcade - Launcher & Process Manager
#
# This is a THIN DISPATCHER.  All setup logic lives in setup.sh.
# All background work (auto-update, boot scan, ROM watcher) lives in
# netplay-server.py as daemon threads.
#
# The boot command uses `exec` to replace this shell with the Python server,
# so the PID that Batocera's service manager tracks IS the Python process.
# No orphan possible — there is only ever one process.
# =============================================================================

INSTALL_DIR="/userdata/system/netplay-arcade"
SCRIPTS_DIR="$INSTALL_DIR/scripts"
MASTER_PID="/tmp/outbreak_master.pid"

# ─── PID GATEKEEPER ──────────────────────────────────────────────────────────
_master_alive() {
    [ -f "$MASTER_PID" ] || return 1
    local _pid
    _pid=$(cat "$MASTER_PID" 2>/dev/null)
    [ -n "$_pid" ] && kill -0 "$_pid" 2>/dev/null
}

_kill_master() {
    [ -f "$MASTER_PID" ] || return 0
    local _pid
    _pid=$(cat "$MASTER_PID" 2>/dev/null)
    [ -z "$_pid" ] && return 0
    if kill -0 "$_pid" 2>/dev/null; then
        kill "$_pid" 2>/dev/null
        local _i=0
        while kill -0 "$_pid" 2>/dev/null && [ $_i -lt 6 ]; do
            sleep 0.5; ((_i++))
        done
        kill -0 "$_pid" 2>/dev/null && kill -9 "$_pid" 2>/dev/null
    fi
    rm -f "$MASTER_PID"
}

# ─── STATUS ──────────────────────────────────────────────────────────────────
status() {
    if _master_alive; then
        echo "NetPlay Arcade server running (PID $(cat "$MASTER_PID"))"
        curl -s http://localhost:8765/status | python3 -m json.tool 2>/dev/null
    else
        echo "NetPlay Arcade server not running"
    fi
}

# ─── BOOT ─────────────────────────────────────────────────────────────────────
# Atomic singleton boot using flock + exec.
#
# Why flock: The PID file check alone has a TOCTOU race — if custom.sh fires
# twice (documented Batocera behavior), both boot.sh instances can pass the
# PID check before either writes the file.  flock makes the gate atomic.
#
# Why exec: Replaces this shell with Python — the flock on fd 200 is inherited,
# so the lock is held for the server's ENTIRE lifetime.  Released automatically
# on exit/crash (kernel guarantee).  No stale lock files, no stale PID files.
#
# Combined: flock prevents the boot race, exec prevents orphans, and the
# inherited lock acts as a runtime singleton guard.
BOOT_LOCK="/tmp/outbreak_boot.lock"

boot() {
    # Fast path: if PID file exists and process alive, skip without locking
    if _master_alive; then
        echo "[$(date '+%H:%M:%S')] Outbreak master already running (PID $(cat "$MASTER_PID")). Nothing to do."
        return 0
    fi

    # Atomic gate: acquire exclusive lock on fd 200.
    # flock -n = non-blocking — if another boot.sh holds the lock, exit immediately.
    exec 200>"$BOOT_LOCK"
    flock -n 200 || {
        echo "[$(date '+%H:%M:%S')] Another boot in progress — skipping."
        return 0
    }

    # Double-check after acquiring lock (another instance may have started
    # in the window between our fast-path check and the flock)
    if _master_alive; then
        echo "[$(date '+%H:%M:%S')] Outbreak master already running (PID $(cat "$MASTER_PID")). Nothing to do."
        return 0
    fi

    echo "[$(date '+%H:%M:%S')] Outbreak booting..."
    mkdir -p "$INSTALL_DIR/logs"

    # Run all bash setup (network, DNS, bind mounts, RA config, DAT cache)
    bash "$SCRIPTS_DIR/setup.sh" pre-server

    # Replace this shell with the Python server.
    # fd 200 (flock) is inherited by exec → Python holds the lock for its
    # entire lifetime.  No second boot.sh can pass flock while server lives.
    # On exit/crash, the kernel releases the lock automatically.
    exec python3 "$SCRIPTS_DIR/netplay-server.py" >> "$INSTALL_DIR/logs/server.log" 2>&1
}

# ─── DISPATCH ─────────────────────────────────────────────────────────────────
case "${1:-boot}" in
    boot)
        boot
        ;;
    install)
        bash "$SCRIPTS_DIR/setup.sh" install "$2"
        ;;
    update)
        bash "$SCRIPTS_DIR/setup.sh" update
        ;;
    restart)
        _kill_master
        boot
        ;;
    stop)
        _kill_master
        echo "NetPlay Arcade stopped"
        ;;
    status)
        status
        ;;
    _write_ports_launcher)
        bash "$SCRIPTS_DIR/setup.sh" _write_ports_launcher
        ;;
    _install_es_system)
        bash "$SCRIPTS_DIR/setup.sh" _install_es_system
        ;;
    *)
        echo "Usage: $0 {install|boot|update|status|restart|stop}"
        ;;
esac
