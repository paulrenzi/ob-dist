#!/bin/bash
# =============================================================================
# Batocera NetPlay - ROM Checker & Canonical Auto-Downloader
#
# Boot flow:
#   1. Walk every ROM in /userdata/roms (all netplay systems)
#   2. Hash each file; compare against No-Intro dat files or inline table
#   3. If a ROM is "mismatch" (known-bad hash) AND wifi is reachable:
#      queue a canonical download from Internet Archive, marking replace_path
#      so the bad file is swapped out automatically when download completes
#   4. Process the download queue (runs in background via server Popen)
#
# "unknown" ROMs (not in any dat) are left alone — no reference to compare.
# =============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROMS_BASE="/userdata/roms"
RGSX_API="https://api.retroachievements.org/API"
NOINTRO_DATS_DIR="/userdata/system/netplay-arcade/dats"
DAT_CACHE="$NOINTRO_DATS_DIR/.cache.json"
DAT_CHECKER="$SCRIPT_DIR/dat_checker.py"
DOWNLOAD_QUEUE="/tmp/rom_download_queue.json"
LOG_FILE="/tmp/netplay-arcade.log"
DOWNLOAD_LOCK="/tmp/outbreak_download.lock"
SESSION_FILE="/tmp/netplay_session.json"

# Pause downloads while a netplay session is active or the Outbreak UI
# has active SSE clients (ping checks need clean network bandwidth).
# Returns immediately when idle; sleeps in 5s loops while busy.
_wait_if_busy() {
    while [ -f "$SESSION_FILE" ]; do
        sleep 5
    done
}
RGSX_API_KEY=""  # Set in config
RA_USERNAME=""   # RetroAchievements username for RGSX
CONFIG_HELPERS="$SCRIPT_DIR/config-parser.sh"

if [ -f "$CONFIG_HELPERS" ]; then
    # shellcheck source=/dev/null
    . "$CONFIG_HELPERS"
    load_netplay_config "/userdata/system/netplay-arcade/config.cfg"
fi

log() { echo "[$(date '+%H:%M:%S')] ROM: $1" | tee -a "$LOG_FILE"; }

_es_notify() {
    local msg="$1"
    curl -sf --max-time 2 -X POST \
        -H "Content-Type: text/plain" \
        -d "$msg" \
        http://127.0.0.1:1234/notify 2>/dev/null
    return 0
}

_es_reload_gamelists() {
    # Tell EmulationStation to re-read all gamelist.xml files.
    # Non-disruptive: ES stays running, no screen flash.
    curl -sf --max-time 5 http://127.0.0.1:1234/reloadgames 2>/dev/null
    return 0
}

# ─── DOWNLOAD PROGRESS REPORTING (Task 2) ─────────────────────────────────────
report_progress() {
    local key="$1" status="$2" percent="$3" filename="$4"
    curl -s -X POST http://localhost:8765/api/download-progress \
        -H "Content-Type: application/json" \
        -d "{\"key\":\"$key\",\"status\":\"$status\",\"percent\":$percent,\"filename\":\"$filename\"}" &>/dev/null || true
}

# ─── SYSTEMS WITH NETPLAY-COMPATIBLE CORES ───────────────────────────────────
NETPLAY_SYSTEMS="nes snes megadrive genesis gba gb gbc ngp ngpc arcade neogeo mame fbneo atari2600 mastersystem gamegear turbografx16 pcengine nds 32x"
ROM_EXTENSIONS="nes sfc smc fig md gen smd gba gb gbc ngp ngc gdi cdi pce sms gg a26 zip 7z iso chd neo rom unf"

# ─── CANONICAL ARCADE GAME LISTS ─────────────────────────────────────────────
#
# FBNeo: the 585-game non-merged romset from archive.org/details/fbneo_1003_bestset
# is canonical (matches our pinned FBNeo v1.0.0.03 core, BIOS included per ROM).
# Every .zip in /userdata/roms/fbneo/ is treated as a valid ROM.
# FBNEO_TITLES below is a metadata-only lookup for multiplayer-relevant titles
# (display names + max_players for netplay hosting). It does NOT limit which
# ROMs are considered canonical — that's determined by the filesystem.
#
#   MAME_TITLES   — games NOT in FBNeo, sourced from Cylum's collection
#                   archive.org/details/cylums-final-burn-neo-rom-collection
#                   Covers classic pre-0.78 titles absent from FBNeo.
#
# ROM IDs are the zip filenames without extension (canonical MAME/FBNeo names).
# Model 2 / Model 3 / Namco System 22 (Virtua Fighter, Daytona, Ridge Racer)
# are excluded — 3D hardware has no savestate support and cannot do netplay.
# ─────────────────────────────────────────────────────────────────────────────

declare -A FBNEO_TITLES=(
    # Format: "Display Name|max_players"
    # max_players caps local_players when hosting so remote clients always
    # have at least one free port. 2P = 1v1 fighters / single-player originals;
    # higher numbers = co-op beat-em-ups and multi-player cabinets.
    # ── Capcom CPS-1 ──────────────────────────────────────────────────────────
    ["sf2"]="Street Fighter II: The World Warrior|2"
    ["sf2ce"]="Street Fighter II: Champion Edition|2"
    ["sf2hf"]="Street Fighter II: Hyper Fighting|2"
    ["ssf2"]="Super Street Fighter II|2"
    ["ssf2t"]="Super Street Fighter II Turbo|2"
    ["sfa"]="Street Fighter Alpha|2"
    ["sfa2"]="Street Fighter Alpha 2|2"
    ["sfa3"]="Street Fighter Alpha 3|2"
    ["ffight"]="Final Fight|2"
    ["ffight2"]="Final Fight 2|2"
    ["ffight3"]="Final Fight 3|2"
    ["punisher"]="The Punisher|2"
    ["avsp"]="Alien vs. Predator|3"
    ["dino"]="Cadillacs and Dinosaurs|2"
    ["ddsom"]="Dungeons & Dragons: Shadow over Mystara|4"
    ["knights"]="Knights of the Round|3"
    ["captcomm"]="Captain Commando|4"
    ["megaman"]="Mega Man: The Power Battle|2"
    ["megaman2"]="Mega Man 2: The Power Fighters|2"
    # ── Capcom CPS-2 ──────────────────────────────────────────────────────────
    ["msh"]="Marvel Super Heroes|2"
    ["mshvsf"]="Marvel Super Heroes vs. Street Fighter|2"
    ["mvsc"]="Marvel vs. Capcom: Clash of Super Heroes|2"
    ["xmvsf"]="X-Men vs. Street Fighter|2"
    ["xmcota"]="X-Men: Children of the Atom|2"
    ["nwarr"]="Night Warriors: Darkstalkers' Revenge|2"
    ["vsav"]="Vampire Savior|2"
    ["vsav2"]="Vampire Savior 2|2"
    ["progear"]="Progear|2"
    ["19xx"]="19XX: The War Against Destiny|2"
    ["dimahoo"]="Dimahoo|2"
    # ── Capcom CPS-3 ──────────────────────────────────────────────────────────
    ["sfiii3"]="Street Fighter III: 3rd Strike|2"
    ["sfiii2"]="Street Fighter III: 2nd Impact|2"
    ["sfiii"]="Street Fighter III: New Generation|2"
    ["jojoba"]="JoJo's Bizarre Adventure|2"
    ["redearth"]="Red Earth|2"
    # ── SNK Neo Geo ───────────────────────────────────────────────────────────
    ["kof94"]="King of Fighters '94|2"
    ["kof95"]="King of Fighters '95|2"
    ["kof96"]="King of Fighters '96|2"
    ["kof97"]="King of Fighters '97|2"
    ["kof98"]="King of Fighters '98|2"
    ["kof99"]="King of Fighters '99|2"
    ["kof2000"]="King of Fighters 2000|2"
    ["kof2001"]="King of Fighters 2001|2"
    ["kof2002"]="King of Fighters 2002|2"
    ["kof2003"]="King of Fighters 2003|2"
    ["garou"]="Garou: Mark of the Wolves|2"
    ["samsho"]="Samurai Shodown|2"
    ["samsho2"]="Samurai Shodown II|2"
    ["samsho3"]="Samurai Shodown III|2"
    ["samsho4"]="Samurai Shodown IV|2"
    ["samsho5s"]="Samurai Shodown V Special|2"
    ["rbff2"]="Real Bout Fatal Fury 2|2"
    ["rbffspec"]="Real Bout Fatal Fury Special|2"
    ["fatfury1"]="Fatal Fury: King of Fighters|2"
    ["fatfury3"]="Fatal Fury 3|2"
    ["fatfursp"]="Fatal Fury Special|2"
    ["mslug"]="Metal Slug|2"
    ["mslug2"]="Metal Slug 2|2"
    ["mslug3"]="Metal Slug 3|2"
    ["mslug4"]="Metal Slug 4|2"
    ["mslug5"]="Metal Slug 5|2"
    ["mslugx"]="Metal Slug X|2"
    ["wh1"]="World Heroes|2"
    ["wh2"]="World Heroes 2|2"
    ["wh2j"]="World Heroes 2 Jet|2"
    ["whp"]="World Heroes Perfect|2"
    ["kizuna"]="Kizuna Encounter|2"
    ["neobombe"]="Neo Bomberman|2"
    ["pulstar"]="Pulstar|2"
    ["blazstar"]="Blazing Star|2"
    ["lastblad2"]="The Last Blade 2|2"
    # ── Midway / Strata (Y-Unit / Wolf Unit / T-Unit) ──────────────────────────
    ["timekill"]="Time Killers|2"
    ["mk"]="Mortal Kombat|2"
    ["mk2"]="Mortal Kombat II|2"
    ["mk3"]="Mortal Kombat 3|2"
    ["umk3"]="Ultimate Mortal Kombat 3|2"
    ["nbajam"]="NBA Jam|2"
    ["nbajamte"]="NBA Jam Tournament Edition|2"
    ["nbahangt"]="NBA Hangtime (Tournament)|4"
    ["narc"]="NARC|2"
    ["smashtv"]="Smash TV|2"
    ["totcarn"]="Total Carnage|2"
    # ── Konami ────────────────────────────────────────────────────────────────
    ["tmnt"]="Teenage Mutant Ninja Turtles|4"
    ["tmnt22pu"]="TMNT: Turtles in Time (2 Players)|2"
    ["simpsons2p"]="The Simpsons (2 Players)|2"
    ["xmen"]="X-Men|4"
    ["sunset"]="Sunset Riders|4"
    ["vendetta2pu"]="Vendetta (2 Players)|2"
    ["ddcrew2"]="D.D. Crew (2 Players)|2"
    # ── Cave ──────────────────────────────────────────────────────────────────
    ["dfeveron"]="Dangun Feveron|2"
    ["esprade"]="ESP Ra.De.|2"
    ["guwange"]="Guwange|2"
    ["donpachi"]="DonPachi|2"
    ["ddonpach"]="DoDonPachi|2"
    ["ibara"]="Ibara|2"
    ["ibarablk"]="Ibara Black Label|2"
    ["mushisam"]="Mushihimesama|2"
    ["espgal"]="Espgaluda|2"
    ["espgal2"]="Espgaluda II|2"
    ["ket"]="Ketsui: Kizuna Jigoku Tachi|2"
    ["batrider"]="Armed Police Batrider|2"
    ["bgaregga"]="Battle Garegga|2"
    # ── Capcom CPS-2 (additional) ─────────────────────────────────────────────
    ["dstlk"]="Darkstalkers: The Night Warriors|2"
    ["ecofghtr"]="Eco Fighters|2"
    ["armwar"]="Armored Warriors|3"
    ["batcir"]="Battle Circuit|4"
    ["cybots"]="Cyberbots: Full Metal Madness|2"
    ["ringdest"]="Ring of Destruction: Slammasters II|2"
    # ── Capcom CPS-1 (additional) ─────────────────────────────────────────────
    ["slammast"]="Saturday Night Slam Masters|4"
    # ── Konami (System GX / TMNT hardware) ────────────────────────────────────
    ["contra"]="Contra|2"
    ["scontra"]="Super Contra|2"
    ["gradius"]="Gradius|2"
    ["gradius2"]="Gradius II: Gofer's Ambition|2"
    ["lifefrce"]="Life Force|2"
    ["salamand"]="Salamander|2"
    ["mystwarr"]="Mystic Warriors|4"
    ["viostorm"]="Violent Storm|4"
    ["asterix"]="Asterix|4"
    ["crimfght"]="Crime Fighters|4"
    ["bucky"]="Bucky O'Hare|4"
    ["moomesa"]="Wild West C.O.W.-Boys of Moo Mesa|4"
    ["metamrph"]="Metamorphic Force|4"
    # ── SNK Neo Geo (additional) ──────────────────────────────────────────────
    ["aof"]="Art of Fighting|2"
    ["aof2"]="Art of Fighting 2|2"
    ["aof3"]="Art of Fighting 3: Path of the Warrior|2"
    ["shocktro"]="Shock Troopers|2"
    ["shocktr2"]="Shock Troopers: 2nd Squad|2"
    ["matrim"]="Matrimelee|2"
    ["rotd"]="Rage of the Dragons|2"
    ["breakrev"]="Breakers Revenge|2"
    ["ninjamas"]="Ninja Masters|2"
    ["nam1975"]="NAM-1975|2"
    ["maglord"]="Magician Lord|2"
    ["crsword"]="Crossed Swords|2"
    ["lbowling"]="League Bowling|2"
    ["turfmast"]="Neo Turf Masters|2"
    ["s1945p"]="Strikers 1945 Plus|2"
    ["twinspri"]="Twinkle Star Sprites|2"
    ["wjammers"]="Windjammers|2"
    ["sengoku"]="Sengoku|3"
    ["sengoku2"]="Sengoku 2|3"
    ["sengoku3"]="Sengoku 3|2"
    ["ncommand"]="Ninja Commando|2"
    ["viewpoin"]="Viewpoint|2"
    # ── Sega / Konami early hardware (FBNeo) ──────────────────────────────────
    ["wboy"]="Wonder Boy|2"
    ["blktiger"]="Black Tiger|2"
    ["gyruss"]="Gyruss|2"
    ["timeplt"]="Time Pilot|2"
    ["yiear"]="Yie Ar Kung-Fu|2"
    ["rastan"]="Rastan|2"
    ["captaven"]="Captain America and the Avengers|4"
    # ── Psikyo ────────────────────────────────────────────────────────────────
    ["s1945"]="Strikers 1945|2"
    ["s1945ii"]="Strikers 1945 II|2"
    ["s1945iii"]="Strikers 1945 III|2"
    ["gunbird"]="Gunbird|2"
    ["gunbird2"]="Gunbird 2|2"
    ["soldivid"]="Sol Divide|2"
    ["dragnblz"]="Dragon Blaze|2"
    # ── Technos ───────────────────────────────────────────────────────────────
    ["ddragon"]="Double Dragon|2"
    ["ddragon2"]="Double Dragon II: The Revenge|2"
    ["ddragon3"]="Double Dragon III: The Rosetta Stone|3"
    ["wwfsstar"]="WWF Superstars|4"
    ["wwfwfest"]="WWF WrestleFest|4"
    # ── Irem (M72 / M92 / M107) ───────────────────────────────────────────────
    ["rtype"]="R-Type|2"
    ["rtype2"]="R-Type II|2"
    ["rtypeleo"]="R-Type Leo|2"
    ["inthunt"]="In the Hunt|2"
    ["uccops"]="Undercover Cops|4"
    ["nspirit"]="Ninja Spirit|2"
    # ── Taito (B / F2 / F3 hardware) ─────────────────────────────────────────
    ["bublbobl"]="Bubble Bobble|2"
    ["pbobble"]="Puzzle Bobble|2"
    ["pbobble3"]="Puzzle Bobble 3|2"
    ["pbobblen"]="Puzzle Bobble (Neo Geo)|2"
    ["growl"]="Growl|4"
    ["cadash"]="Cadash|4"
    # ── Sega System 16 / System 18 ────────────────────────────────────────────
    ["goldnaxe"]="Golden Axe|2"
    ["ga2"]="Golden Axe: The Revenge of Death Adder|4"
    ["altbeast"]="Altered Beast|2"
    ["shinobi"]="Shinobi|2"
    ["astorm"]="Alien Storm|3"
    ["mwalk"]="Michael Jackson's Moonwalker|3"
    ["outrun"]="Out Run|2"
    ["ddcrew"]="D.D. Crew|3"
    ["spidman"]="Spider-Man: The Videogame|4"
    ["aliens"]="Aliens|2"
    # ── Irem (additional) ────────────────────────────────────────────────────
    ["gunforc2"]="Gunforce 2|2"
    ["airduel"]="Air Duel|2"
    # ── Seibu Kaihatsu ───────────────────────────────────────────────────────
    ["raiden"]="Raiden|2"
    ["raiden2"]="Raiden II|2"
    ["raidendx"]="Raiden DX|2"
    # ── Video System / Kaneko ────────────────────────────────────────────────
    ["aerofgt"]="Aero Fighters|2"
    ["airbustr"]="Air Buster|2"
    # ── Banpresto ────────────────────────────────────────────────────────────
    ["airgallet"]="Air Gallet|2"
    # ── Jaleco / Success ─────────────────────────────────────────────────────
    ["cyvern"]="Cyvern: The Dragon Weapons|2"
    ["cotton"]="Cotton: Fantastic Night Dreams|2"
    # ── Data East (FBNeo) ────────────────────────────────────────────────────
    ["fighthist"]="Fighter's History|2"
    # ── Taito (additional) ───────────────────────────────────────────────────
    ["dariusg"]="Darius Gaiden|2"
    ["rayforce"]="RayForce|2"
    ["elevator"]="Elevator Action|2"
    ["spcinv95"]="Space Invaders DX|2"
    ["puzbobl2"]="Puzzle Bobble 2|2"
    # ── Namco classics (in FBNeo) ────────────────────────────────────────────
    ["pacman"]="Pac-Man|2"
    ["mspacman"]="Ms. Pac-Man|2"
    ["rallyx"]="Rally-X|2"
    ["nrallyx"]="New Rally-X|2"
    ["mappy"]="Mappy|2"
    ["xevious"]="Xevious|2"
    ["pacland"]="Pac-Land|2"
    ["gaplus"]="Gaplus|2"
    ["bosconian"]="Bosconian|2"
    ["phozon"]="Phozon|2"
    ["libblerab"]="Libble Rabble|2"
    ["kingball"]="King & Balloon|2"
    # ── Konami early (in FBNeo) ──────────────────────────────────────────────
    ["pooyan"]="Pooyan|2"
    ["scramble"]="Scramble|2"
    ["suprcobra"]="Super Cobra|2"
    # ── Classic shooters (in FBNeo) ──────────────────────────────────────────
    ["phoenix"]="Phoenix|2"
    # ── Midway / Williams (in FBNeo) ─────────────────────────────────────────
    ["term2"]="Terminator 2: Judgment Day|2"
    # ── Atari (in FBNeo) ─────────────────────────────────────────────────────
    ["astdelux"]="Asteroids Deluxe|2"
    ["centiped"]="Centipede|2"
    ["milliped"]="Millipede|2"
    ["gravitar"]="Gravitar|2"
    ["llander"]="Lunar Lander|2"
    ["foodf"]="Food Fight|2"
    # ── Other classics (in FBNeo) ────────────────────────────────────────────
    ["renegade"]="Renegade|2"
    ["reactor"]="Reactor|2"
    ["jrpacman"]="Jr. Pac-Man|2"
    ["kungfum"]="Kung-Fu Master|2"
    ["hyperspt"]="Hyper Sports|4"
    ["rocnrope"]="Roc 'n Rope|2"
    # ── SNK / other (in FBNeo) ───────────────────────────────────────────────
    ["powerins"]="Power Instinct|2"
    ["omegaf"]="Omega Fighter|2"
    ["androdun"]="Andro Dunos|2"
    ["mutnat"]="Mutation Nation|2"
    ["hitice"]="Hit the Ice|4"
    # ── PGM (in FBNeo) ───────────────────────────────────────────────────────
    ["kov"]="Knights of Valour|2"
    ["kovsh"]="Knights of Valour: Super Heroes|2"
    ["kovshp"]="Knights of Valour: Super Heroes Plus|2"
    ["kov2"]="Knights of Valour 2|2"
    ["ddp2"]="DoDonPachi DaiOuJou|2"
    ["ddp3"]="DoDonPachi DaiFukkatsu|2"
    # ── Additional multiplayer titles (from FBNeo Best Set gamelist) ────────
    ["10yard"]="10-Yard Fight|2"
    ["1941"]="1941 - Counter Attack|2"
    ["1942"]="1942|2"
    ["1943"]="1943 - The Battle Of Midway|2"
    ["1943kai"]="1943 Kai - Midway Kaisen|2"
    ["1944u"]="1944 - The Loop Master|2"
    ["1945kiii"]="1945k 3|2"
    ["3stooges"]="Three Stooges In Brides Is Brides, The|3"
    ["3wonders"]="Three Wonders|2"
    ["64street"]="64th. Street - A Detective Story|2"
    ["acrobatm"]="Acrobat Mission|2"
    ["actfancr"]="Act-fancer Cybernetick Hyper Weapon|2"
    ["afighter"]="Action Fighter|2"
    ["airass"]="Air Assault|2"
    ["airattck"]="Air Attack|2"
    ["ajax"]="Ajax|2"
    ["alcon"]="Slap Fight|2"
    ["alexkidd"]="Alex Kidd - The Lost Stars|2"
    ["aliensyn"]="Alien Syndrome|2"
    ["aligator"]="Alligator Hunt|2"
    ["alphamis"]="Aso - Armored Scrum Object|2"
    ["alpine"]="Alpine Ski|2"
    ["amidar"]="Amidar|2"
    ["anteater"]="Anteater|2"
    ["arabian"]="Arabian|2"
    ["arabianm"]="Arabian Magic|4"
    ["arknoid2"]="Arkanoid - Revenge Of Doh|2"
    ["armedf"]="Armed Formation|2"
    ["asteroid"]="Asteroids|2"
    ["astyanax"]="Astyanax, The|2"
    ["asurabld"]="Asura Blade - Sword Of Dynasty|2"
    ["asurabus"]="Asura Buster - Eternal Warriors|2"
    ["athena"]="Athena|2"
    ["atlantis"]="Battle Of Atlantis|2"
    ["aurail"]="Aurail|2"
    ["avengers"]="Avengers|2"
    ["avengrgs"]="Avengers In Galactic Storm|2"
    ["avspirit"]="Avenging Spirit|2"
    ["badlands"]="Bad Lands|2"
    ["bagman"]="Bagman|2"
    ["bakutotu"]="Bakutotsu Kijuutei|2"
    ["bankp"]="Bank Panic|2"
    ["baraduke"]="Alien Sector|2"
    ["batsugun"]="Batsugun|2"
    ["battlnts"]="Battlantis|2"
    ["battroad"]="Battle-road, The|2"
    ["bbakraid"]="Battle Bakraid - Unlimited Version|2"
    ["bbmanw"]="Bomber Man World / New Dyna Blaster - Global Quest|4"
    ["bbros"]="Pang|2"
    ["bbusters"]="Beast Busters|3"
    ["bchopper"]="Battle Chopper|2"
    ["berlwall"]="Berlin Wall, The|2"
    ["bionicc1"]="Bionic Commando|2"
    ["bioship"]="Bio-ship Paladin|2"
    ["bladestl"]="Blades Of Steel|2"
    ["blandia"]="Blandia|2"
    ["blaster"]="Blaster|2"
    ["blazeon"]="Blaze On|2"
    ["blazer"]="Blazer|2"
    ["blkheart"]="Black Heart|2"
    ["blkhole"]="Black Hole|2"
    ["blockcar"]="Block Carnival / Thunder And Lightning 2|2"
    ["bloodbro"]="Blood Bros.|2"
    ["bloodstm"]="Blood Storm|2"
    ["bloodwar"]="Blood Warrior|2"
    ["bloxeed"]="Bloxeed|2"
    ["blswhstl"]="Bells And Whistles|2"
    ["bluehawk"]="Blue Hawk|2"
    ["blzntrnd"]="Blazing Tornado|4"
    ["bmaster"]="Blade Master|2"
    ["bnj"]="Burnin' Rubber|2"
    ["bnzabros"]="Bonanza Bros|2"
    ["bombbee"]="Bomb Bee|2"
    ["bombjack"]="Bomb Jack|2"
    ["bonkadv"]="B.c. Kid|2"
    ["bonzeadv"]="Bonze Adventure|2"
    ["boogwingu"]="Boogie Wings|2"
    ["brapboys"]="B.rap Boys|3"
    ["brkthru"]="Break Thru|2"
    ["btime"]="BurgerTime|2"
    ["btlkroad"]="Battle K-road|2"
    ["btoads"]="Battletoads|3"
    ["bubblem"]="Bubble Memories - The Story Of Bubble Bobble 3|2"
    ["bubbles"]="Bubbles|2"
    ["bubsymphu"]="Bubble Bobble 2|2"
    ["burnforc"]="Burning Force|2"
    ["bwings"]="B-wings|2"
    ["cairblad"]="Change Air Blade|2"
    ["calibr50"]="Caliber 50|2"
    ["cameltry"]="Cameltry|2"
    ["canyon"]="Canyon Bomber|2"
    ["capbowl"]="Capcom Bowling|4"
    ["cawing"]="Carrier Air Wing|2"
    ["ccastles"]="Crystal Castles|2"
    ["cclimber"]="Crazy Climber|2"
    ["cclimbr2"]="Crazy Climber 2|2"
    ["chainrec"]="Chain Reaction|2"
    ["chameleo"]="Chameleon|2"
    ["champwr"]="Champion Wrestler|2"
    ["charlien"]="Charlie Ninja|2"
    ["chelnov"]="Chelnov - Atomic Runner|2"
    ["chinagat"]="China Gate|2"
    ["chopliftu"]="Choplifter|2"
    ["chopper"]="Chopper I|2"
    ["chukatai"]="Chuka Taisen|2"
    ["circusc"]="Circus Charlie|2"
    ["citybomb"]="City Bomber|2"
    ["citycon"]="City Connection|2"
    ["clapapa"]="Rootin' Tootin' / La-pa-pa|2"
    ["cleopatr"]="Cleopatra Fortune|2"
    ["cninja"]="Caveman Ninja|2"
    ["cobracom"]="Cobra-command|2"
    ["congo"]="Congo Bongo|2"
    ["cosmccop"]="Cosmic Cop|2"
    ["cosmogng"]="Cosmo Gang The Video|2"
    ["crbaloon"]="Crazy Balloon|2"
    ["crimec"]="Crime City|2"
    ["crkdown"]="Crack Down|2"
    ["crshrace"]="Lethal Crash Race|2"
    ["ctribe"]="Combatribes, The|3"
    ["cybattlr"]="Cybattler|2"
    ["daioh"]="Daioh|2"
    ["dangseed"]="Dangerous Seed|2"
    ["daraku"]="Daraku Tenshi - The Fallen Angels|2"
    ["darius"]="Darius|2"
    ["darkadv"]="Devil World|2"
    ["darkmist"]="Lost Castle In Darkmist, The|2"
    ["darktowr"]="Dark Tower|2"
    ["darwin"]="Darwin 4078|2"
    ["dassault"]="Thunder Zone|4"
    ["dblewing"]="Double Wings|2"
    ["dbreed"]="Dragon Breed|2"
    ["dbz"]="Dragonball Z|2"
    ["ddribble"]="Double Dribble|2"
    ["ddtod"]="Dungeons And Dragons - Tower Of Doom|4"
    ["ddux"]="Dynamite Dux|2"
    ["deadang"]="Dead Angle|2"
    ["deadconx"]="Dead Connection|2"
    ["defender"]="Defender|2"
    ["demonwld"]="Demon's World / Horror Story|2"
    ["denjinmk"]="Denjin Makai|2"
    ["desertbr"]="Desert Breaker|3"
    ["devstors"]="Devastators|2"
    ["dharma"]="Dharma Doujou|2"
    ["dinorex"]="Dino Rex|2"
    ["djboy"]="Dj Boy|2"
    ["dkong3"]="Donkey Kong 3|2"
    ["dmnfrnt"]="Demon Front|2"
    ["docastle"]="Mr. Do's Castle|2"
    ["dogyuun"]="Dogyuun|2"
    ["dondokod"]="Don Doko Don|2"
    ["dotron"]="Discs Of Tron|2"
    ["dowild"]="Mr. Do's Wild Ride|2"
    ["drakton"]="Drakton|2"
    ["dreamwld"]="Dream World|2"
    ["drgnbstr"]="Dragon Buster|2"
    ["drgnmst"]="Dragon Master|2"
    ["drgnunit"]="Dragon Unit / Castle Of Dragon|2"
    ["driftout"]="Drift Out|2"
    ["dsaber"]="Dragon Saber|2"
    ["dspirit"]="Dragon Spirit|2"
    ["dtfamily"]="Diet Family|2"
    ["dualaslt"]="Liberation|2"
    ["dungeonm"]="Dungeon Magic|4"
    ["dunkshot"]="Dunk Shot|4"
    ["dynablst"]="Dynablaster / Bomber Man|2"
    ["dynagear"]="Dyna Gear|2"
    ["dynwar"]="Dynasty Wars|2"
    ["eaglshot"]="Eagle Shot Golf|4"
    ["earthjkr"]="U.n. Defense Force - Earth Joker|2"
    ["edf"]="E.d.f. - Earth Defense Force|2"
    ["edrandy"]="Cliff Hanger - Edward Randy|2"
    ["eightfrc"]="Eight Forces|2"
    ["elim2"]="Eliminator|4"
    ["elvactr"]="Elevator Action Returns|2"
    ["empcityu"]="Empire City - 1931|2"
    ["eprom"]="Escape From The Planet Of The Robot Monsters|2"
    ["esckids"]="Escape Kids|4"
    ["eswat"]="E-swat - Cyber Police|2"
    ["explbrkr"]="Explosive Breaker|2"
    ["exprraid"]="Express Raider|2"
    ["exterm"]="Exterminator|2"
    ["extrmatn"]="Extermination|2"
    ["f1dreamb"]="F-1 Dream|2"
    ["fantzn2x"]="Fantasy Zone II - The Tears of Opa-Opa (2008)|2"
    ["fantzone"]="Fantasy Zone|2"
    ["fastlane"]="Fast Lane|2"
    ["feversos"]="Fever Sos|2"
    ["fghthist"]="Fighter's History|2"
    ["fhawk"]="Fighting Hawk|2"
    ["finalizr"]="Finalizer - Super Transformation|2"
    ["fireshrk"]="Fire Shark|2"
    ["flicky"]="Flicky|2"
    ["flstory"]="Fairyland Story, The|2"
    ["flytiger"]="Flying Tiger|2"
    ["forgottn"]="Forgotten Worlds|2"
    ["frenzy"]="Frenzy|2"
    ["frontlin"]="Front Line|2"
    ["fround"]="Final Round, The|2"
    ["fstarfrc"]="Final Star Force|2"
    ["gaia"]="Gaia Crusaders|2"
    ["gaialast"]="Gaia - The Last Choice Of Earth|2"
    ["gaiapols"]="Gaiapolis|2"
    ["gaiden"]="Shadow Warriors|2"
    ["galaga3"]="Gaplus|2"
    ["galaga88"]="Galaga '88|2"
    ["galivan"]="Cosmo Police Galivan|2"
    ["galmedes"]="Galmedes|2"
    ["gametngk"]="Game Paradise - Master Of Shooting! / Game Tengoku - The Game Paradise, The|2"
    ["gardia"]="Gardia|2"
    ["garyoret"]="Garyo Retsuden|2"
    ["gatedoom"]="Dark Seal|2"
    ["gaunt2"]="Gauntlet 2|4"
    ["gauntlet"]="Gauntlet|4"
    ["gblchmp"]="Kaiser Knuckle|2"
    ["gbusters"]="Gang Busters|2"
    ["geebeeg"]="Gee Bee|2"
    ["gekiridn"]="Gekirindan|2"
    ["gemini"]="Gemini Wing|2"
    ["genpeitd"]="Genpei Toumaden|2"
    ["gground"]="Gain Ground|3"
    ["ghostb"]="Real Ghostbusters, The|3"
    ["ghoxj"]="Ghox|2"
    ["gigandes"]="Gigandes|2"
    ["gigawing"]="Giga Wing|2"
    ["gijoe"]="G.i. Joe|4"
    ["ginganin"]="Ginga Ninkyouden|2"
    ["gladiatr"]="Gladiator|2"
    ["gogomile"]="Susume! Mile Smile / Go Go! Mile Smile|2"
    ["gondo"]="Gondomania|2"
    ["gradius3"]="Gradius 3|2"
    ["grdian"]="Guardian|2"
    ["grdians"]="Guardians / Denjin Makai 2|2"
    ["grobda"]="Grobda|2"
    ["gseeker"]="Grid Seeker - Project Storm Hammer|2"
    ["gstream"]="G-stream G2020|2"
    ["gtsupreme"]="Golden Tee 2k|4"
    ["gulfstrm"]="Gulf Storm|2"
    ["gulfwar2"]="Gulf War 2|2"
    ["gunbustr"]="Gunbuster|2"
    ["gunforce"]="Gunforce - Battle Fire Engulfed Terror Island|2"
    ["gunfront"]="Gun And Frontier|2"
    ["gunlock"]="Gunlock|2"
    ["gunnail"]="Gunnail|2"
    ["gunsmoke"]="Gun.smoke|2"
    ["gwarrior"]="Galactic Warriors|2"
    ["gyrodine"]="Gyrodine|2"
    ["hachamfb"]="Hacha Mecha Fighter|2"
    ["hal21"]="Hal21|2"
    ["hardhea2"]="Hard Head 2|2"
    ["hardhead"]="Hard Head|2"
    ["hatris"]="Hatris|2"
    ["hcastle"]="Haunted Castle|2"
    ["hellfire"]="Hellfire|2"
    ["hexion"]="Hexion|2"
    ["hharry"]="Hammerin' Harry|2"
    ["hiimpact"]="High Impact Football|4"
    ["hippodrm"]="Hippodrome|2"
    ["hook"]="Hook|4"
    ["hoops96"]="Hoops|4"
    ["hopmappy"]="Hopping Mappy|2"
    ["horizon"]="Horizon|2"
    ["hotdogst"]="Hotdog Storm|2"
    ["hsf2"]="Hyper Street Fighter 2 - The Anniversary Edition|2"
    ["hvymetal"]="Heavy Metal|2"
    ["hvysmsh"]="Heavy Smash|2"
    ["hvyunit"]="Heavy Unit|2"
    ["hyprduel"]="Hyper Duel|2"
    ["ikari3"]="Ikari 3 - The Rescue|2"
    ["imgfight"]="Image Fight|2"
    ["imsorry"]="I'm Sorry|2"
    ["insectx"]="Insector X|2"
    ["invaders"]="Space Invaders / Space Invaders M|2"
    ["ironhors"]="Iron Horse|2"
    ["jackal"]="Jackal|2"
    ["jailbrek"]="Jail Break|2"
    ["jchan"]="Jackie Chan - The Kung-fu Master|2"
    ["jjsquawk"]="J. J. Squawkers|2"
    ["joemacr"]="Joe And Mac Returns|2"
    ["jojo"]="Jojo's Venture|2"
    ["journey"]="Journey|2"
    ["joust"]="Joust|2"
    ["jungleh"]="Jungle Hunt|2"
    ["junofrst"]="Juno First|2"
    ["kangaroo"]="Kangaroo|2"
    ["karatblz"]="Karate Blazers|4"
    ["karianx"]="Karian Cross|2"
    ["karnov"]="Karnov|2"
    ["kazan"]="Ninja Kazan|2"
    ["kbash"]="Knuckle Bash|2"
    ["kchamp"]="Karate Champ|2"
    ["kidniki"]="Kid Niki - Radical Ninja|2"
    ["kikcubic"]="Meikyu Jima|2"
    ["kikikai"]="Kiki Kaikai|2"
    ["killbld"]="Killing Blade, The|2"
    ["kingdmgp"]="Kingdom Grandprix|2"
    ["klax"]="Klax|2"
    ["kncljoe"]="Knuckle Joe|2"
    ["kod"]="King Of Dragons, The|3"
    ["konami88"]="'88 Games|2"
    ["kroozr"]="Kozmik Kroozr|2"
    ["krull"]="Krull|2"
    ["kurikint"]="Kuri Kinton|2"
    ["kyros"]="Kyros|2"
    ["ladybug"]="Lady Bug|2"
    ["lastduel"]="Last Duel|2"
    ["lastmisn"]="Last Mission|2"
    ["lastsurv"]="Last Survivor|2"
    ["ldrun"]="Lode Runner|2"
    ["ldrun2"]="Lode Runner 2 - The Bungeling Strikes Back|2"
    ["ldrun3"]="Lode Runner 3 - The Golden Labyrinth|2"
    ["ldrun4"]="Lode Runner 4 - Teikoku Karano Dasshutsu|2"
    ["ledstorm"]="Led Storm|2"
    ["legend"]="Legend|2"
    ["legion"]="Legion - Spinner-87|2"
    ["legionna"]="Legionnaire|2"
    ["lethalth"]="Lethal Thunder|2"
    ["lgtnfght"]="Lightning Fighters|2"
    ["liquidk"]="Liquid Kids|2"
    ["lkage"]="Legend Of Kage, The|2"
    ["lnc"]="Lock'n'chase|2"
    ["locomotn"]="Loco-motion|2"
    ["loderndf"]="Lode Runner - The Dig Fight|2"
    ["loffire"]="Line Of Fire / Bakudan Yarou|2"
    ["loht"]="Legend Of Hero Tonma|2"
    ["lomakai"]="Legend Of Makai|2"
    ["lotlot"]="Lot Lot|2"
    ["ltswords"]="Lightning Swords|2"
    ["luckywld"]="Lucky And Wild|2"
    ["lwings"]="Legendary Wings|2"
    ["macross"]="Super Spacefortress Macross / Chou-jikuu Yousai Macross|2"
    ["macross2"]="Super Spacefortress Macross 2 / Chou-jikuu Yousai Macross 2|2"
    ["macrossp"]="Macross Plus|2"
    ["svg"]="S.v.g. - Spectral Vs Generation|2"
    # ── Moved from MAME (FBNeo ROM exists in Best Set) ─────────────────────
    ["arkanoid"]="Arkanoid|2"
    ["baddudes"]="Bad Dudes vs. DragonNinja|2"
    ["berzerk"]="Berzerk|2"
    ["cabal"]="Cabal|2"
    ["commando"]="Commando|2"
    ["digdug"]="Dig Dug|2"
    ["digdug2"]="Dig Dug II|2"
    ["dkong"]="Donkey Kong|2"
    ["dkongjr"]="Donkey Kong Jr.|2"
    ["frogger"]="Frogger|2"
    ["galaga"]="Galaga|2"
    ["galaxian"]="Galaxian|2"
    ["ghouls"]="Ghouls'n Ghosts|2"
    ["gwar"]="Guerrilla War|2"
    ["hbarrel"]="Heavy Barrel|2"
    ["ikari"]="Ikari Warriors|2"
    ["mario"]="Mario Bros.|2"
    ["mercs"]="Mercs|3"
    ["mrdo"]="Mr. Do!|2"
    ["opwolf"]="Operation Wolf|2"
    ["othunder"]="Operation Thunderbolt|2"
    ["pow"]="P.O.W.: Prisoners of War|2"
    ["punchout"]="Punch-Out!!|2"
    ["rampage"]="Rampage|3"
    ["robocop"]="RoboCop|2"
    ["rthunder"]="Rolling Thunder|2"
    ["splatter"]="Splatterhouse|2"
    ["tapper"]="Tapper|2"
    ["tnk3"]="T.N.K. III|2"
    ["todruaga"]="The Tower of Druaga|2"
    ["tron"]="Tron|2"
    ["zaxxon"]="Zaxxon|2"
    ["gng"]="Ghosts'n Goblins|2"
    ["mpatrol"]="Moon Patrol|2"
    ["tumblep"]="Tumble Pop|2"
    ["shadfrce"]="Shadow Force|3"
    ["nslasheru"]="Night Slashers|3"
)

declare -A MAME_TITLES=(
    # Games that need MAME cores (not in FBNeo romset).
    # Sourced from MAME 2003-Plus or Cylum's collection.
    # Format: "Display Name|max_players"
    # ── Konami (MAME only — games not already in FBNEO_TITLES) ─────────────
    ["crimfght2"]="Crime Fighters 2|4"
    ["runngun"]="Run and Gun|4"
    # ── Konami light-gun ─────────────────────────────────────────────────────
    ["lethalen2"]="Lethal Enforcers II|2"
    # ── Midway / Williams / Atari (MAME only) ────────────────────────────────
    ["kinst"]="Killer Instinct|2"
    ["kinst2"]="Killer Instinct 2|2"
    ["joust2"]="Joust 2|2"
    ["primalrg"]="Primal Rage|2"
    ["area51"]="Area 51|2"
    ["revolx"]="Revolution X|2"
    ["mace"]="Mace: The Dark Age|2"
    # ── Namco (MAME only) ────────────────────────────────────────────────────
    ["polepos"]="Pole Position|2"
    ["polepos2"]="Pole Position II|2"
    ["pacmania"]="Pac-Mania|2"
    ["pacandpal"]="Pac & Pal|2"
    ["suprpac"]="Super Pac-Man|2"
    # ── Namco / Sega light-gun (MAME only) ───────────────────────────────────
    ["pointblk"]="Point Blank|2"
    ["timecris"]="Time Crisis|2"
    ["housedead"]="The House of the Dead|2"
    # ── Sega (MAME only) ─────────────────────────────────────────────────────
    ["goldaxe2"]="Golden Axe II|2"
    ["arabianf"]="Arabian Fight|4"
    # ── Data East / Technos (MAME only) ──────────────────────────────────────
    ["joemac"]="Joe & Mac: Caveman Ninja|2"
    # ── Nintendo (MAME only) ──────────────────────────────────────────────────
    ["mariobro"]="Mario Bros. (alternate)|2"
    # ── Classic shooters / action (MAME only) ─────────────────────────────────
    ["wizwor"]="Wizard of Wor|2"
    ["qbert2"]="Q*bert's Qubes|2"
    ["karate"]="Karate Champ|2"
    ["indytemp"]="Indiana Jones: Temple of Doom|2"
    ["battlezone"]="Battlezone|2"
    # ── Atari (MAME only) ─────────────────────────────────────────────────────
    ["paperboy"]="Paperboy|2"
    ["marble"]="Marble Madness|2"
    ["roadblst"]="Road Blasters|2"
    ["ssprint"]="Super Sprint|3"
    ["warlords"]="Warlords|4"
    # ── Light gun (MAME only) ────────────────────────────────────────────────
    ["judgedrd"]="Judge Dredd|2"
)

# Console ROM verification is handled by dat_checker.py reading .dat files
# from $NOINTRO_DATS_DIR. Drop No-Intro DATs there and the cache rebuilds
# automatically on boot. See scripts/dat_checker.py for details.

# ─── CONSOLE CANONICAL GAME LISTS ────────────────────────────────────────────
# Per-system curated multiplayer libraries. Used for library health reporting
# in the boot scan and for Smart Join ROM resolution (ia_collection_for lookup).
# Key: No-Intro filename stem. Value: "Short Display Name|max_players".
# ─────────────────────────────────────────────────────────────────────────────

declare -A NES_TITLES=(
    # Canonical source: No-Intro Nintendo – Nintendo Entertainment System
    ["Contra (USA)"]="Contra|2"
    ["Super Mario Bros. (USA, Europe)"]="Super Mario Bros.|2"
    ["Super Mario Bros. 2 (USA)"]="Super Mario Bros. 2|2"
    ["Super Mario Bros. 3 (USA)"]="Super Mario Bros. 3|2"
    ["Teenage Mutant Ninja Turtles (USA)"]="TMNT|2"
    ["Teenage Mutant Ninja Turtles II - The Arcade Game (USA)"]="TMNT II: The Arcade Game|2"
    ["Teenage Mutant Ninja Turtles III - The Manhattan Project (USA)"]="TMNT III: Manhattan Project|2"
    ["Double Dragon (USA)"]="Double Dragon|2"
    ["Double Dragon II - The Revenge (USA)"]="Double Dragon II|2"
    ["Double Dragon III - The Sacred Stones (USA)"]="Double Dragon III|2"
    ["Battletoads (USA)"]="Battletoads|2"
    ["River City Ransom (USA)"]="River City Ransom|2"
    ["Bubble Bobble (USA)"]="Bubble Bobble|2"
    ["Gauntlet II (USA)"]="Gauntlet II|4"
    ["Life Force (USA)"]="Life Force|2"
    ["Rampage (USA)"]="Rampage|3"
    ["Jackal (USA)"]="Jackal|2"
    ["Blades of Steel (USA)"]="Blades of Steel|2"
    ["Mighty Final Fight (USA)"]="Mighty Final Fight|2"
    ["P.O.W. - Prisoners of War (USA)"]="P.O.W.|2"
    ["WWF WrestleMania (USA)"]="WWF WrestleMania|2"
    ["The Legend of Zelda (USA)"]="The Legend of Zelda|2"
    ["Metroid (USA)"]="Metroid|2"
    ["Ninja Gaiden (USA)"]="Ninja Gaiden|2"
    ["Kung Fu (USA)"]="Kung Fu|2"
)

declare -A SNES_TITLES=(
    # Canonical source: No-Intro Nintendo – Super Nintendo Entertainment System
    ["Super Mario Kart (USA)"]="Super Mario Kart|4"
    ["Street Fighter II Turbo - Hyper Fighting (USA)"]="SF II Turbo|2"
    ["Mortal Kombat II (USA)"]="Mortal Kombat II|2"
    ["Teenage Mutant Ninja Turtles IV - Turtles in Time (USA)"]="TMNT IV: Turtles in Time|2"
    ["NBA Jam Tournament Edition (USA)"]="NBA Jam TE|4"
    ["Super Bomberman (USA)"]="Super Bomberman|4"
    ["Zombies Ate My Neighbors (USA)"]="Zombies Ate My Neighbors|2"
    ["Goof Troop (USA)"]="Goof Troop|2"
    ["The Legend of the Mystical Ninja (USA)"]="Legend of the Mystical Ninja|2"
    ["Pocky & Rocky (USA)"]="Pocky & Rocky|2"
    ["Contra III - The Alien Wars (USA)"]="Contra III|2"
    ["Sunset Riders (USA)"]="Sunset Riders|2"
    ["Secret of Mana (USA)"]="Secret of Mana|3"
    ["Kirby Super Star (USA)"]="Kirby Super Star|2"
    ["Super Smash TV (USA)"]="Super Smash TV|2"
    ["The King of Dragons (USA)"]="The King of Dragons|2"
    ["Knights of the Round (USA)"]="Knights of the Round|3"
    ["Captain Commando (USA)"]="Captain Commando|4"
    ["Alien vs. Predator (USA)"]="Alien vs. Predator|3"
    ["Super Mario World (USA)"]="Super Mario World|2"
    ["Donkey Kong Country (USA)"]="Donkey Kong Country|2"
    ["Donkey Kong Country 2 - Diddy's Kong Quest (USA)"]="Donkey Kong Country 2|2"
    ["Donkey Kong Country 3 - Dixie Kong's Double Trouble! (USA)"]="Donkey Kong Country 3|2"
    ["International Superstar Soccer (USA)"]="International Superstar Soccer|2"
    ["NHL '94 (USA)"]="NHL '94|2"
    ["Super Double Dragon (USA)"]="Super Double Dragon|2"
    ["Battletoads in Battlemaniacs (USA)"]="Battletoads in Battlemaniacs|2"
)

declare -A GENESIS_TITLES=(
    # Canonical source: No-Intro Sega – Mega Drive – Genesis
    ["Streets of Rage (USA)"]="Streets of Rage|2"
    ["Streets of Rage 2 (USA)"]="Streets of Rage 2|2"
    ["Streets of Rage 3 (USA)"]="Streets of Rage 3|3"
    ["Sonic the Hedgehog 2 (USA)"]="Sonic the Hedgehog 2|2"
    ["Sonic the Hedgehog 3 (USA)"]="Sonic the Hedgehog 3|2"
    ["Gunstar Heroes (USA)"]="Gunstar Heroes|2"
    ["Contra - Hard Corps (USA)"]="Contra: Hard Corps|2"
    ["Golden Axe (USA, Europe)"]="Golden Axe|2"
    ["Golden Axe II (USA, Europe)"]="Golden Axe II|2"
    ["NBA Jam (USA)"]="NBA Jam|2"
    ["NBA Jam Tournament Edition (USA)"]="NBA Jam TE|2"
    ["NHL '94 (USA)"]="NHL '94|2"
    ["Mortal Kombat (USA)"]="Mortal Kombat|2"
    ["Mortal Kombat II (USA)"]="Mortal Kombat II|2"
    ["Mortal Kombat 3 (USA)"]="Mortal Kombat 3|2"
    ["ToeJam & Earl (USA)"]="ToeJam & Earl|2"
    ["ToeJam & Earl in Panic on Funkotron (USA)"]="ToeJam & Earl in Panic on Funkotron|2"
    ["Mega Bomberman (USA)"]="Mega Bomberman|4"
    ["The Punisher (USA, Europe)"]="The Punisher|2"
    ["Alien Storm (USA, Europe)"]="Alien Storm|3"
    ["Battletoads & Double Dragon - The Ultimate Team (USA)"]="Battletoads & Double Dragon|2"
    ["Earthworm Jim 2 (USA)"]="Earthworm Jim 2|2"
    ["X-Men 2 - Clone Wars (USA)"]="X-Men 2: Clone Wars|2"
    ["X-Men (USA)"]="X-Men|6"
    ["Sunset Riders (USA)"]="Sunset Riders|4"
    ["Comix Zone (USA)"]="Comix Zone|2"
    ["The Adventures of Batman & Robin (USA)"]="Adventures of Batman & Robin|2"
    ["Teenage Mutant Ninja Turtles - The Hyperstone Heist (USA)"]="TMNT: Hyperstone Heist|2"
    ["Spider-Man and Venom - Maximum Carnage (USA)"]="Spider-Man: Maximum Carnage|2"
    ["World of Illusion Starring Mickey Mouse and Donald Duck (USA)"]="World of Illusion|2"
    ["Aladdin (USA)"]="Aladdin|2"
    ["The Lion King (USA)"]="The Lion King|2"
    ["Altered Beast (USA)"]="Altered Beast|2"
    ["Shadow Dancer - The Secret of Shinobi (USA)"]="Shadow Dancer|2"
    ["Road Rash (USA)"]="Road Rash|2"
    ["Road Rash II (USA)"]="Road Rash II|2"
    ["Road Rash 3 (USA)"]="Road Rash 3|2"
    ["Zombies Ate My Neighbors (USA)"]="Zombies Ate My Neighbors|2"
    ["General Chaos (USA)"]="General Chaos|2"
    ["NHL Hockey (USA)"]="NHL Hockey|2"
    ["Madden NFL '94 (USA)"]="Madden NFL '94|2"
    ["FIFA Soccer 95 (USA)"]="FIFA Soccer 95|2"
    ["Tecmo Super Bowl (USA)"]="Tecmo Super Bowl|2"
    ["Kolibri (USA)"]="Kolibri|2"
    ["Micro Machines 2 - Turbo Tournament (Europe)"]="Micro Machines 2|2"
)

declare -A GB_TITLES=(
    # Canonical source: No-Intro Nintendo – Game Boy (+ Game Boy Color)
    ["Tetris (World) (Rev 1)"]="Tetris|2"
    ["Dr. Mario (USA, Europe)"]="Dr. Mario|2"
    ["Kirby's Dream Land 2 (USA, Europe)"]="Kirby's Dream Land 2|2"
    ["Double Dragon (USA, Europe)"]="Double Dragon|2"
    ["Teenage Mutant Ninja Turtles - Fall of the Foot Clan (USA)"]="TMNT: Fall of the Foot Clan|2"
    ["Pokemon - Red Version (USA, Europe)"]="Pokémon Red|2"
    ["Pokemon - Blue Version (USA, Europe)"]="Pokémon Blue|2"
    ["Pokemon - Gold Version (USA, Australia)"]="Pokémon Gold|2"
    ["Pokemon - Silver Version (USA, Australia)"]="Pokémon Silver|2"
    ["The Legend of Zelda - Oracle of Ages (USA)"]="Zelda: Oracle of Ages|2"
    ["The Legend of Zelda - Oracle of Seasons (USA)"]="Zelda: Oracle of Seasons|2"
    ["Super Mario Bros. Deluxe (USA, Europe)"]="Super Mario Bros. Deluxe|2"
    ["Wario Land II (USA)"]="Wario Land II|2"
)

declare -A GBA_TITLES=(
    # Canonical source: No-Intro Nintendo – Game Boy Advance
    ["Mario Kart - Super Circuit (USA)"]="Mario Kart: Super Circuit|4"
    ["Advance Wars (USA)"]="Advance Wars|2"
    ["Kirby & The Amazing Mirror (USA)"]="Kirby & The Amazing Mirror|4"
    ["The Legend of Zelda - A Link to the Past & Four Swords (USA)"]="Zelda: A Link to the Past & Four Swords|4"
    ["Mario Tennis - Power Tour (USA)"]="Mario Tennis: Power Tour|2"
    ["Mario Golf - Advance Tour (USA)"]="Mario Golf: Advance Tour|2"
    ["Final Fight One (USA)"]="Final Fight One|2"
    ["Double Dragon Advance (USA)"]="Double Dragon Advance|2"
    ["Super Mario Advance 4 - Super Mario Bros. 3 (USA)"]="SMA4: Super Mario Bros. 3|2"
    ["Metroid Fusion (USA)"]="Metroid Fusion|2"
    ["Golden Sun (USA)"]="Golden Sun|2"
    ["Castlevania - Aria of Sorrow (USA)"]="Castlevania: Aria of Sorrow|2"
)

declare -A MASTERSYSTEM_TITLES=(
    # Canonical source: No-Intro Sega – Master System – Mark III (ni-romsets)
    ["Double Dragon (USA, Europe)"]="Double Dragon|2"
    ["Rampage (USA, Europe)"]="Rampage|3"
    ["Bubble Bobble (USA, Europe)"]="Bubble Bobble|2"
    ["Gauntlet (USA, Europe)"]="Gauntlet|4"
    ["Shinobi (USA, Europe)"]="Shinobi|2"
    ["Sonic the Hedgehog (USA, Europe)"]="Sonic the Hedgehog|2"
    ["Wonder Boy III - The Dragon's Trap (USA, Europe)"]="Wonder Boy III|2"
    ["Golden Axe Warrior (USA, Europe)"]="Golden Axe Warrior|2"
    ["Alex Kidd in Miracle World (USA, Europe)"]="Alex Kidd in Miracle World|2"
    ["OutRun (USA, Europe)"]="Out Run|2"
)

declare -A GAMEGEAR_TITLES=(
    # Canonical source: No-Intro Sega – Game Gear (ni-romsets)
    ["Sonic the Hedgehog (USA, Europe)"]="Sonic the Hedgehog|2"
    ["Sonic the Hedgehog 2 (USA, Europe)"]="Sonic the Hedgehog 2|2"
    ["Columns (USA, Europe)"]="Columns|2"
    ["Mortal Kombat (USA)"]="Mortal Kombat|2"
    ["NBA Jam (USA)"]="NBA Jam|2"
    ["Streets of Rage 2 (USA, Europe)"]="Streets of Rage 2|2"
    ["FIFA International Soccer (USA, Europe)"]="FIFA International Soccer|2"
)

declare -A NDS_TITLES=(
    # Canonical source: No-Intro Nintendo – Nintendo DS (ni-romsets)
    ["Mario Kart DS (USA)"]="Mario Kart DS|4"
    ["New Super Mario Bros. (USA)"]="New Super Mario Bros.|4"
    ["Metroid Prime Hunters (USA)"]="Metroid Prime Hunters|4"
    ["Tetris DS (USA)"]="Tetris DS|4"
    ["Mario Party DS (USA)"]="Mario Party DS|4"
    ["Animal Crossing - Wild World (USA)"]="Animal Crossing: Wild World|4"
    ["Clubhouse Games (USA)"]="Clubhouse Games|4"
    ["Mario & Luigi - Partners in Time (USA)"]="Mario & Luigi: Partners in Time|2"
    ["Bomberman Land Touch! (USA)"]="Bomberman Land Touch!|4"
)

declare -A SEGA32X_TITLES=(
    # Canonical source: No-Intro Sega – 32X (ni-romsets)
    ["Virtua Racing Deluxe (USA)"]="Virtua Racing Deluxe|2"
    ["Knuckles' Chaotix (USA)"]="Knuckles' Chaotix|2"
    ["Doom (USA)"]="Doom|2"
    ["Star Wars Arcade (USA)"]="Star Wars Arcade|2"
    ["Pitfall - The Mayan Adventure (USA)"]="Pitfall: The Mayan Adventure|2"
    ["Spider-Man - Web of Fire (USA)"]="Spider-Man: Web of Fire|2"
    ["Blackthorne (USA)"]="Blackthorne|2"
)

declare -A ATARI2600_TITLES=(
    # Canonical source: No-Intro Atari – 2600 (ni-romsets)
    ["Combat (USA)"]="Combat|2"
    ["Boxing (USA)"]="Boxing|2"
    ["Warlords (USA)"]="Warlords|4"
    ["Space Invaders (USA)"]="Space Invaders|2"
    ["Video Olympics (USA)"]="Video Olympics|2"
    ["Pitfall! - Pitfall Harry's Jungle Adventure (USA)"]="Pitfall!|2"
    ["River Raid (USA)"]="River Raid|2"
    ["Asteroids (USA)"]="Asteroids|2"
    ["Missile Command (USA)"]="Missile Command|2"
    ["Centipede (USA)"]="Centipede|2"
    ["Defender (USA)"]="Defender|2"
    ["Joust (USA)"]="Joust|2"
    ["Frogger (USA)"]="Frogger|2"
    ["Kaboom! (USA)"]="Kaboom!|2"
    ["Ice Hockey (USA)"]="Ice Hockey|2"
    ["Surround (USA)"]="Surround|2"
    ["Outlaw (USA)"]="Outlaw|2"
    ["Freeway (USA)"]="Freeway|2"
)

declare -A TURBOGRAFX16_TITLES=(
    # Canonical source: No-Intro NEC – PC Engine – TurboGrafx-16
    ["Bomberman '93 (USA)"]="Bomberman '93|5"
    ["Bonk's Adventure (USA)"]="Bonk's Adventure|2"
    ["Blazing Lazers (USA)"]="Blazing Lazers|2"
    ["Military Madness (USA)"]="Military Madness|2"
    ["Alien Crush (USA)"]="Alien Crush|2"
    ["Dungeon Explorer (USA)"]="Dungeon Explorer|5"
    ["Air Zonk (USA)"]="Air Zonk|2"
    ["New Adventure Island (USA)"]="New Adventure Island|2"
    ["Soldier Blade (USA)"]="Soldier Blade|2"
    ["R-Type (USA)"]="R-Type|2"
    ["Neutopia (USA)"]="Neutopia|2"
    ["Keith Courage in Alpha Zones (USA)"]="Keith Courage|2"
)

# ─── NETWORK CHECK ───────────────────────────────────────────────────────────
has_network() {
    ping -c 1 -W 3 8.8.8.8 &>/dev/null || ping -c 1 -W 3 1.1.1.1 &>/dev/null
}

# ─── SYSTEM ALIAS NORMALISATION ──────────────────────────────────────────────
system_from_dir() {
    case "$1" in
        genesis) echo "megadrive" ;;
        fbneo)   echo "arcade" ;;
        *)       echo "$1" ;;
    esac
}

# ─── PRIORITY CONSOLE TITLES ─────────────────────────────────────────────────
# Canonical multiplayer titles checked at boot. Missing ones are queued for
# download before mismatch repairs, so popular games arrive first.
# Format: "system|Full Title (Region)"
CONSOLE_PRIORITY=(
    "snes|Street Fighter II Turbo - Hyper Fighting (USA)"
    "snes|Super Bomberman (USA)"
    "snes|Mortal Kombat (USA)"
    "snes|NBA Jam (USA)"
    "snes|Super Mario Kart (USA)"
    "nes|Contra (USA)"
    "nes|Double Dragon (USA)"
    "nes|Tecmo Super Bowl (USA)"
    "nes|Battletoads (USA)"
    "megadrive|Streets of Rage 2 (USA)"
    "megadrive|Streets of Rage (USA)"
    "megadrive|Streets of Rage 3 (USA)"
    "megadrive|Sonic the Hedgehog 2 (USA)"
    "megadrive|Gunstar Heroes (USA)"
    "megadrive|Contra - Hard Corps (USA)"
    "megadrive|Golden Axe (USA, Europe)"
    "megadrive|Mortal Kombat II (USA)"
    "megadrive|NBA Jam Tournament Edition (USA)"
    "megadrive|ToeJam & Earl (USA)"
    "megadrive|Mega Bomberman (USA)"
    "megadrive|Teenage Mutant Ninja Turtles - The Hyperstone Heist (USA)"
    "megadrive|Spider-Man and Venom - Maximum Carnage (USA)"
    "megadrive|Zombies Ate My Neighbors (USA)"
    "megadrive|X-Men 2 - Clone Wars (USA)"
    "gba|Mario Kart - Super Circuit (USA)"
    "gba|Mortal Kombat - Deadly Alliance (USA)"
)
# Auto-populate from ALL canonical title arrays so every curated game
# eventually gets downloaded. The static entries above set priority order;
# these appended entries fill in the rest.
for _key in "${!NES_TITLES[@]}";          do CONSOLE_PRIORITY+=("nes|$_key"); done
for _key in "${!SNES_TITLES[@]}";         do CONSOLE_PRIORITY+=("snes|$_key"); done
for _key in "${!GENESIS_TITLES[@]}";      do CONSOLE_PRIORITY+=("megadrive|$_key"); done
for _key in "${!GB_TITLES[@]}";           do CONSOLE_PRIORITY+=("gb|$_key"); done
for _key in "${!GBA_TITLES[@]}";          do CONSOLE_PRIORITY+=("gba|$_key"); done
for _key in "${!MASTERSYSTEM_TITLES[@]}"; do CONSOLE_PRIORITY+=("mastersystem|$_key"); done
for _key in "${!GAMEGEAR_TITLES[@]}";     do CONSOLE_PRIORITY+=("gamegear|$_key"); done
for _key in "${!NDS_TITLES[@]}";          do CONSOLE_PRIORITY+=("nds|$_key"); done
for _key in "${!SEGA32X_TITLES[@]}";      do CONSOLE_PRIORITY+=("sega32x|$_key"); done
for _key in "${!ATARI2600_TITLES[@]}";    do CONSOLE_PRIORITY+=("atari2600|$_key"); done
for _key in "${!TURBOGRAFX16_TITLES[@]}"; do CONSOLE_PRIORITY+=("pcengine|$_key"); done

# ─── INTERNET ARCHIVE COLLECTION FOR SYSTEM ──────────────────────────────────
# ── IA source identifiers ─────────────────────────────────────────────────────
# FBNeo 1.0.0.03 Best Set: 585 hand-curated non-merged ROMs with BIOS included
# Matches our pinned FBNeo v1.0.0.03 core exactly — no parent/BIOS dependencies
IA_FBNEO_PACK="fbneo_1003_bestset"
IA_FBNEO_ZIP="fbneo_1_0_0_3_best.zip"
# Cylum's FBNeo: unrestricted individual zips (fallback for titles not in pack)
IA_CYLUM_ITEM="cylums-final-burn-neo-rom-collection"
IA_CYLUM_SUBDIR="Cylum%27s%20FinalBurn%20Neo%20ROM%20Collection%20%2802-18-21%29"
# MAME 2003-Plus: login-restricted (not usable for automated downloads)
IA_MAME_ITEM="MAME_2003-Plus_Reference_Set_2018"
# MAME samples: freely downloadable RAR pack (~24 MB, contains all sample .zips)
IA_MAME_SAMPLES_ITEM="mamesamples"
IA_MAME_SAMPLES_FILE="mamesamples.rar"

# ── AUDIO SAMPLES ─────────────────────────────────────────────────────────────
# Games that require audio sample .zip files for proper sound.
# Format: SAMPLE_MAP[game_id]="sample_filename.zip"
# Most match the game_id; a few have different sample names (parent driver).
# Source: mamesamples archive on IA (compatible with MAME 2003-Plus core).
declare -A SAMPLE_MAP=(
    ["dkong"]="dkong.zip"
    ["dkongjr"]="dkongjr.zip"
    ["mario"]="mario.zip"
    ["galaga"]="galaga.zip"
    ["polepos"]="polepos.zip"
    ["berzerk"]="berzerk.zip"
    ["zaxxon"]="zaxxon.zip"
    ["spaceinv"]="invaders.zip"
)
IA_MAME_SUBDIR="roms"

# ── Console No-Intro romsets on IA ─────────────────────────────────────────────
# Two tiers:
#   1. Per-ROM items: individual .7z files per game → direct download by filename
#   2. Bulk items: one .7z per system → download once, extract missing, delete
#
# Per-ROM items (fast: download only what's needed, ~100KB–8MB per ROM)
declare -A IA_CONSOLE_PER_ROM=(
    ["megadrive"]="nointro.md"
    ["gamegear"]="nointro.gg"
    ["pcengine"]="nointro.tg-16"
    ["atari2600"]="nointro.atari-2600"
    ["sega32x"]="nointro.32x"
    ["mastersystem"]="nointro.ms-mkiii"
    ["gba"]="ef_gba_no-intro_2024-02-21"
)
# File extension in per-ROM items (.7z for nointro.*, .zip for ef_gba)
declare -A IA_CONSOLE_PER_ROM_EXT=(
    ["megadrive"]=".7z"
    ["gamegear"]=".7z"
    ["pcengine"]=".7z"
    ["atari2600"]=".7z"
    ["sega32x"]=".7z"
    ["mastersystem"]=".7z"
    ["gba"]=".zip"
)
# Bulk items (slower: download full system archive, extract, delete)
# Item: no-intro_romset_collection (freely accessible, .7z per system)
IA_CONSOLE_BULK_ITEM="no-intro_romset_collection"
declare -A IA_CONSOLE_BULK=(
    ["nes"]="Nintendo - Nintendo Entertainment System.7z"
    ["snes"]="Nintendo - Super Nintendo Entertainment System.7z"
    ["gb"]="Nintendo - Game Boy.7z"
    ["gbc"]="Nintendo - Game Boy Color.7z"
)

# For arcade ROMs, game_id (zip name without extension) determines which
# canonical set to use: FBNeo non-merged set or MAME 2003-Plus reference set.
ia_collection_for() {
    local system="$1"
    local game_id="${2:-}"
    case "$system" in
        fbneo|arcade|mame|neogeo)
            echo "$IA_CYLUM_ITEM" ;;
        *)
            # Console: per-ROM item, or bulk item, or empty (unsupported)
            if [ -n "${IA_CONSOLE_PER_ROM[$system]:-}" ]; then
                echo "${IA_CONSOLE_PER_ROM[$system]}"
            elif [ -n "${IA_CONSOLE_BULK[$system]:-}" ]; then
                echo "$IA_CONSOLE_BULK_ITEM"
            else
                echo ""
            fi
            ;;
    esac
}

# ── SYNC ARCADE ROMSET ──────────────────────────────────────────────────────
# Downloads ALL missing canonical arcade ROMs, then consolidates to one
# canonical location per game (FBNeo titles → fbneo/, MAME-only → mame/).
#
# Strategy:
#   1. Download the FBNeo 1.0.0.03 Best Set (4.7 GB zip, 585 non-merged ROMs)
#      Each ROM is self-contained with BIOS included — no parent/BIOS deps
#   2. Extract all ROMs to fbneo/
#   3. Delete the archive to reclaim space
#   4. MAME-only titles: try Cylum's collection (MAME 2003-Plus is login-restricted)
#   5. Clean up duplicate ROMs in mame/arcade/neogeo dirs
sync_arcade_romset() {
    local dest_dir="$ROMS_BASE/fbneo"
    local mame_dirs=("$ROMS_BASE/mame" "$ROMS_BASE/mame/roms" "$ROMS_BASE/arcade" "$ROMS_BASE/neogeo")
    local cylum_base="https://archive.org/download/$IA_CYLUM_ITEM/$IA_CYLUM_SUBDIR"
    mkdir -p "$dest_dir"

    # ── Lockfile: prevent concurrent syncs (atomic flock) ────────────────
    local SYNC_LOCK="/tmp/outbreak-arcade-sync.lock"
    exec 7>"$SYNC_LOCK"
    if ! flock -n 7; then
        log "Arcade sync already running — skipping"
        exec 7>&-
        return 0
    fi
    trap 'exec 7>&-' EXIT

    # ── Phase 1: check if pack is already extracted ────────────────────
    # The 1.0.0.03 Best Set contains ~585 non-merged FBNeo ROMs (BIOS included).
    local pack_marker="$dest_dir/.fbneo_pack_extracted"
    local rom_count
    rom_count=$(find "$dest_dir" -maxdepth 1 -name '*.zip' 2>/dev/null | wc -l)
    log "FBNeo: $rom_count ROMs in $dest_dir"

    if [ -f "$pack_marker" ] && [ "$rom_count" -gt 500 ]; then
        log "FBNeo 1.0.0.03 Best Set already extracted ($rom_count ROMs) — skipping download"
    else
        # ── Phase 2: download and extract the FBNeo 1.0.0.03 Best Set ───
        local pack_url="https://archive.org/download/$IA_FBNEO_PACK/$IA_FBNEO_ZIP"
        local pack_path="/userdata/fbneo_pack.zip"

        log "Downloading FBNeo 1.0.0.03 Best Set (~4.7 GB, 585 non-merged ROMs)..."

        wget -q --timeout=900 --tries=2 -O "$pack_path" "$pack_url" 2>/dev/null
        if [ $? -eq 0 ] && [ -f "$pack_path" ] && [ "$(stat -c%s "$pack_path" 2>/dev/null)" -gt 1000000000 ]; then
            log "Pack downloaded — extracting all ROMs to fbneo/..."

            # Extract all .zip files from the pack into dest_dir
            # Non-merged set: each ROM is self-contained (BIOS included)
            unzip -o -j "$pack_path" '*.zip' -d "$dest_dir" 2>/dev/null
            local new_count
            new_count=$(find "$dest_dir" -maxdepth 1 -name '*.zip' 2>/dev/null | wc -l)
            log "Extracted: $new_count ROMs now in fbneo/ (was $rom_count)"

            rm -f "$pack_path"
            log "Cleaned up pack archive"

            # Mark as extracted so we don't re-download
            date +%s > "$pack_marker"
        else
            rm -f "$pack_path"
            log "WARN: FBNeo pack download failed or incomplete"
        fi
    fi

    # ── Phase 2a: canonical ROM enforcement ──────────────────────────────
    # Quarantine regional duplicates only: if a base game exists (e.g. avsp)
    # AND a regional variant exists (e.g. avspu), quarantine the variant.
    # Never quarantine a game that's in FBNEO_TITLES.
    local quarantine_dir="/userdata/roms/quarantine/fbneo"
    local cylum_base="https://archive.org/download/$IA_CYLUM_ITEM/$IA_CYLUM_SUBDIR"
    local canonical_missing=0
    local canonical_fetched=0
    local variants_quarantined=0

    # Known FBNeo region suffixes (single and double char)
    local region_suffixes="u j a b d e h k r ud ur ub"

    # Build a set of all ROM names for O(1) lookup
    declare -A rom_set
    for rom in "$dest_dir"/*.zip; do
        [ -f "$rom" ] || continue
        rom_set[$(basename "$rom" .zip)]=1
    done

    # Find and quarantine regional duplicates
    local name base suffix
    for name in "${!rom_set[@]}"; do
        # Never quarantine a game that's in our curated titles list
        [ -n "${FBNEO_TITLES[$name]+x}" ] && continue
        for suffix in $region_suffixes; do
            base="${name%$suffix}"
            [ "$base" = "$name" ] && continue  # suffix didn't match
            [ -z "$base" ] && continue
            [ -n "${rom_set[$base]+x}" ] || continue
            # This ROM is a regional variant of an existing base game — delete it
            rm -f "$dest_dir/$name.zip"
            for mext in thumb image; do
                rm -f "$dest_dir/images/${name}-${mext}.png" 2>/dev/null
            done
            ((variants_quarantined++))
            log "Canonical: removed duplicate $name.zip (canonical: $base.zip)"
            break  # only need one suffix match
        done
    done

    # Restore any wrongly quarantined canonical ROMs (from previous versions)
    local restored=0
    if [ -d "$quarantine_dir" ]; then
        for game_id in "${!FBNEO_TITLES[@]}"; do
            if [ ! -f "$dest_dir/$game_id.zip" ] && [ -f "$quarantine_dir/$game_id.zip" ]; then
                mv "$quarantine_dir/$game_id.zip" "$dest_dir/$game_id.zip"
                for mext in thumb image; do
                    [ -f "$quarantine_dir/${game_id}-${mext}.png" ] && \
                        mkdir -p "$dest_dir/images" && \
                        mv "$quarantine_dir/${game_id}-${mext}.png" "$dest_dir/images/${game_id}-${mext}.png"
                done
                ((restored++))
                log "Canonical: restored $game_id.zip from quarantine"
            fi
        done
        [ "$restored" -gt 0 ] && log "Canonical FBNeo: restored $restored ROM(s) from quarantine"
        # Clean up legacy quarantine — duplicates are now deleted, not quarantined
        rm -rf "$quarantine_dir"
    fi

    # Download any missing canonical ROMs — Best Set zip-serve first, Cylum fallback
    # Early-exit after 3 consecutive failures (both sources down → let self-healing handle it)
    local pack_base="https://archive.org/download/$IA_FBNEO_PACK/$IA_FBNEO_ZIP"
    local _consec_fail=0
    for game_id in "${!FBNEO_TITLES[@]}"; do
        [ -f "$dest_dir/$game_id.zip" ] && continue
        ((canonical_missing++))
        if [ "$_consec_fail" -ge 3 ]; then
            continue  # skip remaining — sources are down, count missing for self-healing
        fi
        local tmp_path="$dest_dir/$game_id.zip.dl_tmp"
        local _got=false
        # Primary: Best Set zip-serve (most complete source)
        wget -q --timeout=60 -O "$tmp_path" "$pack_base/$game_id.zip" 2>/dev/null
        if [ $? -eq 0 ] && [ -f "$tmp_path" ] && [ "$(stat -c%s "$tmp_path" 2>/dev/null)" -gt 1000 ]; then
            mv "$tmp_path" "$dest_dir/$game_id.zip"
            ((canonical_fetched++)); _consec_fail=0; _got=true
            log "Canonical: downloaded fbneo/$game_id.zip (Best Set)"
        else
            rm -f "$tmp_path"
            # Fallback: Cylum's individual collection
            wget -q --timeout=30 -O "$tmp_path" "$cylum_base/$game_id.zip" 2>/dev/null
            if [ $? -eq 0 ] && [ -f "$tmp_path" ] && [ "$(stat -c%s "$tmp_path" 2>/dev/null)" -gt 1000 ]; then
                mv "$tmp_path" "$dest_dir/$game_id.zip"
                ((canonical_fetched++)); _consec_fail=0; _got=true
                log "Canonical: downloaded fbneo/$game_id.zip (Cylum)"
            else
                rm -f "$tmp_path"
            fi
        fi
        if ! $_got; then
            ((_consec_fail++))
            if [ "$_consec_fail" -ge 3 ]; then
                log "Canonical: 3 consecutive download failures — skipping individual downloads"
            fi
        fi
        _wait_if_busy; sleep 1
    done
    [ "$canonical_missing" -gt 0 ] && log "Canonical FBNeo: $canonical_missing missing, $canonical_fetched downloaded"
    [ "$variants_quarantined" -gt 0 ] && log "Canonical FBNeo: removed $variants_quarantined non-canonical duplicate ROMs"

    # ── Self-healing: bulk re-download if individual downloads couldn't fill gaps ──
    # Only triggers as last resort when zip-serve AND Cylum both failed for >5 ROMs.
    # The bulk download uses a different (often healthier) IA server than zip-serve.
    local _still_missing=0
    for game_id in "${!FBNEO_TITLES[@]}"; do
        [ -f "$dest_dir/$game_id.zip" ] || ((_still_missing++))
    done
    local _prev_canon=0
    [ -f "$pack_marker" ] && _prev_canon=$(sed -n '2p' "$pack_marker" 2>/dev/null)
    _prev_canon=${_prev_canon:-0}
    # Cap baseline at current list size (list may have shrunk between versions)
    [ "$_prev_canon" -gt "${#FBNEO_TITLES[@]}" ] && _prev_canon=${#FBNEO_TITLES[@]}
    local _still_present=$(( ${#FBNEO_TITLES[@]} - _still_missing ))

    local _need_redownload=false
    if [ "$_prev_canon" -gt 0 ] && [ $((_prev_canon - _still_present)) -gt 5 ]; then
        log "Self-healing: canonical count dropped from $_prev_canon → $_still_present after individual downloads — re-downloading Best Set..."
        _need_redownload=true
    elif [ "$_prev_canon" -eq 0 ] && [ "$_still_missing" -gt 5 ] && [ "$canonical_fetched" -lt "$canonical_missing" ]; then
        log "Self-healing: $_still_missing canonical ROMs still missing after individual downloads — re-downloading Best Set..."
        _need_redownload=true
    fi
    if $_need_redownload; then
        rm -f "$pack_marker"
        local pack_url="https://archive.org/download/$IA_FBNEO_PACK/$IA_FBNEO_ZIP"
        local pack_path="/userdata/fbneo_pack.zip"
        wget -q --timeout=900 --tries=2 -O "$pack_path" "$pack_url" 2>/dev/null
        if [ $? -eq 0 ] && [ -f "$pack_path" ] && [ "$(stat -c%s "$pack_path" 2>/dev/null)" -gt 1000000000 ]; then
            log "Pack downloaded — re-extracting to fbneo/..."
            unzip -o -j "$pack_path" '*.zip' -d "$dest_dir" 2>/dev/null
            local new_count
            new_count=$(find "$dest_dir" -maxdepth 1 -name '*.zip' 2>/dev/null | wc -l)
            log "Re-extracted: $new_count ROMs now in fbneo/"
            rm -f "$pack_path"
            date +%s > "$pack_marker"
        else
            rm -f "$pack_path"
            log "WARN: Best Set re-download failed"
        fi
    fi

    # Update baseline canonical count for self-healing on future runs
    local _final_canon=0
    for game_id in "${!FBNEO_TITLES[@]}"; do
        [ -f "$dest_dir/$game_id.zip" ] && ((_final_canon++))
    done
    if [ -f "$pack_marker" ]; then
        local _ts; _ts=$(head -1 "$pack_marker")
        printf '%s\n%s\n' "$_ts" "$_final_canon" > "$pack_marker"
    fi
    log "Canonical FBNeo: $_final_canon / ${#FBNEO_TITLES[@]} titles present"

    # ── Phase 2b: ensure required BIOS/parent files are present ────────────
    # The Best Set ships neogeo.zip inside the pack, but other BIOS files
    # (pgm.zip, skns.zip, etc.) may be missing. Copy from /userdata/bios/
    # if available there, otherwise try Cylum's collection.
    local FBNEO_BIOS_FILES="neogeo.zip pgm.zip skns.zip decocass.zip nmk004.zip cchip.zip ym2608.zip isgsm.zip"
    local cylum_bios_base="https://archive.org/download/$IA_CYLUM_ITEM/$IA_CYLUM_SUBDIR/BIOS%20Files"
    local bios_fetched=0
    for bios in $FBNEO_BIOS_FILES; do
        [ -f "$dest_dir/$bios" ] && continue
        # Try copying from Batocera's system bios directory first
        if [ -f "/userdata/bios/$bios" ]; then
            cp "/userdata/bios/$bios" "$dest_dir/$bios"
            ((bios_fetched++))
            log "BIOS: copied $bios from /userdata/bios/"
            continue
        fi
        # Try downloading from Cylum's BIOS Files subfolder
        local bios_tmp="$dest_dir/$bios.dl_tmp"
        wget -q --timeout=30 -O "$bios_tmp" "$cylum_bios_base/$bios" 2>/dev/null
        if [ $? -eq 0 ] && [ -f "$bios_tmp" ] && [ "$(stat -c%s "$bios_tmp" 2>/dev/null)" -gt 1000 ]; then
            mv "$bios_tmp" "$dest_dir/$bios"
            ((bios_fetched++))
            log "BIOS: downloaded $bios from Cylum's"
        else
            rm -f "$bios_tmp"
            log "BIOS: $bios not available (games needing it may fail)"
        fi
    done
    [ "$bios_fetched" -gt 0 ] && log "BIOS: $bios_fetched file(s) added to fbneo/"

    # ── Phase 2c: patch pgm.zip with extra BIOS files if needed ──────────
    # Cylum's pgm.zip has 4 standard files but FBNeo v1.0.0.03 also needs
    # ddp3_bios.u37 and bios.u42 for PGM2/IGS hardware games.
    # Extract these from ddp3.zip and dmnfrnt.zip if present.
    if [ -f "$dest_dir/pgm.zip" ]; then
        python3 -c "
import zipfile, os, sys
pgm = '$dest_dir/pgm.zip'
extras = {'ddp3_bios.u37': '$dest_dir/ddp3.zip', 'bios.u42': '$dest_dir/dmnfrnt.zip'}
z = zipfile.ZipFile(pgm, 'r')
existing = set(z.namelist())
to_add = {}
for fname, src in extras.items():
    if fname not in existing and os.path.isfile(src):
        sz = zipfile.ZipFile(src, 'r')
        if fname in sz.namelist():
            to_add[fname] = sz.read(fname)
        sz.close()
if not to_add:
    z.close()
    sys.exit(0)
tmp = pgm + '.tmp'
with zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED) as nz:
    for item in z.infolist():
        nz.writestr(item, z.read(item.filename))
    for fname, data in to_add.items():
        nz.writestr(fname, data)
z.close()
os.replace(tmp, pgm)
print(f'Patched pgm.zip: added {list(to_add.keys())}')
" 2>>"$LOG_FILE" && log "BIOS: pgm.zip patched with extra PGM BIOS files" || true
    fi

    # ── Phase 3: clean up MAME duplicates ─────────────────────────────────
    # Scan all FBNeo .zips (not just curated list) to catch the full pack
    local cleaned=0
    for rom_file in "$dest_dir"/*.zip; do
        [ -f "$rom_file" ] || continue
        local game_id
        game_id=$(basename "$rom_file" .zip)
        for mdir in "${mame_dirs[@]}"; do
            if [ -f "$mdir/$game_id.zip" ]; then
                rm -f "$mdir/$game_id.zip"
                ((cleaned++))
                log "Cleaned MAME dup: $mdir/$game_id.zip"
            fi
        done
    done
    [ "$cleaned" -gt 0 ] && log "Removed $cleaned MAME duplicates of FBNeo titles"

    # ── Phase 4: MAME-only titles ─────────────────────────────────────────
    # MAME 2003-Plus is login-restricted. Try Cylum's for MAME titles too.
    local mame_missing=()
    local mame_dest="$ROMS_BASE/mame"
    mkdir -p "$mame_dest"
    for game_id in "${!MAME_TITLES[@]}"; do
        if [ ! -f "$mame_dest/$game_id.zip" ] && [ ! -f "$mame_dest/roms/$game_id.zip" ]; then
            mame_missing+=("$game_id")
        fi
    done
    if [ ${#mame_missing[@]} -gt 0 ]; then
        local mame_dl=0
        local cylum_base="https://archive.org/download/$IA_CYLUM_ITEM/$IA_CYLUM_SUBDIR"
        log "Downloading ${#mame_missing[@]} MAME-only ROMs..."
        for game_id in "${mame_missing[@]}"; do
            local tmp_path="$mame_dest/$game_id.zip.dl_tmp"
            wget -q --timeout=30 -O "$tmp_path" "$cylum_base/$game_id.zip" 2>/dev/null
            if [ $? -eq 0 ] && [ -f "$tmp_path" ] && [ "$(stat -c%s "$tmp_path" 2>/dev/null)" -gt 1000 ]; then
                mv "$tmp_path" "$mame_dest/$game_id.zip"
                ((mame_dl++))
                log "✓ mame/$game_id.zip"
            else
                rm -f "$tmp_path"
                log "✗ mame/$game_id.zip (not available)"
            fi
            _wait_if_busy; sleep 1  # throttle + pause during netplay
        done
        log "MAME sync: $mame_dl downloaded"
    else
        log "MAME-only titles: all present"
    fi

    # ── Phase 5: download missing audio samples ─────────────────────────
    # Tiny files (~2 MB total) — runs inline, no background needed.
    sync_audio_samples

    # ── Phase 6: scrape missing game media ──────────────────────────────
    # Runs in the same process after ROM downloads — no competing traffic.
    local MEDIA_SCRAPER="$INSTALL_DIR/scripts/media-scraper.py"
    if [ -f "$MEDIA_SCRAPER" ]; then
        log "Scraping media for new ROMs..."
        python3 "$MEDIA_SCRAPER" "$dest_dir" --system-id 75 2>>"$LOG_FILE" || true
        python3 "$MEDIA_SCRAPER" "$ROMS_BASE/mame" --system-id 75 2>>"$LOG_FILE" || true
    fi

    # ES gamelists will be reloaded once by _background_media_scrape after
    # all boot tasks (sync + downloads + scrape) complete — no early reload here.
}

# ── SYNC AUDIO SAMPLES ────────────────────────────────────────────────────────
# Downloads missing audio sample .zip files for MAME games that need them.
# Samples are placed in /userdata/bios/mame2003-plus/samples/ where the
# MAME 2003-Plus core expects them (system_directory/mame2003-plus/samples/).
# Strategy: download the full mamesamples.rar (~24 MB) once, extract only
# the sample files we need, then delete the archive.
sync_audio_samples() {
    local samples_dir="/userdata/bios/mame2003-plus/samples"
    mkdir -p "$samples_dir"

    # Check which samples are missing
    local missing=()
    local game_id sample_file
    for game_id in "${!SAMPLE_MAP[@]}"; do
        sample_file="${SAMPLE_MAP[$game_id]}"
        [ -f "$samples_dir/$sample_file" ] && continue
        missing+=("$game_id")
    done

    [ ${#missing[@]} -eq 0 ] && { log "Audio samples: all present"; return 0; }

    log "Audio samples: ${#missing[@]} missing — downloading sample pack..."
    local pack_url="https://archive.org/download/$IA_MAME_SAMPLES_ITEM/$IA_MAME_SAMPLES_FILE"
    local pack_path="/tmp/mamesamples.rar"

    wget -q --timeout=120 --tries=2 -O "$pack_path" "$pack_url" 2>/dev/null
    if [ $? -ne 0 ] || [ ! -f "$pack_path" ] || [ "$(stat -c%s "$pack_path" 2>/dev/null)" -lt 1000000 ]; then
        rm -f "$pack_path"
        log "Audio samples: download failed"
        return 1
    fi

    # Extract only the sample files we need
    local extracted=0
    for game_id in "${missing[@]}"; do
        sample_file="${SAMPLE_MAP[$game_id]}"
        unrar e -o+ -inul "$pack_path" "$sample_file" "$samples_dir/" 2>/dev/null
        if [ -f "$samples_dir/$sample_file" ]; then
            ((extracted++))
            log "✓ samples/$sample_file (for $game_id)"
        else
            log "✗ samples/$sample_file (not in pack)"
        fi
    done

    rm -f "$pack_path"
    log "Audio samples: $extracted/${#missing[@]} extracted"
}

_sync_arcade_individual() {
    # Individual download from Cylum's for a small number of missing ROMs
    local dest_dir="$1"; shift
    local game_ids=("$@")
    local downloaded=0
    local cylum_base="https://archive.org/download/$IA_CYLUM_ITEM/$IA_CYLUM_SUBDIR"
    log "Individual download: ${#game_ids[@]} ROMs from Cylum's..."

    for game_id in "${game_ids[@]}"; do
        local tmp_path="$dest_dir/$game_id.zip.dl_tmp"
        wget -q --timeout=30 -O "$tmp_path" "$cylum_base/$game_id.zip" 2>/dev/null
        if [ $? -eq 0 ] && [ -f "$tmp_path" ] && [ "$(stat -c%s "$tmp_path" 2>/dev/null)" -gt 1000 ]; then
            mv "$tmp_path" "$dest_dir/$game_id.zip"
            ((downloaded++))
            log "✓ $game_id.zip ($downloaded/${#game_ids[@]})"
        else
            rm -f "$tmp_path"
            log "✗ $game_id.zip (not available)"
        fi
        _wait_if_busy; sleep 1  # throttle + pause during netplay
    done
    log "Individual sync: $downloaded/${#game_ids[@]} downloaded"
}

# Return the canonical archive identifier for an arcade ROM by its zip basename
arcade_canonical_source() {
    local game_id="$1"
    # Any ROM in the fbneo directory is canonical (full pack)
    if [ -f "$ROMS_BASE/fbneo/$game_id.zip" ] || [ -n "${FBNEO_TITLES[$game_id]:-}" ]; then
        echo "fbneo"
    elif [ -n "${MAME_TITLES[$game_id]:-}" ]; then
        echo "mame"
    else
        echo "unknown"
    fi
}

# ─── CALCULATE ROM CHECKSUM ──────────────────────────────────────────────────
get_rom_hash() {
    local rom_path="$1"
    local ext="${rom_path##*.}"
    ext=$(echo "$ext" | tr '[:upper:]' '[:lower:]')
    if [ "$ext" = "zip" ]; then
        local inner
        inner=$(unzip -l "$rom_path" 2>/dev/null \
            | grep -E '\.(nes|sfc|smc|md|gba|gb|gbc|pce|sms|gg)$' \
            | awk '{print $4}' | head -1)
        [ -n "$inner" ] && {
            unzip -p "$rom_path" "$inner" 2>/dev/null | md5sum | cut -d' ' -f1
            return
        }
    fi
    md5sum "$rom_path" 2>/dev/null | cut -d' ' -f1
}

# ─── CHECK ROM AGAINST NO-INTRO DATABASE ─────────────────────────────────────
# Uses dat_checker.py and the pre-built cache for O(1) lookup.
# Falls back to "unchecked" when no DATs have been placed in NOINTRO_DATS_DIR.
check_rom_nointro() {
    local rom_path="$1"

    # No DAT directory or empty — nothing to check against
    if [ ! -d "$NOINTRO_DATS_DIR" ] || \
       [ -z "$(ls -A "$NOINTRO_DATS_DIR"/*.dat "$NOINTRO_DATS_DIR"/*.xml 2>/dev/null)" ]; then
        echo '{"status":"unchecked","canonical":null}'
        return
    fi

    # No cache yet — should have been built at boot, but handle gracefully
    if [ ! -f "$DAT_CACHE" ]; then
        echo '{"status":"unchecked","canonical":null,"note":"cache missing"}'
        return
    fi

    local hash result
    hash=$(get_rom_hash "$rom_path")

    result=$(python3 "$DAT_CHECKER" check-md5 "$hash" "$DAT_CACHE" 2>/dev/null)
    local exit_code=$?

    if [ $exit_code -eq 0 ]; then
        echo "{\"status\":\"verified\",\"canonical\":true,\"hash\":\"$hash\",\"source\":\"dat\",\"match\":\"$result\"}"
    elif [ $exit_code -eq 2 ]; then
        echo '{"status":"unchecked","canonical":null,"note":"cache missing"}'
    else
        echo "{\"status\":\"unknown\",\"canonical\":false,\"hash\":\"$hash\"}"
    fi
}

# ─── QUEUE CANONICAL REPLACEMENT ─────────────────────────────────────────────
# Searches Internet Archive and adds to the download queue.
# replace_path: if non-empty, this file will be deleted after a successful dl.
queue_canonical_download() {
    # Task 8: respect auto_download_roms opt-in flag
    if [[ "${auto_download_roms:-true}" != "true" ]]; then
        log "ROM auto-download disabled (auto_download_roms=false in config)"
        return 0
    fi
    local system="$1"
    local game_name="$2"
    local dest_dir="$3"
    local replace_path="${4:-}"

    # For arcade systems, use game_id (zip basename without ext) to pick the
    # right canonical archive (FBNeo or MAME 2003-Plus)
    local game_id
    game_id=$(basename "${replace_path:-$game_name}" | sed 's/\.[^.]*$//' | tr '[:upper:]' '[:lower:]')

    # Route arcade ROMs to the correct folder based on their canonical source.
    # FBNeo-titled ROMs must go to fbneo/ (not mame/) so the romset matches
    # the core that will be used to launch them.
    case "$system" in
        arcade|mame|neogeo|fbneo)
            # If game_id doesn't match a known key (e.g. display name was passed
            # instead of zip shortcode), reverse-lookup by title → game_id
            if [ -z "${FBNEO_TITLES[$game_id]:-}" ] && [ -z "${MAME_TITLES[$game_id]:-}" ]; then
                local _lookup_name
                _lookup_name=$(echo "$game_name" | tr '[:upper:]' '[:lower:]')
                local _found_id=""
                for _kid in "${!FBNEO_TITLES[@]}"; do
                    local _title="${FBNEO_TITLES[$_kid]%%|*}"
                    _title=$(echo "$_title" | tr '[:upper:]' '[:lower:]')
                    if [ "$_title" = "$_lookup_name" ]; then
                        _found_id="$_kid"; break
                    fi
                done
                if [ -z "$_found_id" ]; then
                    for _kid in "${!MAME_TITLES[@]}"; do
                        local _title="${MAME_TITLES[$_kid]%%|*}"
                        _title=$(echo "$_title" | tr '[:upper:]' '[:lower:]')
                        if [ "$_title" = "$_lookup_name" ]; then
                            _found_id="$_kid"; break
                        fi
                    done
                fi
                if [ -n "$_found_id" ]; then
                    log "Resolved display name '$game_name' → game_id '$_found_id'"
                    game_id="$_found_id"
                fi
            fi
            local _src
            _src=$(arcade_canonical_source "$game_id")
            if [ "$_src" = "fbneo" ]; then
                dest_dir="$ROMS_BASE/fbneo"
                log "Routing $game_id to fbneo/ (FBNeo title)"
            elif [ "$_src" = "mame" ]; then
                dest_dir="$ROMS_BASE/mame"
                log "Routing $game_id to mame/ (MAME title)"
            fi
            ;;
    esac

    local collection
    collection=$(ia_collection_for "$system" "$game_id")
    if [ -z "$collection" ]; then
        log "No IA collection for '$system' — skipping $game_name"
        return 1
    fi

    log "Queuing canonical download: $game_name ($system)"

    # ── Arcade ROMs: direct download (no search needed) ──────────────────────
    # Use Cylum's FBNeo (unrestricted) for individual arcade ROM downloads.
    # The process_download_queue handler will also try fallback sources.
    case "$system" in
        arcade|mame|neogeo|fbneo)
            local direct_url="https://archive.org/download/$IA_CYLUM_ITEM/$IA_CYLUM_SUBDIR/${game_id}.zip"
            log "Arcade direct URL: $direct_url"
            python3 - "$game_name" "$game_id" "$dest_dir" "$system" "$DOWNLOAD_QUEUE" "$replace_path" "$direct_url" "$collection" <<'PYEOF'
import json, sys, os, tempfile
game_name, game_id, dest_dir, system, queue_file, replace_path, direct_url, collection = sys.argv[1:]

try:
    queue = []
    if os.path.exists(queue_file):
        try:
            queue = json.load(open(queue_file))
        except Exception:
            pass

    for e in queue:
        if replace_path and e.get("replace_path") == replace_path:
            print(f"[ROM] Already queued replacement for {replace_path}", flush=True)
            sys.exit(0)
        if e.get("direct_url") == direct_url:
            print(f"[ROM] Already in queue: {game_id}", flush=True)
            sys.exit(0)

    queue.append({
        "identifier": collection, "title": game_name, "system": system,
        "dest_dir": dest_dir, "replace_path": replace_path,
        "direct_url": direct_url, "rom_filename": f"{game_id}.zip",
        "url": f"https://archive.org/download/{collection}", "status": "queued"
    })
    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(queue_file) or ".", suffix=".tmp")
    try:
        with os.fdopen(fd, "w") as fh:
            json.dump(queue, fh, indent=2)
        os.replace(tmp, queue_file)
    except Exception:
        try: os.unlink(tmp)
        except OSError: pass
        raise
    print(f"[ROM] Queued arcade direct: {game_name} ({game_id}.zip from {collection})", flush=True)
except Exception as e:
    print(f"[ROM] Queue error: {e}", flush=True)
PYEOF
            return $?
            ;;
    esac

    # ── Console ROMs: not individually downloadable ─────────────────────────
    # Console ROMs use bulk system zips from ni-roms.  The priority section
    # handles batch download + selective extraction per system. Individual
    # queue_canonical_download calls are only used for arcade ROMs.
    log "No individual download path for console system '$system' — skipped"
    return 1
}

# ─── PROCESS DOWNLOAD QUEUE ──────────────────────────────────────────────────
# Downloads each queued ROM, then swaps out replace_path if provided.
process_download_queue() {
    [ ! -f "$DOWNLOAD_QUEUE" ] && { log "No downloads queued"; return; }
    local count
    count=$(python3 -c "
import json
try:
    print(len([x for x in json.load(open('$DOWNLOAD_QUEUE')) if x.get('status')=='queued']))
except:
    print(0)" 2>/dev/null)
    [ "$count" = "0" ] && { log "Download queue empty"; return; }

    # Acquire global download lock — waits for core downloads to finish first
    exec 8>"$DOWNLOAD_LOCK"
    flock -x 8
    log "Download lock acquired (ROMs)"

    log "Processing $count queued ROM download(s)..."

    python3 - "$DOWNLOAD_QUEUE" "$LOG_FILE" <<'PYEOF'
import json, shutil, subprocess, os, sys, time, tempfile

queue_file, log_file = sys.argv[1], sys.argv[2]

ROM_EXTS  = ('.zip','.7z','.nes','.sfc','.smc','.md','.gen',
             '.gba','.gb','.gbc','.pce',
             '.sms','.gg','.a26','.rom','.neo')
SKIP_FMTS = {'metadata','sqlite','torrent','xml','jpg','jpeg',
             'png','gif','txt','pdf','item tile','json'}

# Minimum free disk space required before starting any download (500 MB)
MIN_FREE_BYTES = 500 * 1024 * 1024
DOWNLOAD_FLAG  = "/tmp/netplay_downloading.json"

def plog(msg):
    line = f"[{time.strftime('%H:%M:%S')}] ROM: {msg}\n"
    sys.stdout.write(line); sys.stdout.flush()
    try:
        open(log_file, "a").write(line)
    except Exception:
        pass

def es_notify(msg):
    try:
        import urllib.request
        req = urllib.request.Request(
            "http://127.0.0.1:1234/notify",
            data=msg.encode(),
            headers={"Content-Type": "text/plain"},
            method="POST")
        urllib.request.urlopen(req, timeout=2)
    except Exception:
        pass

def write_flag(current="", remaining=0):
    try:
        fd, tmp = tempfile.mkstemp(dir="/tmp", suffix=".tmp")
        with os.fdopen(fd, "w") as f:
            json.dump({"active": True, "current": current, "remaining": remaining,
                       "started": int(time.time())}, f)
        os.replace(tmp, DOWNLOAD_FLAG)
    except Exception:
        pass

def clear_flag():
    try:
        os.unlink(DOWNLOAD_FLAG)
    except OSError:
        pass

def free_bytes(path):
    try:
        st = os.statvfs(path if os.path.isdir(path) else os.path.dirname(path) or "/")
        return st.f_bavail * st.f_frsize
    except Exception:
        return None

def pick_best_rom(files_list):
    candidates = []
    for f in files_list:
        if not isinstance(f, dict): continue
        if f.get("format","").lower() in SKIP_FMTS or f.get("source") == "metadata":
            continue
        ext = os.path.splitext(f.get("name",""))[1].lower()
        if ext in ROM_EXTS:
            try: size = int(f.get("size", 0))
            except: size = 0
            candidates.append((f["name"], ext, size))
    if not candidates: return None
    for pref in ('.zip', '.7z'):
        zips = [c for c in candidates if c[1] == pref]
        if zips: return max(zips, key=lambda c: c[2])[0]
    return max(candidates, key=lambda c: c[2])[0]

queue = json.load(open(queue_file))
pending = [e for e in queue if e.get("status") == "queued"]

if pending:
    write_flag(remaining=len(pending))
    es_notify(f"ROM update: downloading {len(pending)} file(s)...")
    plog(f"Starting {len(pending)} download(s)")

completed = 0
for i, entry in enumerate(queue):
    if entry.get("status") != "queued":
        continue

    identifier   = entry["identifier"]
    dest         = entry["dest_dir"]
    title        = entry["title"]
    replace_path = entry.get("replace_path", "")

    remaining = len([e for e in queue[i:] if e.get("status") == "queued"])
    write_flag(current=title, remaining=remaining)

    # Check free disk space before fetching metadata or downloading
    free = free_bytes(dest if os.path.isdir(dest) else "/userdata")
    if free is not None and free < MIN_FREE_BYTES:
        plog(f"SKIP {title}: only {free // (1024*1024)} MB free (need 500 MB) — stopping queue")
        break   # No point checking remaining entries; space is a shared constraint

    plog(f"Downloading: {title} ({identifier})")

    # ── Arcade direct download: skip metadata fetch entirely ─────────────
    direct_url  = entry.get("direct_url", "")
    rom_filename = entry.get("rom_filename", "")
    rom_bytes   = 0   # unknown for arcade direct; progress bar won't show %
    if direct_url and rom_filename:
        url      = direct_url
        rom_file = rom_filename
        plog(f"Direct download: {rom_file} from {identifier}")
    else:
        # ── Fallback: fetch IA metadata to find the right file ───────────
        meta_r = subprocess.run(
            ["curl", "-s", "--max-time", "20",
             f"https://archive.org/metadata/{identifier}"],
            capture_output=True, text=True)
        try:
            metadata = json.loads(meta_r.stdout)
        except Exception as e:
            queue[i]["status"] = "error"
            queue[i]["error"]  = f"Metadata parse error: {e}"
            plog(f"ERROR: {queue[i]['error']}")
            continue

        files_list = metadata.get("files", [])
        if not isinstance(files_list, list):
            queue[i]["status"] = "error"
            queue[i]["error"]  = "Unexpected files type"
            continue

        rom_file = pick_best_rom(files_list)
        if not rom_file:
            queue[i]["status"] = "error"
            queue[i]["error"]  = f"No ROM file found in {identifier}"
            plog(f"No ROM in {identifier}")
            continue

        # Check that the ROM file will fit — IA metadata includes exact file sizes
        rom_meta  = next((f for f in files_list if f.get("name") == rom_file), {})
        rom_bytes = int(rom_meta.get("size", 0) or 0)
        free_now  = free_bytes(dest if os.path.isdir(dest) else "/userdata")
        if free_now is not None and rom_bytes > 0:
            needed = rom_bytes + MIN_FREE_BYTES   # keep 500 MB headroom after download
            if free_now < needed:
                queue[i]["status"] = "error"
                queue[i]["error"]  = (f"Not enough space: need {needed // (1024*1024)} MB, "
                                      f"have {free_now // (1024*1024)} MB free")
                plog(f"SKIP {title}: {queue[i]['error']}")
                continue

        d1     = metadata.get("d1", "")
        ia_dir = metadata.get("dir", f"/items/{identifier}")
        url    = f"https://{d1}{ia_dir}/{rom_file}" if d1 else \
                 f"https://archive.org/download/{identifier}/{rom_file}"

    os.makedirs(dest, exist_ok=True)
    dest_path = os.path.join(dest, rom_file)
    tmp_path  = dest_path + ".dl_tmp"

    plog(f"wget → {dest_path}")
    # Task 2: report download start
    subprocess.run(["curl", "-s", "-X", "POST", "http://localhost:8765/api/download-progress",
        "-H", "Content-Type: application/json",
        "-d", f'{{"key":"{identifier}","status":"downloading","percent":0,"filename":"{rom_file}"}}'],
        capture_output=True)
    cancel_file = f"/tmp/netplay-cancel-{identifier}"
    dl_proc = subprocess.Popen(["wget", "-q", "--timeout=30", "-O", tmp_path, url],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    cancelled = False
    timed_out = False
    dl_start = time.monotonic()
    last_report_t = dl_start
    MAX_DL_SECONDS = 1200  # 20 minutes — hard kill for stalled downloads
    while dl_proc.poll() is None:
        if os.path.exists(cancel_file):
            dl_proc.terminate()
            try: dl_proc.wait(timeout=3)
            except Exception: dl_proc.kill()
            cancelled = True
            try: os.unlink(cancel_file)
            except OSError: pass
            break
        if time.monotonic() - dl_start > MAX_DL_SECONDS:
            dl_proc.terminate()
            try: dl_proc.wait(timeout=5)
            except Exception: dl_proc.kill()
            timed_out = True
            if os.path.exists(tmp_path):
                try: os.unlink(tmp_path)
                except OSError: pass
            break
        # Real-time progress: stat the partial file every 5 s (rom_bytes from IA metadata)
        if rom_bytes > 0 and (time.monotonic() - last_report_t) >= 5:
            try:
                pct = min(99, int(os.path.getsize(tmp_path) * 100 / rom_bytes))
                subprocess.run(
                    ["curl", "-s", "--max-time", "3", "-X", "POST",
                     "http://localhost:8765/api/download-progress",
                     "-H", "Content-Type: application/json",
                     "-d", f'{{"key":"{identifier}","status":"downloading","percent":{pct},"filename":"{rom_file}"}}'],
                    capture_output=True)
            except OSError:
                pass
            last_report_t = time.monotonic()
        time.sleep(0.5)

    if timed_out:
        queue[i]["status"] = "error"
        queue[i]["error"]  = "Download timed out (20 min)"
        plog(f"TIMEOUT: {title}")
        subprocess.run(
            ["curl", "-s", "--max-time", "3", "-X", "POST",
             "http://localhost:8765/api/download-progress",
             "-H", "Content-Type: application/json",
             "-d", f'{{"key":"{identifier}","status":"error","percent":0,"filename":"{rom_file}"}}'],
            capture_output=True)
        continue

    if cancelled:
        if os.path.exists(tmp_path): os.unlink(tmp_path)
        queue[i]["status"] = "cancelled"
        plog(f"Download cancelled: {title}")
        subprocess.run(["curl", "-s", "-X", "POST", "http://localhost:8765/api/download-progress",
            "-H", "Content-Type: application/json",
            "-d", f'{{"key":"{identifier}","status":"cancelled","percent":0,"filename":"{rom_file}"}}'],
            capture_output=True)
        continue

    class _R:
        def __init__(self, code): self.returncode = code
    dl = _R(dl_proc.returncode or 0)

    # Task 5: size check before moving
    MIN_SIZE = 1000
    if dl.returncode == 0 and os.path.exists(tmp_path):
        actual_size = os.path.getsize(tmp_path)
        if actual_size <= MIN_SIZE:
            plog(f"ERROR: downloaded file too small ({actual_size} bytes) — discarding")
            os.remove(tmp_path)
            queue[i]["status"] = "error"
            queue[i]["error"]  = f"File too small: {actual_size} bytes"
            # Task 2: report error
            subprocess.run(["curl", "-s", "-X", "POST", "http://localhost:8765/api/download-progress",
                "-H", "Content-Type: application/json",
                "-d", f'{{"key":"{identifier}","status":"error","percent":0,"filename":"{rom_file}"}}'],
                capture_output=True)
            continue

    if dl.returncode == 0 and os.path.exists(tmp_path) and os.path.getsize(tmp_path) > MIN_SIZE:
        if replace_path and os.path.exists(replace_path) and replace_path != dest_path:
            try:
                quarantine_dir = "/userdata/roms/quarantine"
                os.makedirs(quarantine_dir, exist_ok=True)
                q_name = os.path.basename(replace_path)
                shutil.copy2(replace_path, os.path.join(quarantine_dir, q_name))
                os.remove(replace_path)
                plog(f"Quarantined: {q_name} → {quarantine_dir}")
            except Exception as e:
                plog(f"Could not quarantine {replace_path}: {e}")
        os.rename(tmp_path, dest_path)
        queue[i]["status"]     = "complete"
        queue[i]["local_path"] = dest_path
        queue[i]["rom_file"]   = rom_file
        plog(f"OK: {rom_file} ({os.path.getsize(dest_path):,} bytes)")

        # ── Update gamelist.xml: repoint old entry to new file ────────
        if replace_path and replace_path != dest_path:
            old_fn = os.path.basename(replace_path)
            new_fn = rom_file
            gl_path = os.path.join(dest, "gamelist.xml")
            try:
                import xml.etree.ElementTree as _ET
                if os.path.isfile(gl_path):
                    _tree = _ET.parse(gl_path)
                    _root = _tree.getroot()
                    _updated = False
                    _dupes = []
                    for _g in _root.findall("game"):
                        _p = _g.find("path")
                        if _p is None or not _p.text:
                            continue
                        _gfn = _p.text.lstrip("./")
                        if _gfn == old_fn:
                            _p.text = "./" + new_fn
                            _updated = True
                        elif _gfn == new_fn and _g.find("image") is None and _g.find("desc") is None:
                            _dupes.append(_g)
                    for _d in _dupes:
                        try: _root.remove(_d)
                        except ValueError: pass
                    if _updated:
                        _tree.write(gl_path, encoding="unicode", xml_declaration=True)
                        plog(f"Gamelist: repointed {old_fn} → {new_fn}")
            except Exception as _e:
                plog(f"Gamelist update failed: {_e}")

        # Report "verifying" so UI doesn't appear frozen between rename and hash check
        subprocess.run(
            ["curl", "-s", "--max-time", "3", "-X", "POST",
             "http://localhost:8765/api/download-progress",
             "-H", "Content-Type: application/json",
             "-d", f'{{"key":"{identifier}","status":"verifying","percent":100,"filename":"{rom_file}"}}'],
            capture_output=True)

        # Post-download hash verification via DAT cache (console ROMs only)
        _dat_cache   = '/userdata/system/netplay-arcade/dats/.cache.json'
        _dat_checker = '/userdata/system/netplay-arcade/scripts/dat_checker.py'
        if os.path.exists(_dat_cache) and os.path.exists(_dat_checker):
            vr = subprocess.run(
                ['python3', _dat_checker, 'check-file', dest_path, _dat_cache],
                capture_output=True, text=True)
            if vr.returncode == 0:
                plog(f"Hash verified: {rom_file}")
                queue[i]["hash_verified"] = True
            elif vr.returncode == 1:
                plog(f"Note: {rom_file} hash not in DAT database — accepting download")
                queue[i]["hash_verified"] = False
            # returncode 2 = no cache — skip silently

        # report complete
        subprocess.run(["curl", "-s", "-X", "POST", "http://localhost:8765/api/download-progress",
            "-H", "Content-Type: application/json",
            "-d", f'{{"key":"{identifier}","status":"complete","percent":100,"filename":"{rom_file}"}}'],
            capture_output=True)
        completed += 1
    else:
        if os.path.exists(tmp_path): os.remove(tmp_path)
        queue[i]["status"] = "error"
        queue[i]["error"]  = f"wget exited {dl.returncode}"
        plog(f"Download failed: {title}")
        # Task 2: report error
        subprocess.run(["curl", "-s", "-X", "POST", "http://localhost:8765/api/download-progress",
            "-H", "Content-Type: application/json",
            "-d", f'{{"key":"{identifier}","status":"error","percent":0,"filename":"{rom_file}"}}'],
            capture_output=True)

import tempfile as _tf
_fd, _tmp = _tf.mkstemp(dir=os.path.dirname(queue_file) or ".", suffix=".tmp")
try:
    with os.fdopen(_fd, "w") as _fh:
        json.dump(queue, _fh, indent=2)
    os.replace(_tmp, queue_file)
except Exception:
    try: os.unlink(_tmp)
    except OSError: pass
    raise

clear_flag()
if completed:
    es_notify(f"ROM updates complete ({completed} downloaded)")
plog(f"Queue processing complete ({completed} downloaded)")
# Write count so the calling bash can decide whether to reload ES
with open("/tmp/_dl_completed_count", "w") as _cf:
    _cf.write(str(completed))
PYEOF
    # Release global download lock
    flock -u 8
    exec 8>&-
    log "Download lock released (ROMs)"

    # ── Post-download: scrape media for any systems that got new ROMs ─────
    local MEDIA_SCRAPER="$SCRIPT_DIR/media-scraper.py"
    if [ -f "$MEDIA_SCRAPER" ] && [ -f "$DOWNLOAD_QUEUE" ]; then
        local _dl_systems
        _dl_systems=$(python3 -c "
import json, sys, os
SS_IDS = {
    'nes':3,'snes':4,'megadrive':1,'genesis':1,'gba':12,'gb':9,'gbc':10,
    'arcade':75,'fbneo':75,'mame':75,'neogeo':75,
    'atari2600':26,'mastersystem':2,'gamegear':21,'nds':15,
    'turbografx16':31,'pcengine':31,'32x':19,'sega32x':19,
}
try:
    q = json.load(open(sys.argv[1]))
    seen = set()
    for e in q:
        if e.get('status') == 'complete' and e.get('dest_dir'):
            d = e['dest_dir']
            if d not in seen:
                seen.add(d)
                sname = os.path.basename(d)
                sid = SS_IDS.get(sname, '')
                if sid:
                    print(f'{d}|{sid}')
except Exception:
    pass
" "$DOWNLOAD_QUEUE" 2>/dev/null)
        while IFS='|' read -r _sd _sid; do
            [ -z "$_sd" ] || [ -z "$_sid" ] && continue
            [ -d "$_sd" ] || continue
            log "Scraping media for $(basename "$_sd") (SS ID: $_sid)..."
            python3 "$MEDIA_SCRAPER" "$_sd" --system-id "$_sid" 2>>"$LOG_FILE" || true
        done <<< "$_dl_systems"
    fi

    # ── Reload ES gamelists only if this run actually downloaded ROMs ─────
    local _this_run_completed
    _this_run_completed=$(cat /tmp/_dl_completed_count 2>/dev/null || echo 0)
    rm -f /tmp/_dl_completed_count
    if [ "${_this_run_completed:-0}" -gt 0 ]; then
        _generate_netplay_collection
        _es_reload_gamelists
        log "ES gamelists reloaded ($_this_run_completed downloaded this run)"
    fi
}

# ─── BOOT SCAN ───────────────────────────────────────────────────────────────
# Arcade: scans fbneo/ directory for all .zip files (full pack is canonical).
# MAME-only titles are checked against the MAME_TITLES array.
# Console ROMs are only hashed when a DAT cache is available.
_scan_progress_write() {
    # _scan_progress_write <phase> <label> [checked] [total]
    local phase="$1" label="$2" checked="${3:-0}" total="${4:-0}"
    printf '{"active":true,"phase":"%s","label":"%s","checked":%d,"total":%d,"started":%d}\n' \
        "$phase" "$label" "$checked" "$total" "${_scan_started:-0}" \
        > /tmp/rom_scan_progress.json
}

_background_media_scrape() {
    # Scrape media for all systems that have ROMs missing from gamelist.xml.
    # Runs at low priority after boot scan, uses its own lockfile.
    local _SCRAPE_LOCK="/tmp/outbreak-media-scrape.lock"
    exec 6>"$_SCRAPE_LOCK"
    if ! flock -n 6; then
        log "Media scrape already running — skipping"
        exec 6>&-
        return 0
    fi

    local _scraper="$SCRIPT_DIR/media-scraper.py"
    [ -f "$_scraper" ] || { exec 6>&-; return 0; }

    log "Background media scrape starting..."
    local _scraped_systems=0

    # All systems with ROMs worth scraping
    local _all_systems="fbneo mame nes snes megadrive gba gb gbc mastersystem gamegear nds sega32x atari2600 pcengine neogeo arcade"
    for _sys in $_all_systems; do
        local _sys_dir="$ROMS_BASE/$_sys"
        [ -d "$_sys_dir" ] || continue

        # Count ROMs vs gamelist entries — skip if fully scraped
        local _rom_count _gl_count
        _rom_count=$(find "$_sys_dir" -maxdepth 1 -type f \
            \( -name "*.zip" -o -name "*.7z" -o -name "*.nes" -o -name "*.sfc" \
               -o -name "*.smc" -o -name "*.md" -o -name "*.gen" -o -name "*.smd" \
               -o -name "*.gba" -o -name "*.gb" -o -name "*.gbc" -o -name "*.sms" \
               -o -name "*.gg" -o -name "*.nds" -o -name "*.32x" -o -name "*.pce" \
               -o -name "*.a26" -o -name "*.chd" \) 2>/dev/null | wc -l)
        _gl_count=$(grep -c "<game>" "$_sys_dir/gamelist.xml" 2>/dev/null || echo 0)

        [ "$_rom_count" -eq 0 ] && continue

        # Count ROMs missing thumbnail files (more accurate than gamelist count alone,
        # since bare gamelist entries without media files need re-scraping)
        local _missing_media=0
        if [ "$_gl_count" -ge "$((_rom_count - 5))" ]; then
            # Gamelist looks complete — check for missing thumbnail files
            local _images_dir="$_sys_dir/images"
            while IFS= read -r _rf; do
                local _rstem
                _rstem=$(basename "$_rf")
                _rstem="${_rstem%.*}"
                [ ! -f "$_images_dir/${_rstem}-thumb.png" ] && ((_missing_media++))
            done < <(find "$_sys_dir" -maxdepth 1 -type f \
                \( -name "*.zip" -o -name "*.7z" -o -name "*.nes" -o -name "*.sfc" \
                   -o -name "*.smc" -o -name "*.md" -o -name "*.gen" -o -name "*.smd" \
                   -o -name "*.gba" -o -name "*.gb" -o -name "*.gbc" -o -name "*.sms" \
                   -o -name "*.gg" -o -name "*.nds" -o -name "*.32x" -o -name "*.pce" \
                   -o -name "*.a26" -o -name "*.chd" \) 2>/dev/null)
            [ "$_missing_media" -eq 0 ] && continue
        fi

        local _missing=$((_rom_count - _gl_count + _missing_media))
        log "Media scrape: $_sys has $_missing unscraped ROM(s) — scraping..."
        nice -n 15 python3 "$_scraper" "$_sys_dir" >/dev/null 2>&1
        ((_scraped_systems++))

    done

    exec 6>&-

    # Single ES reload after all boot work is done (sync + downloads + scrape).
    # Always reload — even if no scraping happened, downloads may have added ROMs.
    _es_reload_gamelists
    if [ "$_scraped_systems" -gt 0 ]; then
        log "Media scrape complete: $_scraped_systems system(s) scraped — gamelists reloaded"
    else
        log "Media scrape: all systems already scraped — gamelists reloaded"
    fi
}

# ─── NETPLAY COLLECTION GENERATOR ─────────────────────────────────────────────
# Writes /userdata/system/configs/emulationstation/collections/custom-Outbreak Host.cfg
# containing absolute paths to every canonical netplay ROM that exists on disk.
# Registers the collection in es_settings.cfg if not already present.
_generate_netplay_collection() {
    local roms_base="${1:-/userdata/roms}"
    local ES_CFG_DIR="/userdata/system/configs/emulationstation"
    local COLL_DIR="$ES_CFG_DIR/collections"
    local COLL_FILE="$COLL_DIR/custom-Outbreak Host.cfg"
    local ES_SETTINGS="$ES_CFG_DIR/es_settings.cfg"

    mkdir -p "$COLL_DIR"

    # Build list: system_dir|title_array_name|extension_glob
    # FBNeo/MAME keys are zip filenames; console keys are full ROM names.
    local _found=0
    : > "$COLL_FILE.tmp"

    # ── Arcade (zip-based, key = filename without .zip) ──────────────────────
    local _key
    for _key in "${!FBNEO_TITLES[@]}"; do
        [ -f "$roms_base/fbneo/$_key.zip" ] && {
            echo "$roms_base/fbneo/$_key.zip" >> "$COLL_FILE.tmp"
            ((_found++))
        }
    done
    for _key in "${!MAME_TITLES[@]}"; do
        [ -f "$roms_base/mame/$_key.zip" ] && {
            echo "$roms_base/mame/$_key.zip" >> "$COLL_FILE.tmp"
            ((_found++))
        }
    done

    # ── Console (key = full ROM name, may be .zip or native extension) ───────
    _scan_console_titles() {
        local sys_dir="$1"; shift
        local _rom_name _match
        for _rom_name in "$@"; do
            _match=""
            # Check .zip first, then any file starting with the ROM name
            [ -f "$roms_base/$sys_dir/$_rom_name.zip" ] && _match="$roms_base/$sys_dir/$_rom_name.zip"
            if [ -z "$_match" ]; then
                # Glob for native extensions (e.g., "Contra (USA).nes")
                for _f in "$roms_base/$sys_dir/$_rom_name".*; do
                    [ -f "$_f" ] && { _match="$_f"; break; }
                done
            fi
            [ -n "$_match" ] && {
                echo "$_match" >> "$COLL_FILE.tmp"
                ((_found++))
            }
        done
    }

    _scan_console_titles "nes"          "${!NES_TITLES[@]}"
    _scan_console_titles "snes"         "${!SNES_TITLES[@]}"
    _scan_console_titles "megadrive"    "${!GENESIS_TITLES[@]}"
    _scan_console_titles "gb"           "${!GB_TITLES[@]}"
    _scan_console_titles "gba"          "${!GBA_TITLES[@]}"
    _scan_console_titles "mastersystem" "${!MASTERSYSTEM_TITLES[@]}"
    _scan_console_titles "gamegear"     "${!GAMEGEAR_TITLES[@]}"
    _scan_console_titles "nds"          "${!NDS_TITLES[@]}"
    _scan_console_titles "sega32x"      "${!SEGA32X_TITLES[@]}"
    _scan_console_titles "atari2600"    "${!ATARI2600_TITLES[@]}"
    _scan_console_titles "pcengine"     "${!TURBOGRAFX16_TITLES[@]}"

    # Sort for deterministic output, then atomically replace
    sort "$COLL_FILE.tmp" > "$COLL_FILE"
    rm -f "$COLL_FILE.tmp"
    log "Collection: $_found canonical ROM(s) in Outbreak Host"

    # ── Register collection in es_settings.cfg ───────────────────────────────
    if [ -f "$ES_SETTINGS" ]; then
        if ! grep -q 'CollectionSystemsCustom' "$ES_SETTINGS"; then
            # No custom collections setting exists — add it
            sed -i '/<\/config>/i\    <string name="CollectionSystemsCustom" value="Outbreak Host" />' "$ES_SETTINGS"
            log "Collection: registered Outbreak Host in es_settings.cfg"
        elif ! grep -q 'Outbreak Host' "$ES_SETTINGS"; then
            # Setting exists but doesn't include our collection — append
            sed -i 's/\(CollectionSystemsCustom[^"]*value="[^"]*\)/\1,Outbreak Host/' "$ES_SETTINGS"
            log "Collection: appended Outbreak Host to CollectionSystemsCustom"
        fi
    fi
}

boot_scan() {
    # Singleton lock — prevent concurrent boot scans using flock (atomic).
    local _SCAN_LOCK="/tmp/netplay_bootscan.lock"
    exec 9>"$_SCAN_LOCK"
    if ! flock -n 9; then
        log "Boot scan already running — skipping duplicate"
        exec 9>&-
        return 0
    fi
    # Lock acquired — fd 9 stays open (and locked) for the lifetime of this process.
    trap 'exec 9>&-' EXIT

    log "=== Boot ROM scan starting ==="
    local _scan_started; _scan_started=$(date +%s)
    _scan_progress_write "starting" "Starting ROM scan..." 0 0

    local total=0 verified=0 mismatched=0 unknown=0 queued=0
    local arcade_total=0 arcade_verified=0 mame_total=0 mame_verified=0
    local SYS_COUNTS_FILE="/tmp/rom_sys_counts.tmp"
    local ROM_INDEX_FILE="/userdata/system/netplay-arcade/rom_index.json"
    local ROM_INDEX_TMP
    ROM_INDEX_TMP=$(mktemp)
    > "$SYS_COUNTS_FILE"
    local network_ok=false

    if has_network; then
        network_ok=true
        log "Network OK — mismatched ROMs will be auto-corrected"
    else
        log "No network — hash check only, downloads deferred"
    fi

    # ── Arcade: count what's present, then sync missing in background ─────
    # Scan the fbneo directory — the full 905-game pack is canonical,
    # not just the curated FBNEO_TITLES metadata list.
    log "Counting FBNeo titles..."
    local fbneo_dir="$ROMS_BASE/fbneo"
    local fbneo_expected=905  # full pack size
    _scan_progress_write "fbneo" "Checking FBNeo arcade titles..." 0 "$fbneo_expected"
    if [ -d "$fbneo_dir" ]; then
        for rom_file in "$fbneo_dir"/*.zip; do
            [ -f "$rom_file" ] || continue
            local game_id
            game_id=$(basename "$rom_file" .zip)
            ((total++)); ((verified++))
            ((arcade_total++)); ((arcade_verified++))
            echo "$game_id|$rom_file|fbneo|fbneo" >> "$ROM_INDEX_TMP"
        done
    fi
    echo "arcade $arcade_verified $fbneo_expected" >> "$SYS_COUNTS_FILE"

    log "Counting MAME-only titles..."
    _scan_progress_write "mame" "Checking MAME arcade titles..." 0 "${#MAME_TITLES[@]}"
    local mame_dir="$ROMS_BASE/mame"
    for game_id in "${!MAME_TITLES[@]}"; do
        local rom_path=""
        for _mame_candidate in "$mame_dir/$game_id.zip" "$mame_dir/roms/$game_id.zip"; do
            [ -f "$_mame_candidate" ] && { rom_path="$_mame_candidate"; break; }
        done
        if [ -n "$rom_path" ]; then
            ((total++)); ((verified++))
            ((mame_total++)); ((mame_verified++))
            echo "$game_id|$rom_path|mame|mame" >> "$ROM_INDEX_TMP"
        fi
    done
    echo "mame $mame_verified ${#MAME_TITLES[@]}" >> "$SYS_COUNTS_FILE"

    # ── Check which specific canonical FBNeo titles are missing ─────────────
    # Total zip count can be misleading (junk/variant ROMs inflate count).
    # Check each FBNEO_TITLES key individually to find truly missing games.
    local fbneo_titles_missing=0
    for game_id in "${!FBNEO_TITLES[@]}"; do
        if [ ! -f "$fbneo_dir/$game_id.zip" ]; then
            ((fbneo_titles_missing++))
        fi
    done
    local mame_only_missing=$(( ${#MAME_TITLES[@]} - mame_verified ))

    # ── Run arcade sync inline (low priority) ──────────────────────────────
    # Runs within this process so the Python server's subprocess.run() blocks
    # until sync completes — single-process architecture.
    if $network_ok && [ $((fbneo_titles_missing + mame_only_missing)) -gt 0 ]; then
        log "Starting arcade sync ($fbneo_titles_missing FBNeo canonical + $mame_only_missing MAME missing)..."
        nice -n 15 bash "${BASH_SOURCE[0]}" sync-arcade 2>&1
    fi

    # ── Console: hash check only when DAT cache is present ───────────────────
    # Without DATs every console ROM would return "unchecked" — skip the walk
    # entirely to avoid spending minutes hashing files we can't verify.

    local CONSOLE_SYSTEMS="nes snes megadrive genesis gba gb gbc ngp ngpc mastersystem gamegear nds sega32x atari2600 pcengine"
    local _dat_entries
    _dat_entries=$(python3 -c "import json; print(len(json.load(open('$DAT_CACHE'))))" 2>/dev/null || echo 0)
    if [ -f "$DAT_CACHE" ] && [ "$_dat_entries" -gt 0 ]; then
        log "Scanning console ROMs against DAT cache ($_dat_entries entries)..."
        _scan_progress_write "console" "Scanning console ROMs..." 0 0
        for sys_name in $CONSOLE_SYSTEMS; do
            local sys_dir="$ROMS_BASE/$sys_name"
            [ -d "$sys_dir" ] || continue
            local system
            system=$(system_from_dir "$sys_name")
            local _sv=0 _st=0

            while IFS= read -r -d '' rom_path; do
                ((total++)); ((_st++))

                local result status
                result=$(check_rom_nointro "$rom_path")
                status=$(python3 -c \
                    "import json,sys; print(json.loads(sys.argv[1]).get('status','unknown'))" \
                    "$result" 2>/dev/null)

                case "$status" in
                    verified)
                        ((verified++)); ((_sv++))
                        log "✓ $(basename "$rom_path")"
                        ;;
                    mismatch)
                        ((mismatched++))
                        log "⚠ MISMATCH: $(basename "$rom_path")"
                        if $network_ok; then
                            local game_name
                            game_name=$(basename "$rom_path" | sed 's/\.[^.]*$//')
                            queue_canonical_download \
                                "$system" "$game_name" "$sys_dir" "$rom_path" \
                                2>&1 \
                                && ((queued++))
                        fi
                        ;;
                    unknown|unchecked)
                        ((unknown++))
                        ;;
                esac
            done < <(find "$sys_dir" -maxdepth 1 -type f \
                \( -name "*.zip" -o -name "*.7z" -o -name "*.bin" \
                   -o -name "*.nes" -o -name "*.sfc" \
                   -o -name "*.smc" -o -name "*.md"  -o -name "*.gen" \
                   -o -name "*.smd" -o -name "*.gba" \
                   -o -name "*.gb"  -o -name "*.gbc" \
                   -o -name "*.ngp" -o -name "*.ngc" \
                   -o -name "*.sms" -o -name "*.gg"  -o -name "*.nds" \
                   -o -name "*.32x" -o -name "*.pce" -o -name "*.a26" \) -print0 2>/dev/null)
            echo "$sys_name $_sv $_st" >> "$SYS_COUNTS_FILE"
        done
    else
        log "No DAT cache — console scan skipped (add .dat files to $NOINTRO_DATS_DIR to enable)"
    fi

    # ── Priority console titles: download missing canonical titles ──────────────
    # Uses CONSOLE_PRIORITY list (populated from *_TITLES arrays at startup).
    # Each title is checked on disk by exact No-Intro filename. Missing titles
    # are grouped by system, then each system's No-Intro zip is downloaded from
    # IA and only the missing ROMs are extracted. No searching, no gamelist.xml
    # scanning, no fuzzy matching.
    if $network_ok; then
        log "Checking priority console titles..."

        # Phase 1: detect missing titles per system (Python for speed)
        local _priority_list
        _priority_list=$(python3 - "$ROMS_BASE" \
            "${CONSOLE_PRIORITY[@]}" <<'PYEOF'
import os, re, sys

roms_base = sys.argv[1]
curated = [e.split("|", 1) for e in sys.argv[2:]]

def norm_title(s):
    s = re.sub(r'\.\w{1,5}$', '', s)
    return re.sub(r'\s+', ' ', s.strip().lower())

def norm_bare(s):
    s = re.sub(r'\.\w{1,5}$', '', s)
    s = re.sub(r'\s*\([^)]*\)', '', s)
    s = re.sub(r'\s*\[[^\]]*\]', '', s)
    return re.sub(r'\s+', ' ', s.strip().lower())

def file_present(sys_dir, title):
    target = norm_title(title)
    target_bare = norm_bare(title)
    if not target:
        return True, None
    non_canonical = None
    try:
        for fn in os.listdir(sys_dir):
            if norm_title(fn) == target:
                return True, None
            if non_canonical is None and norm_bare(fn) == target_bare:
                fpath = os.path.join(sys_dir, fn)
                if os.path.isfile(fpath):
                    non_canonical = fpath
    except Exception:
        pass
    return False, non_canonical

seen = set()
for sys_name, title in curated:
    key = f"{sys_name}|{title}"
    if key in seen:
        continue
    seen.add(key)
    sys_dir = os.path.join(roms_base, sys_name)
    if not os.path.isdir(sys_dir):
        continue
    found, replace_path = file_present(sys_dir, title)
    if not found:
        rp = replace_path or ""
        print(f"{sys_name}|{title}|{rp}")
PYEOF
)
        # Phase 2: download missing ROMs — per-ROM direct or bulk extraction
        if [ -n "$_priority_list" ]; then
            # Collect missing titles per system into temp files
            local _tmp_dir
            _tmp_dir=$(mktemp -d /tmp/outbreak_console_dl.XXXXXX)
            while IFS='|' read -r _psys _ptitle _preplace; do
                [ -z "$_psys" ] && continue
                echo "${_ptitle}|${_preplace}" >> "$_tmp_dir/$_psys.list"
                ((queued++))
            done <<< "$_priority_list"

            # ── Fuzzy filename resolver ──────────────────────────────────
            # IA filenames often differ from our *_TITLES keys by extra region
            # tags, language suffixes, or tilde aliases.  This Python helper
            # takes a list of wanted titles and a list of available filenames
            # and returns the best match for each title, keyed by wanted name.
            #
            # Match strategy (first match wins):
            #   1. Exact match (title + ext)
            #   2. Prefix match — strip everything after first '(' in both
            #      names and compare the base game name.  Among multiple
            #      prefix matches, prefer (USA) > (World) > (Europe) > other.
            _ia_resolve_filenames() {
                # $1 = file with wanted titles (one per line, first field before |)
                # $2 = file with available filenames (one per line)
                # $3 = extension filter (e.g. .7z, .zip, or empty for any)
                # stdout: wanted_title<TAB>matched_filename  (one per line)
                python3 - "$1" "$2" "$3" <<'PYEOF'
import sys, os, re

wanted_file, avail_file, ext_filter = sys.argv[1], sys.argv[2], sys.argv[3]

# Read wanted titles (first field before |)
wanted = []
for line in open(wanted_file):
    line = line.strip()
    if not line:
        continue
    title = line.split('|')[0]
    wanted.append(title)

# Read available filenames
available = []
for line in open(avail_file):
    fn = line.strip()
    if not fn:
        continue
    if ext_filter and not fn.lower().endswith(ext_filter.lower()):
        continue
    available.append(fn)

def base_name(s):
    """Strip extension, then get the game name before the first '('."""
    # Remove extension
    for ext in ('.7z', '.zip', '.nes', '.sfc', '.smc', '.md', '.gen',
                '.gba', '.gb', '.gbc', '.pce', '.sms', '.gg', '.a26',
                '.nds', '.32x'):
        if s.lower().endswith(ext):
            s = s[:-len(ext)]
            break
    # Get text before first '(' and normalize
    idx = s.find('(')
    if idx > 0:
        s = s[:idx]
    s = s.strip().lower()
    # Normalize "Legend of Zelda, The -" → "the legend of zelda -"
    # No-Intro moves articles (The, A, An) to end with comma
    s = re.sub(r'^(.+?),\s*(the|a|an)\b', r'\2 \1', s)
    return s

def region_score(fn):
    """Prefer USA > World > Europe > Japan > other."""
    fn_lower = fn.lower()
    score = 0
    if '(usa' in fn_lower:
        score += 100
    if '(world)' in fn_lower:
        score += 50
    if '(europe' in fn_lower:
        score += 25
    if '(japan' in fn_lower:
        score += 10
    # Prefer shorter names (fewer extra tags)
    score -= len(fn) * 0.01
    return score

# Build lookup: base_name -> list of available filenames
from collections import defaultdict
base_to_files = defaultdict(list)
for fn in available:
    bn = base_name(fn)
    base_to_files[bn].append(fn)

# Also handle tilde aliases: "Combat ~ Tank-Plus (USA).7z"
# The part before ~ is also a valid base name
for fn in available:
    if '~' in fn:
        # "Combat ~ Tank-Plus (USA).7z" -> base "combat"
        tilde_base = fn.split('~')[0].strip().lower()
        base_to_files[tilde_base].append(fn)

# Exact filename lookup (with extension)
exact_set = set(available)

for title in wanted:
    # Try exact match first (title + common extensions)
    matched = None
    for ext in ('.7z', '.zip', '.nes', '.sfc', '.smc', '.md', '.gen',
                '.gba', '.gb', '.gbc', '.pce', '.sms', '.gg', '.a26',
                '.nds', '.32x'):
        if (title + ext) in exact_set:
            matched = title + ext
            break

    if not matched:
        # Fuzzy: match by base name prefix
        want_base = base_name(title)
        candidates = base_to_files.get(want_base, [])
        if candidates:
            # Pick best by region preference
            candidates.sort(key=region_score, reverse=True)
            matched = candidates[0]

    if matched:
        print(f"{title}\t{matched}")
PYEOF
            }

            # Process each system that has missing titles
            for _sys_list in "$_tmp_dir"/*.list; do
                [ -f "$_sys_list" ] || continue
                local _sys
                _sys=$(basename "$_sys_list" .list)
                local _missing_count
                _missing_count=$(wc -l < "$_sys_list")
                local _dest_dir="$ROMS_BASE/$_sys"
                mkdir -p "$_dest_dir"

                # Check disk space (500MB minimum headroom)
                local _free_mb
                _free_mb=$(df -m /userdata | awk 'NR==2{print $4}')
                if [ "${_free_mb:-0}" -lt 500 ]; then
                    log "Disk space low (${_free_mb}MB free) — skipping $_sys"
                    continue
                fi

                local _per_rom_item="${IA_CONSOLE_PER_ROM[$_sys]:-}"
                local _bulk_archive="${IA_CONSOLE_BULK[$_sys]:-}"

                if [ -n "$_per_rom_item" ]; then
                    # ── Tier 1: Per-ROM direct download ──────────────────────
                    # Fetch IA file listing once per system, fuzzy-match titles
                    local _ext="${IA_CONSOLE_PER_ROM_EXT[$_sys]:-.7z}"
                    log "Console sync: $_sys — $_missing_count missing (per-ROM from $_per_rom_item)"

                    # Fetch IA metadata to get actual filenames
                    local _ia_files="$_tmp_dir/${_sys}_ia_files.txt"
                    if ! curl -sf --timeout 30 \
                        "https://archive.org/metadata/${_per_rom_item}/files" \
                        2>/dev/null | python3 -c "
import sys, json
try:
    data = json.load(sys.stdin)
    for f in data.get('result', []):
        name = f.get('name', '')
        if name:
            print(name)
except: pass
" > "$_ia_files" 2>/dev/null; then
                        log "Could not fetch IA file listing for $_per_rom_item — skipping"
                        continue
                    fi
                    local _ia_file_count
                    _ia_file_count=$(wc -l < "$_ia_files")
                    log "IA listing: $_ia_file_count files in $_per_rom_item"

                    # Resolve wanted titles to actual IA filenames
                    local _resolved="$_tmp_dir/${_sys}_resolved.txt"
                    _ia_resolve_filenames "$_sys_list" "$_ia_files" "$_ext" > "$_resolved"

                    local _dl_ok=0
                    while IFS='|' read -r _title _replace; do
                        # Look up the resolved IA filename for this title
                        local _ia_filename
                        _ia_filename=$(awk -F'\t' -v t="$_title" '$1==t{print $2; exit}' "$_resolved")

                        if [ -z "$_ia_filename" ]; then
                            log "No match on IA: $_title"
                            continue
                        fi

                        local _encoded
                        _encoded=$(python3 -c "import sys,urllib.parse; print(urllib.parse.quote(sys.stdin.read().strip()))" <<< "$_ia_filename")
                        local _url="https://archive.org/download/${_per_rom_item}/${_encoded}"
                        local _out_file="${_dest_dir}/${_ia_filename}"
                        local _tmp_file="${_out_file}.dl_tmp"

                        if wget -q --timeout=30 --tries=2 -O "$_tmp_file" "$_url" 2>/dev/null; then
                            local _sz
                            _sz=$(stat -c%s "$_tmp_file" 2>/dev/null || echo 0)
                            if [ "$_sz" -gt 1000 ]; then
                                mv "$_tmp_file" "$_out_file"
                                [ "$_ia_filename" != "${_title}${_ext}" ] && \
                                    log "OK: $_title → $_ia_filename (${_sz} bytes)" || \
                                    log "OK: ${_ia_filename} (${_sz} bytes)"
                                # Quarantine old non-canonical version
                                if [ -n "$_replace" ] && [ -f "$_replace" ]; then
                                    mkdir -p /userdata/roms/quarantine
                                    mv "$_replace" /userdata/roms/quarantine/ 2>/dev/null && \
                                        log "Quarantined: $(basename "$_replace")"
                                fi
                                ((_dl_ok++))
                            else
                                rm -f "$_tmp_file"
                                log "Too small: $_ia_filename (${_sz} bytes) — skipped"
                            fi
                        else
                            rm -f "$_tmp_file"
                            log "Download failed: $_ia_filename"
                        fi
                    done < "$_sys_list"
                    log "Console sync: $_sys — downloaded $_dl_ok/$_missing_count ROM(s)"

                elif [ -n "$_bulk_archive" ]; then
                    # ── Tier 2: Bulk archive download + selective extraction ─
                    log "Console sync: $_sys — $_missing_count missing (bulk from $_bulk_archive)"
                    local _encoded_archive
                    _encoded_archive=$(python3 -c "import sys,urllib.parse; print(urllib.parse.quote(sys.stdin.read().strip()))" <<< "$_bulk_archive")
                    local _archive_url="https://archive.org/download/${IA_CONSOLE_BULK_ITEM}/${_encoded_archive}"
                    local _cache_dir="/userdata/system/netplay-arcade/cache"
                    local _archive_path="${_cache_dir}/${_bulk_archive}"
                    mkdir -p "$_cache_dir"

                    if [ ! -f "$_archive_path" ]; then
                        log "Downloading: $_bulk_archive"
                        _es_notify "Downloading $_sys ROM set..."
                        if ! wget -q --timeout=900 --tries=2 -O "${_archive_path}.dl_tmp" "$_archive_url"; then
                            log "Download failed: $_bulk_archive"
                            rm -f "${_archive_path}.dl_tmp"
                            continue
                        fi
                        mv "${_archive_path}.dl_tmp" "$_archive_path"
                        log "Downloaded: $_bulk_archive ($(du -h "$_archive_path" | cut -f1))"
                    else
                        log "Using cached: $_bulk_archive"
                    fi

                    # List archive contents and fuzzy-match against wanted titles
                    local _archive_contents="$_tmp_dir/${_sys}_archive_contents.txt"
                    7z l -slt "$_archive_path" 2>/dev/null | grep '^Path = ' | sed 's/^Path = //' > "$_archive_contents"
                    local _resolved="$_tmp_dir/${_sys}_bulk_resolved.txt"
                    _ia_resolve_filenames "$_sys_list" "$_archive_contents" "" > "$_resolved"

                    local _extracted=0
                    while IFS='|' read -r _title _replace; do
                        local _inner
                        _inner=$(awk -F'\t' -v t="$_title" '$1==t{print $2; exit}' "$_resolved")

                        if [ -z "$_inner" ]; then
                            log "Not found in archive: $_title ($_sys)"
                            continue
                        fi

                        if 7z e -y -o"$_dest_dir" "$_archive_path" "$_inner" &>/dev/null; then
                            [ "$_inner" != "$_title"* ] && \
                                log "Extracted: $_title → $_inner" || \
                                log "Extracted: $_inner"
                            if [ -n "$_replace" ] && [ -f "$_replace" ]; then
                                mkdir -p /userdata/roms/quarantine
                                mv "$_replace" /userdata/roms/quarantine/ 2>/dev/null && \
                                    log "Quarantined: $(basename "$_replace")"
                            fi
                            ((_extracted++))
                        else
                            log "Extract failed: $_inner ($_sys)"
                        fi
                    done < "$_sys_list"
                    log "Console sync: $_sys — extracted $_extracted/$_missing_count ROM(s)"

                    # Clean up the archive to save disk space
                    rm -f "$_archive_path"
                    log "Cleaned up: $_bulk_archive"
                else
                    log "No IA source configured for $_sys — skipping"
                fi
            done
            rm -rf "$_tmp_dir"
        fi
    fi

    log "=== Scan: $verified verified | $mismatched mismatch | $unknown unknown | $total total ==="
    if [ "$queued" -gt 0 ]; then
        log "$queued replacement(s) queued"
        _es_notify "Updating game library..."
    fi

    # Write summary for UI / server
    python3 - "$total" "$verified" "$mismatched" "$unknown" "$queued" \
              "$DOWNLOAD_QUEUE" "$SYS_COUNTS_FILE" <<'PYEOF' > /tmp/rom_scan_summary.json
import json, sys, time, os
total, verified, mismatched, unknown, queued, queue_file, sys_counts_file = sys.argv[1:]
s = {
    "total": int(total), "verified": int(verified),
    "mismatched": int(mismatched), "unknown": int(unknown),
    "queued": int(queued), "timestamp": int(time.time()),
}
try:
    q = json.load(open(queue_file))
    s["downloading"] = len([x for x in q if x.get("status") == "queued"])
except Exception:
    s["downloading"] = 0
try:
    st = os.statvfs("/userdata")
    s["disk_free_mb"]  = (st.f_bavail * st.f_frsize) // (1024 * 1024)
    s["disk_total_mb"] = (st.f_blocks * st.f_frsize) // (1024 * 1024)
except Exception:
    pass
systems = {}
try:
    for line in open(sys_counts_file):
        parts = line.strip().split()
        if len(parts) == 3:
            systems[parts[0]] = {"verified": int(parts[1]), "total": int(parts[2])}
except Exception:
    pass
if systems:
    s["systems"] = systems
print(json.dumps(s, indent=2))
PYEOF

    # Write persistent ROM index — consumed by rom_finder.py on smart-join
    python3 - "$ROM_INDEX_TMP" "$ROM_INDEX_FILE" <<'PYEOF'
import json, sys, time, tempfile, os
tmp_file, out_file = sys.argv[1], sys.argv[2]
entries = {}
try:
    for line in open(tmp_file):
        parts = line.strip().split("|")
        if len(parts) == 4:
            stem, path, system, core = parts
            entries[stem] = {"path": path, "system": system, "core": core}
except Exception:
    pass
data = {"generated": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "roms": entries}
fd, tmp = tempfile.mkstemp(dir=os.path.dirname(out_file) or "/tmp", suffix=".tmp")
try:
    with os.fdopen(fd, "w") as fh:
        json.dump(data, fh)
    os.replace(tmp, out_file)
    print(f"[ROM] Index: {len(entries)} ROMs written to {out_file}")
except Exception as e:
    try: os.unlink(tmp)
    except OSError: pass
    print(f"[ROM] Index write failed: {e}")
PYEOF
    rm -f "$ROM_INDEX_TMP"

    # Downloads are processed by the server's background download worker thread,
    # not here — avoids blocking boot and allows session-aware scheduling.
    [ "$queued" -gt 0 ] && log "$queued ROM(s) queued for background download"

    rm -f /tmp/rom_scan_progress.json
    log "=== Boot scan done ==="

    # ── Generate "Outbreak Host" collection ──────────────────────────────────
    _generate_netplay_collection "$ROMS_BASE"

    # Media scraping is handled by the download worker thread in netplay-server.py
    # via _run_scraper_if_needed() — boot scan only scans and queues.
}

# ─── SCAN SINGLE ROM ─────────────────────────────────────────────────────────
scan_rom() {
    local rom_path="$1"
    log "Scanning: $rom_path"
    local nointro_result
    nointro_result=$(check_rom_nointro "$rom_path")
    local rgsx_result='{"status":"skipped"}'
    if [ -n "$RGSX_API_KEY" ]; then
        local hash ra_response
        hash=$(get_rom_hash "$rom_path")
        [ -n "$hash" ] && ra_response=$(
            curl -s --max-time 10 \
            "${RGSX_API}/API_GetGameInfoAndUserProgress?z=${RA_USERNAME}&y=${RGSX_API_KEY}&m=${hash}" \
            2>/dev/null)
        if [ -n "$ra_response" ] && ! echo "$ra_response" | grep -q '"Error"'; then
            rgsx_result=$(python3 -c "
import json,sys
try:
    d=json.loads(sys.argv[1]); gid=d.get('ID',0)
    if gid>0: print(json.dumps({'status':'verified','canonical':True,'game_id':gid,'title':d.get('Title',''),'source':'retroachievements'}))
    else:      print(json.dumps({'status':'unrecognized','canonical':False}))
except Exception as e: print(json.dumps({'error':str(e),'status':'parse_error'}))
" "$ra_response")
        fi
    fi
    python3 -c "
import json,sys
ni=json.loads(sys.argv[1]); rx=json.loads(sys.argv[2])
print(json.dumps({'nointro':ni,'rgsx':rx,'canonical':ni.get('canonical') or rx.get('canonical'),'status':ni.get('status','unknown')},indent=2))
" "$nointro_result" "$rgsx_result"
}

# ─── MAIN DISPATCH ────────────────────────────────────────────────────────────
[[ "${BASH_SOURCE[0]}" != "${0}" ]] && return 0  # sourced - skip dispatch
case "$1" in
    boot)       [ -n "${2:-}" ] && ROMS_BASE="$2"; boot_scan ;;
    scan)       scan_rom "$2" ;;
    sync-arcade) sync_arcade_romset ;;
    sync-samples) sync_audio_samples ;;
    download)   queue_canonical_download "$2" "$3" "$ROMS_BASE/$2" "" ;;
    queue)      process_download_queue ;;
    scrape)     _background_media_scrape ;;
    hash)     get_rom_hash "$2" ;;
    fix)
        # Targeted repair for specific ROM paths (used by /api/fix-games).
        # Checks each ROM against the No-Intro DAT; queues a canonical
        # replacement download for any that don't verify. Then drains the queue.
        shift
        for _rom_path in "$@"; do
            [ -f "$_rom_path" ] || continue
            _fix_system=$(basename "$(dirname "$_rom_path")")
            _fix_game=$(basename "$_rom_path" | sed 's/\.[^.]*$//')
            _fix_result=$(check_rom_nointro "$_rom_path")
            _fix_canonical=$(echo "$_fix_result" | \
                python3 -c "import json,sys; print(str(json.load(sys.stdin).get('canonical',True)).lower())" 2>/dev/null || echo "true")
            if [ "$_fix_canonical" != "true" ]; then
                log "fix: queuing canonical download for $_fix_game ($_fix_system)"
                queue_canonical_download "$_fix_system" "$_fix_game" "$(dirname "$_rom_path")" "$_rom_path"
            else
                log "fix: $_fix_game already verified — skipping"
            fi
        done
        log "fix: queued — download worker will process"
        ;;
    *)
        echo "Usage: $0 {boot [roms-base]|scan <rom>|download <s> <game>|queue|hash <rom>|fix <rom>...}"
        exit 1 ;;
esac
