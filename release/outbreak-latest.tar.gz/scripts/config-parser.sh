#!/bin/bash

set_netplay_config_defaults() {
    USERNAME="${USERNAME:-$(hostname)}"
    MAX_PING="${MAX_PING:-40}"
    DISCORD_WEBHOOK="${DISCORD_WEBHOOK:-}"
    RA_USERNAME="${RA_USERNAME:-}"
    RGSX_API_KEY="${RGSX_API_KEY:-}"
    RETROARCH_BIN="${RETROARCH_BIN:-/usr/bin/retroarch}"
    WAN_ENABLED="${WAN_ENABLED:-false}"
    AUTO_UPDATE="${AUTO_UPDATE:-true}"
    ROLLBACK_MAX_PING="${ROLLBACK_MAX_PING:-60}"
    SCANLINES="${SCANLINES:-false}"
    GH_TOKEN="${GH_TOKEN:-}"
}

trim_config_whitespace() {
    local value="$1"
    value="${value#"${value%%[![:space:]]*}"}"
    value="${value%"${value##*[![:space:]]}"}"
    printf '%s' "$value"
}

strip_outer_quotes() {
    local value="$1"
    local length="${#value}"
    local first_char last_char

    if [ "$length" -lt 2 ]; then
        printf '%s' "$value"
        return
    fi

    first_char="${value:0:1}"
    last_char="${value:$((length - 1)):1}"
    if { [ "$first_char" = '"' ] && [ "$last_char" = '"' ]; } || \
       { [ "$first_char" = "'" ] && [ "$last_char" = "'" ]; }; then
        value="${value:1:$((length - 2))}"
    fi
    printf '%s' "$value"
}

load_netplay_config() {
    local config_file="${1:-/userdata/system/netplay-arcade/config.cfg}"
    local raw_line line key value

    set_netplay_config_defaults
    [ -f "$config_file" ] || return 0

    while IFS= read -r raw_line || [ -n "$raw_line" ]; do
        line="$(trim_config_whitespace "$raw_line")"
        [ -z "$line" ] && continue
        case "$line" in
            \#*) continue ;;
        esac
        case "$line" in
            *=*)
                key="${line%%=*}"
                value="${line#*=}"
                key="$(trim_config_whitespace "$key")"
                value="$(trim_config_whitespace "$value")"
                value="$(strip_outer_quotes "$value")"
                key="$(printf '%s' "$key" | tr '[:upper:]' '[:lower:]')"
                case "$key" in
                    username)        USERNAME="$value" ;;
                    max_ping)        MAX_PING="$value" ;;
                    discord_webhook) DISCORD_WEBHOOK="$value" ;;
                    ra_username)     RA_USERNAME="$value" ;;
                    rgsx_api_key)    RGSX_API_KEY="$value" ;;
                    retroarch_bin)   RETROARCH_BIN="$value" ;;
                    wan_enabled)       WAN_ENABLED="$value" ;;
                    auto_update)       AUTO_UPDATE="$value" ;;
                    rollback_max_ping) ROLLBACK_MAX_PING="$value" ;;
                    scanlines)         SCANLINES="$value" ;;
                    gh_token)          GH_TOKEN="$value" ;;
                esac
                ;;
        esac
    done < "$config_file"
}
