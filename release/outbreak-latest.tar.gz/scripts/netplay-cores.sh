#!/bin/bash
# =============================================================================
# Batocera NetPlay - Stable Core Channel  (v1.0)
#
# CONCEPT
# -------
# Every libretro core in /usr/lib/libretro/ is rebuilt on every Batocera
# release and may silently change save-state layout or RNG behavior between
# versions, breaking netplay sync even when both players use the "same" core
# by name.
#
# This module maintains a second set of cores — the "netplay channel" — whose
# versions are pinned and verified by content-hash.  When netplay is active,
# RetroArch is launched with -L pointing at the pinned .so rather than the
# system one.  Both players must use the same channel entry; the /session API
# advertises the channel ID + hash so the joiner can verify before connecting.
#
# DIRECTORY LAYOUT
# ----------------
# /userdata/system/netplay-arcade/cores/
#   manifest.json          ← authoritative version + hash database
#   snes9x_libretro.so     ← pinned copy (may be same bytes as system copy)
#   fceumm_libretro.so
#   genesisplusgx_libretro.so
#   ...
#
# MANIFEST SCHEMA  (manifest.json)
# ----------------------------------
# {
#   "channel": "stable-1",            ← bump when any core is updated
#   "updated": "2025-03-07",
#   "cores": {
#     "snes9x": {
#       "display_version": "1.61",
#       "corename":        "Snes9x",
#       "md5":             "abc123...",  ← md5 of the pinned .so
#       "source":          "system",     ← "system" | "custom"
#       "so_path":         "/userdata/system/netplay-arcade/cores/snes9x_libretro.so",
#       "info_version":    "1.61",       ← from .info file
#       "pinned_at":       "2025-03-07"
#     },
#     ...
#   }
# }
#
# SOURCE VALUES
#   "system"  → we copied the current system .so into the channel at install
#               time; it will stay frozen until the admin runs `update-channel`
#   "custom"  → a manually placed .so; never overwritten automatically
#
# WORKFLOW
# --------
#   1. Install:         netplay-cores.sh init
#      Copies every system core listed in NETPLAY_CORES into the channel dir,
#      reads display_version from the matching .info file, hashes the .so,
#      writes manifest.json.
#
#   2. Broadcast:       netplay-cores.sh resolve <core_name>
#      Returns the full path to the pinned .so (or falls back to system path
#      if the core isn't in the channel).  broadcast_session uses this.
#
#   3. Version check:   netplay-cores.sh verify <core_name> <expected_md5>
#      Returns JSON {match, local_md5, expected_md5, channel}.
#      join_session calls this BEFORE launching RA.
#
#   4. Status:          netplay-cores.sh status
#      Prints JSON array with every managed core, its version, hash, and
#      whether it matches the system copy.
#
#   5. Admin update:    netplay-cores.sh update-channel [core_name]
#      Re-copies from system and re-hashes.  Useful after a Batocera upgrade
#      when the admin has decided the new core version is netplay-safe.
#      Without core_name, updates ALL cores.
#
# =============================================================================

CHANNEL_DIR="/userdata/system/netplay-arcade/cores"
MANIFEST="$CHANNEL_DIR/manifest.json"
SYSTEM_CORES="/usr/lib/libretro"
INFO_DIR="/usr/share/libretro/info"
LOG_FILE="/tmp/netplay-arcade.log"
DOWNLOAD_LOCK="/tmp/outbreak_download.lock"

# Cores managed by the netplay channel — ordered by priority
NETPLAY_CORES=(
    fceumm
    nestopia
    mesen
    snes9x
    snes9x_next
    genesisplusgx
    picodrive
    mgba
    gpsp
    gambatte
    fbneo
    mame078plus
    mednafen_ngp
    mednafen_supergrafx
    flycast
    stella
)

# ─── CANONICAL CORE DOWNLOAD CONFIG ──────────────────────────────────────────
# Cores are hosted as GitHub Release assets on the Outbreak repo itself.
# Every machine on the same Outbreak version downloads the same release tag →
# byte-identical binaries → matching md5 regardless of Batocera version.
#
# To update: upload new .so.zip files to the release tag and bump CHANNEL_ID.
CORE_RELEASE_TAG="core-channel-x86_64"
REPO="paulrenzi/ob-dist"

# Map: Batocera core name → release asset filename stem (used in .so.zip asset names).
declare -A ASSET_NAMES
ASSET_NAMES=(
    [fceumm]="fceumm"
    [nestopia]="nestopia"
    [mesen]="mesen"
    [snes9x]="snes9x"
    [snes9x_next]="snes9x2010"
    [genesisplusgx]="genesis_plus_gx"
    [picodrive]="picodrive"
    [mgba]="mgba"
    [gpsp]="gpsp"
    [gambatte]="gambatte"
    [fbneo]="fbneo"
    [mame078plus]="mame2003_plus"
    [mednafen_ngp]="mednafen_ngp"
    [mednafen_supergrafx]="mednafen_supergrafx"
    [flycast]="flycast"
    [stella]="stella"
)
CHANNEL_ID="outbreak-${CORE_RELEASE_TAG}"

log() { echo "[$(date '+%H:%M:%S')] CORES: $1" | tee -a "$LOG_FILE"; }

# ─── UTILITY: hash a .so ──────────────────────────────────────────────────────
so_md5() {
    local path="$1"
    [ -f "$path" ] && md5sum "$path" | cut -d' ' -f1 || echo ""
}

# ─── UTILITY: resolve .so path (channel dir first, then system) ───────────────
# Used when looking up the actual file on disk regardless of manifest
find_so() {
    local core="$1"
    local channel_so="$CHANNEL_DIR/${core}_libretro.so"
    local system_so="$SYSTEM_CORES/${core}_libretro.so"
    # Underscore-normalised system fallback for cores like mupen64plus-next
    # (Batocera stores mupen64plus_next_libretro.so; the internal name uses a hyphen)
    local system_so_us="$SYSTEM_CORES/${core//-/_}_libretro.so"
    if [ -f "$channel_so" ];   then echo "$channel_so";   return; fi
    if [ -f "$system_so" ];    then echo "$system_so";    return; fi
    if [ -f "$system_so_us" ]; then echo "$system_so_us"; return; fi
    echo ""
}

# ─── UTILITY: resolve .info file path ────────────────────────────────────────
# Some cores have different upstream libretro names vs Batocera internal names;
# the .info file on disk uses the upstream name.
_info_file_for() {
    local core="$1"
    local primary="$INFO_DIR/${core}_libretro.info"
    [ -f "$primary" ] && { echo "$primary"; return; }
    # Upstream alias fallbacks
    case "$core" in
        snes9x_next)   echo "$INFO_DIR/snes9x2010_libretro.info"    ;;
        mame078plus)   echo "$INFO_DIR/mame2003_plus_libretro.info" ;;
        genesisplusgx) echo "$INFO_DIR/genesis_plus_gx_libretro.info" ;;
        *)             echo "$primary" ;;
    esac
}

# ─── UTILITY: read display_version from .info file ───────────────────────────
read_info_version() {
    local core="$1"
    local info_file
    info_file=$(_info_file_for "$core")
    [ ! -f "$info_file" ] && { echo ""; return; }
    grep '^display_version' "$info_file" 2>/dev/null \
        | head -1 | sed 's/.*= *"\(.*\)"/\1/' | tr -d '"'
}

# ─── UTILITY: read corename from .info file ───────────────────────────────────
read_corename() {
    local core="$1"
    local info_file
    info_file=$(_info_file_for "$core")
    [ ! -f "$info_file" ] && { echo "$core"; return; }
    grep '^corename' "$info_file" 2>/dev/null \
        | head -1 | sed 's/.*= *"\(.*\)"/\1/' | tr -d '"'
}

# ─── INIT: build channel — download pinned cores, fall back to system copy ────
init_channel() {
    log "Initialising netplay core channel ($CHANNEL_ID)..."
    mkdir -p "$CHANNEL_DIR"

    # ── Step 1: Download canonical cores from GitHub Release ─────────────────
    # Everyone on the same Outbreak version gets the same release tag → same
    # binaries → matching md5 regardless of Batocera version.
    local _raw_arch _arch_tag
    _raw_arch=$(uname -m 2>/dev/null || echo "x86_64")
    case "$_raw_arch" in
        x86_64)             _arch_tag="x86_64" ;;
        aarch64|arm64)      _arch_tag="arm64"  ;;
        armv7l|armhf|arm*)  _arch_tag="armhf"  ;;
        *)                  _arch_tag=""        ;;
    esac

    local _downloaded_cores=""   # space-separated list passed to Python step
    local _dl_ok=0 _dl_fail=0

    # Write zip-extraction helper (avoids nesting heredocs)
    local _extract_py="/tmp/outbreak_unzip.py"
    cat > "$_extract_py" <<'UNZIPEOF'
import zipfile, sys, shutil, os
tmp_zip, dst = sys.argv[1:]
try:
    with zipfile.ZipFile(tmp_zip) as z:
        members = z.namelist()
        # Prefer *_libretro.so to avoid picking up incidental helper libs
        so = next((m for m in members if m.endswith('_libretro.so')), None)
        if so is None:
            so = next((m for m in members if m.endswith('.so')), None)
        if so:
            tmp_dir = '/tmp/outbreak_extract'
            os.makedirs(tmp_dir, exist_ok=True)
            z.extract(so, tmp_dir)
            shutil.move(os.path.join(tmp_dir, so), dst)
            print('ok')
        else:
            print('no-so')
except Exception as e:
    print(f'err:{e}')
UNZIPEOF

    local _scripts_dir
    _scripts_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    if [ -n "$_arch_tag" ] && command -v curl &>/dev/null; then
        log "Downloading canonical cores from GitHub release ($CORE_RELEASE_TAG)..."
        # Acquire global download lock — prevents ROM downloads from running
        # concurrently, which can saturate WiFi and crash the connection.
        exec 9>"$DOWNLOAD_LOCK"
        flock -x 9
        log "Download lock acquired (cores)"

        # Fetch release metadata once — maps asset names to download URLs.
        local _release_json="/tmp/outbreak_release_meta.json"
        if curl -fsS --max-time 30 \
               "https://api.github.com/repos/$REPO/releases/tags/$CORE_RELEASE_TAG" \
               -o "$_release_json" 2>/dev/null; then

            for _core in "${NETPLAY_CORES[@]}"; do
                local _bname="${ASSET_NAMES[$_core]:-}"
                if [ -z "$_bname" ]; then
                    log "  [SKIP] $_core: no asset mapping — will use system copy"
                    (( _dl_fail++ )) || true
                    continue
                fi
                local _asset_name="${_bname}_libretro.so.zip"
                local _dst="$CHANNEL_DIR/${_core}_libretro.so"
                local _tmp="/tmp/outbreak_dl_${_bname}.zip"

                # Look up this asset's API URL from the release metadata
                local _asset_api_url
                _asset_api_url=$(python3 -c "
import json, sys
with open('$_release_json') as f:
    r = json.load(f)
for a in r.get('assets', []):
    if a['name'] == '$_asset_name':
        print(a['url'])
        break
" 2>/dev/null)

                if [ -z "$_asset_api_url" ]; then
                    log "  [SKIP] $_core: asset '$_asset_name' not in release — will use system copy"
                    (( _dl_fail++ )) || true
                    continue
                fi

                if curl -fsSL --max-time 120 --connect-timeout 15 \
                       -H "Accept: application/octet-stream" \
                       -o "$_tmp" "$_asset_api_url" 2>/dev/null; then
                    local _result
                    _result=$(python3 "$_extract_py" "$_tmp" "$_dst" 2>/dev/null)
                    rm -f "$_tmp"
                    rm -rf "/tmp/outbreak_extract"
                    if [ "$_result" = "ok" ]; then
                        log "  [OK]   $_core ← GitHub release $CORE_RELEASE_TAG"
                        _downloaded_cores="${_downloaded_cores} ${_core}"
                        (( _dl_ok++ )) || true
                    else
                        log "  [SKIP] $_core: extract failed ($_result) — will use system copy"
                        (( _dl_fail++ )) || true
                    fi
                else
                    rm -f "$_tmp"
                    log "  [SKIP] $_core: download failed — will use system copy"
                    (( _dl_fail++ )) || true
                fi
            done
            rm -f "$_release_json"
        else
            log "  [ERROR] Could not fetch release metadata for $CORE_RELEASE_TAG — all cores will use system copy"
            rm -f "$_release_json"
        fi

        log "Download complete: $_dl_ok canonical, $_dl_fail from system copy"
        # Release global download lock
        flock -u 9
        exec 9>&-
        log "Download lock released (cores)"
    else
        log "Skipping core download (arch=$_raw_arch unsupported or no curl)"
    fi

    rm -f "$_extract_py"

    # ── Step 2: Fill any gaps with system copies, write manifest ─────────────
    python3 - "$CHANNEL_DIR" "$MANIFEST" "$SYSTEM_CORES" "$INFO_DIR" \
              "$CHANNEL_ID" "$_downloaded_cores" "${NETPLAY_CORES[@]}" <<'PYEOF'
import json, os, sys, hashlib, shutil, datetime

channel_dir, manifest_path, sys_cores, info_dir, channel_id, downloaded_str, *cores = sys.argv[1:]
downloaded = set(downloaded_str.split())

# Cores where the .info filename uses the upstream libretro name, not the
# Batocera internal package name.
INFO_ALIASES = {
    "snes9x_next":   "snes9x2010",
    "mame078plus":   "mame2003_plus",
    "genesisplusgx": "genesis_plus_gx",
}

def md5_file(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()

def find_sys_so(core, sys_cores):
    """Return the system .so path, trying both the raw name and underscore-normalised variant."""
    p = os.path.join(sys_cores, f"{core}_libretro.so")
    if os.path.exists(p):
        return p
    # mupen64plus-next → mupen64plus_next (Batocera filesystem convention)
    p2 = os.path.join(sys_cores, f"{core.replace('-', '_')}_libretro.so")
    return p2 if os.path.exists(p2) else ""

def read_info_field(core, field, info_dir):
    for name in [core, INFO_ALIASES.get(core, "")]:
        if not name:
            continue
        p = os.path.join(info_dir, f"{name}_libretro.info")
        if not os.path.exists(p):
            continue
        with open(p) as f:
            for line in f:
                if line.strip().startswith(field):
                    parts = line.split("=", 1)
                    if len(parts) == 2:
                        return parts[1].strip().strip('"')
    return ""

today = datetime.date.today().isoformat()
manifest = {
    "channel":  channel_id,
    "updated":  today,
    "cores":    {}
}

added = 0
skipped = 0

existing = {}
if os.path.exists(manifest_path):
    try:
        with open(manifest_path) as mf:
            existing = json.load(mf).get("cores", {})
    except Exception:
        pass

for core in cores:
    dst_so = os.path.join(channel_dir, f"{core}_libretro.so")
    sys_so = find_sys_so(core, sys_cores)

    # Priority 1: downloaded from buildbot (already at dst_so)
    if core in downloaded and os.path.exists(dst_so):
        h            = md5_file(dst_so)
        info_ver     = read_info_field(core, "display_version", info_dir)
        corename_str = read_info_field(core, "corename", info_dir) or core
        manifest["cores"][core] = {
            "display_version": info_ver,
            "corename":        corename_str,
            "md5":             h,
            "source":          "canonical",
            "build_date":      channel_id,
            "so_path":         dst_so,
            "info_version":    info_ver,
            "pinned_at":       today,
        }
        print(f"  [PIN]  {core}: {info_ver or '(no version)'} [{h[:8]}…] ← GitHub release {channel_id}")
        added += 1
        continue

    # Priority 2: admin-placed custom entry — never overwrite
    if existing.get(core, {}).get("source") == "custom":
        print(f"  [KEEP] {core}: custom entry, not overwriting")
        h = md5_file(dst_so) if os.path.exists(dst_so) else ""
        manifest["cores"][core] = {**existing[core], "md5": h}
        added += 1
        continue

    # Priority 3: system copy fallback
    if not sys_so:
        print(f"  [SKIP] {core}: not found in {sys_cores}")
        skipped += 1
        continue

    # Bind mounts can make src and dst the same inode — skip copy if so
    try:
        if os.path.exists(dst_so) and os.path.samefile(sys_so, dst_so):
            pass  # already the same file (bind mount)
        else:
            shutil.copy2(sys_so, dst_so)
    except Exception:
        shutil.copy2(sys_so, dst_so)
    h            = md5_file(dst_so)
    info_ver     = read_info_field(core, "display_version", info_dir)
    corename_str = read_info_field(core, "corename", info_dir) or core
    manifest["cores"][core] = {
        "display_version": info_ver,
        "corename":        corename_str,
        "md5":             h,
        "source":          "system",
        "so_path":         dst_so,
        "info_version":    info_ver,
        "pinned_at":       today,
    }
    print(f"  [SYS]  {core}: {info_ver or '(no version)'} [{h[:8]}…] ← system copy (version varies by Batocera)")
    added += 1

tmp_path = manifest_path + ".tmp"
with open(tmp_path, "w") as mf:
    json.dump(manifest, mf, indent=2)
os.replace(tmp_path, manifest_path)

pinned = sum(1 for e in manifest["cores"].values() if e.get("source") == "canonical")
system = sum(1 for e in manifest["cores"].values() if e.get("source") == "system")
print(f"\nChannel '{channel_id}' ready: {pinned} from GitHub release, {system} from system copy, {skipped} skipped")
if system:
    print(f"  NOTE: {system} core(s) fell back to system copy — version will vary by Batocera release.")
    print(f"        Players on different Batocera versions may see a version-mismatch warning at join time.")
print(f"Manifest: {manifest_path}")
PYEOF
    log "Channel init complete"

    # Clear any pending drift warning — init just re-pinned everything
    local _bv_file="/usr/share/batocera/version"
    if [ -f "$_bv_file" ]; then
        tr -d '[:space:]' < "$_bv_file" > "$CHANNEL_DIR/.batocera_version"
        rm -f /tmp/outbreak_core_drift_warning
    fi
}

# ─── RESOLVE: return the path to use when launching RA ───────────────────────
# Prints the pinned .so path if it exists and is verified, else system path.
resolve_core_path() {
    local core="$1"

    # Strip _libretro suffix if passed with it
    core="${core%_libretro}"
    core="${core%.so}"

    local channel_so="$CHANNEL_DIR/${core}_libretro.so"
    local system_so="$SYSTEM_CORES/${core}_libretro.so"
    # Underscore-normalised system fallback (mupen64plus-next → mupen64plus_next)
    local system_so_us="$SYSTEM_CORES/${core//-/_}_libretro.so"

    if [ -f "$channel_so" ]; then
        echo "$channel_so"
    elif [ -f "$system_so" ]; then
        echo "$system_so"
    elif [ -f "$system_so_us" ]; then
        echo "$system_so_us"
    else
        echo ""
        return 1
    fi
}

# ─── GET VERSION INFO FOR A CORE ─────────────────────────────────────────────
# Returns JSON with version string + md5 suitable for embedding in /session
get_core_version() {
    local core="$1"
    core="${core%_libretro}"
    core="${core%.so}"

    python3 - "$core" "$MANIFEST" "$CHANNEL_DIR" "$INFO_DIR" "$SYSTEM_CORES" <<'PYEOF'
import json, os, sys, hashlib

core, manifest_path, channel_dir, info_dir, sys_cores = sys.argv[1:]

INFO_ALIASES = {
    "snes9x_next":   "snes9x2010",
    "mame078plus":   "mame2003_plus",
    "genesisplusgx": "genesis_plus_gx",
}

def md5_file(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()

def read_info_field(core, field):
    for name in [core, INFO_ALIASES.get(core, "")]:
        if not name:
            continue
        p = os.path.join(info_dir, f"{name}_libretro.info")
        if not os.path.exists(p):
            continue
        with open(p) as f:
            for line in f:
                if line.strip().startswith(field):
                    parts = line.split("=", 1)
                    if len(parts) == 2:
                        return parts[1].strip().strip('"')
    return ""

# Prefer channel copy
channel_so = os.path.join(channel_dir, f"{core}_libretro.so")
# Batocera uses underscores in filenames; some core names use hyphens (mupen64plus-next).
# Check both the literal name and the underscore-normalised variant for system fallback.
system_so  = os.path.join(sys_cores, f"{core}_libretro.so")
if not os.path.exists(system_so):
    system_so = os.path.join(sys_cores, f"{core.replace('-', '_')}_libretro.so")
active_so  = channel_so if os.path.exists(channel_so) else system_so
using_channel = os.path.exists(channel_so)

channel_id = "none"
pinned_ver = ""
pinned_md5 = ""

# Load manifest
if os.path.exists(manifest_path):
    try:
        manifest = json.load(open(manifest_path))
        channel_id = manifest.get("channel", "none")
        entry      = manifest.get("cores", {}).get(core, {})
        pinned_ver = entry.get("display_version", "")
        pinned_md5 = entry.get("md5", "")
    except Exception:
        pass

# Live hash of the file we'll actually use
live_md5 = md5_file(active_so) if os.path.exists(active_so) else ""

# Info version from system .info file
info_ver  = read_info_field(core, "display_version")
corename  = read_info_field(core, "corename") or core

result = {
    "core":          core,
    "corename":      corename,
    "channel":       channel_id,
    "using_channel": using_channel,
    "display_version": pinned_ver or info_ver or "",
    "info_version":    info_ver,
    "md5":             live_md5,
    "pinned_md5":      pinned_md5,
    "hash_ok":         (live_md5 == pinned_md5) if pinned_md5 else None,
    "so_path":         active_so if os.path.exists(active_so) else "",
}
print(json.dumps(result))
PYEOF
}

# ─── VERIFY: check that local core matches the expected md5 ──────────────────
# Returns JSON {match, local_md5, expected_md5, channel, core}
verify_core() {
    local core="$1"
    local expected_md5="$2"
    local expected_channel="${3:-}"

    core="${core%_libretro}"
    core="${core%.so}"

    local version_info
    version_info=$(get_core_version "$core")

    python3 - "$version_info" "$expected_md5" "$expected_channel" <<'PYEOF'
import json, sys

version_json, expected_md5, expected_channel = sys.argv[1:4]

try:
    info = json.loads(version_json)
except Exception:
    info = {}

local_md5     = info.get("md5", "")
local_channel = info.get("channel", "")

md5_match     = (local_md5 == expected_md5) if expected_md5 else None
channel_match = (local_channel == expected_channel) if expected_channel else None

# Both must match if both are provided; if only md5 provided, use that
if expected_md5 and expected_channel:
    overall_match = md5_match and channel_match
elif expected_md5:
    overall_match = md5_match
elif expected_channel:
    overall_match = channel_match
else:
    overall_match = None   # nothing to compare

print(json.dumps({
    "match":            overall_match,
    "md5_match":        md5_match,
    "channel_match":    channel_match,
    "local_md5":        local_md5,
    "expected_md5":     expected_md5,
    "local_channel":    local_channel,
    "expected_channel": expected_channel,
    "core":             info.get("core", ""),
    "display_version":  info.get("display_version", ""),
    "using_channel":    info.get("using_channel", False),
}))
PYEOF
}

# ─── STATUS: print all managed cores with version + hash ─────────────────────
channel_status() {
    python3 - "$MANIFEST" "$CHANNEL_DIR" "$SYSTEM_CORES" "$INFO_DIR" <<'PYEOF'
import json, os, sys, hashlib

manifest_path, channel_dir, sys_cores, info_dir = sys.argv[1:]

def md5_file(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()

if not os.path.exists(manifest_path):
    print(json.dumps({"error": "Manifest not found — run: netplay-cores.sh init"}))
    sys.exit(0)

with open(manifest_path) as f:
    manifest = json.load(f)

results = []
for core, entry in manifest.get("cores", {}).items():
    channel_so = os.path.join(channel_dir, f"{core}_libretro.so")
    system_so  = os.path.join(sys_cores,   f"{core}_libretro.so")
    if not os.path.exists(system_so):
        system_so = os.path.join(sys_cores, f"{core.replace('-', '_')}_libretro.so")

    channel_md5 = md5_file(channel_so) if os.path.exists(channel_so) else None
    system_md5  = md5_file(system_so)  if os.path.exists(system_so)  else None

    pinned_md5  = entry.get("md5", "")
    channel_ok  = (channel_md5 == pinned_md5) if (channel_md5 and pinned_md5) else False
    system_diff = (channel_md5 != system_md5)  if (channel_md5 and system_md5) else None

    results.append({
        "core":            core,
        "corename":        entry.get("corename", core),
        "display_version": entry.get("display_version", ""),
        "channel":         manifest.get("channel", ""),
        "pinned_md5":      pinned_md5[:12] + "…" if pinned_md5 else "",
        "channel_ok":      channel_ok,
        "system_differs":  system_diff,
        "pinned_at":       entry.get("pinned_at", ""),
        "source":          entry.get("source", "system"),
    })

print(json.dumps({
    "channel":  manifest.get("channel", ""),
    "updated":  manifest.get("updated", ""),
    "cores":    results
}, indent=2))
PYEOF
}

# ─── UPDATE CHANNEL: re-copy from system ─────────────────────────────────────
update_channel() {
    local target_core="${1:-}"   # empty = all

    if [ -z "$target_core" ]; then
        log "Updating ALL cores in channel from system..."
    else
        log "Updating channel core: $target_core"
    fi

    python3 - "$MANIFEST" "$CHANNEL_DIR" "$SYSTEM_CORES" "$INFO_DIR" \
              "$target_core" <<'PYEOF'
import json, os, sys, hashlib, shutil, datetime

manifest_path, channel_dir, sys_cores, info_dir, target_core = sys.argv[1:6]

INFO_ALIASES = {
    "snes9x_next":   "snes9x2010",
    "mame078plus":   "mame2003_plus",
    "genesisplusgx": "genesis_plus_gx",
}

def md5_file(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()

def find_sys_so(core, sys_cores):
    p = os.path.join(sys_cores, f"{core}_libretro.so")
    if os.path.exists(p):
        return p
    p2 = os.path.join(sys_cores, f"{core.replace('-', '_')}_libretro.so")
    return p2 if os.path.exists(p2) else ""

def read_info_field(core, field):
    for name in [core, INFO_ALIASES.get(core, "")]:
        if not name:
            continue
        p = os.path.join(info_dir, f"{name}_libretro.info")
        if not os.path.exists(p):
            continue
        with open(p) as f:
            for line in f:
                if line.strip().startswith(field):
                    parts = line.split("=", 1)
                    if len(parts) == 2:
                        return parts[1].strip().strip('"')
    return ""

if not os.path.exists(manifest_path):
    print(json.dumps({"error": "Run init first"}))
    sys.exit(1)

with open(manifest_path) as f:
    manifest = json.load(f)

today   = datetime.date.today().isoformat()
updated = []
cores   = [target_core] if target_core else list(manifest.get("cores", {}).keys())

for core in cores:
    if core not in manifest.get("cores", {}):
        print(f"  [SKIP] {core} not in manifest")
        continue

    if manifest["cores"][core].get("source") == "custom":
        print(f"  [SKIP] {core}: custom entry, not overwriting")
        continue

    sys_so = find_sys_so(core, sys_cores)
    dst_so = os.path.join(channel_dir, f"{core}_libretro.so")

    if not sys_so:
        print(f"  [MISS] {core}: system .so not found")
        continue

    old_md5 = manifest["cores"][core].get("md5", "")
    shutil.copy2(sys_so, dst_so)
    new_md5 = md5_file(dst_so)
    new_ver = read_info_field(core, "display_version")

    changed = (old_md5 != new_md5)
    manifest["cores"][core].update({
        "display_version": new_ver,
        "md5":             new_md5,
        "info_version":    new_ver,
        "pinned_at":       today,
        "source":          "system",
    })

    tag = "UPDATED" if changed else "SAME"
    print(f"  [{tag}] {core}: {new_ver or '?'} [{new_md5[:8]}…]"
          + (f"  (was {old_md5[:8]}…)" if changed else ""))
    updated.append({"core": core, "changed": changed, "version": new_ver})

manifest["updated"] = today
tmp_path = manifest_path + ".tmp"
with open(tmp_path, "w") as f:
    json.dump(manifest, f, indent=2)
os.replace(tmp_path, manifest_path)

print(json.dumps({"updated": updated, "manifest": manifest_path}))
PYEOF

    # Update stored Batocera version to clear the drift warning
    local _bv_file="/usr/share/batocera/version"
    if [ -f "$_bv_file" ]; then
        tr -d '[:space:]' < "$_bv_file" > "$CHANNEL_DIR/.batocera_version"
        rm -f /tmp/outbreak_core_drift_warning
    fi

    # Notify EmulationStation so the user sees confirmation on the platform wheel.
    local _notif_msg
    if [ -z "$target_core" ]; then
        _notif_msg="✅ Core channel updated"
    else
        _notif_msg="✅ Core updated: $target_core"
    fi
    command -v batocera-es-swissknife &>/dev/null && \
        batocera-es-swissknife --notification "$_notif_msg" 2>/dev/null
    [ -S /tmp/es.sock ] && \
        printf '<?xml version="1.0"?>\n<notification><message>%s</message></notification>\n' \
               "$_notif_msg" | nc -U /tmp/es.sock 2>/dev/null
}

# ─── PLACE CUSTOM: admin places a manually-built .so ─────────────────────────
place_custom() {
    local core="$1"
    local so_file="$2"

    core="${core%_libretro}"
    core="${core%.so}"

    [ ! -f "$so_file" ] && { echo '{"error":"File not found"}'; return 1; }

    local dst="$CHANNEL_DIR/${core}_libretro.so"
    cp "$so_file" "$dst"

    local h
    h=$(so_md5 "$dst")
    local ver
    ver=$(read_info_version "$core")
    local cn
    cn=$(read_corename "$core")

    python3 - "$MANIFEST" "$core" "$h" "$ver" "$cn" "$dst" <<'PYEOF'
import json, os, sys, datetime
manifest_path, core, h, ver, cn, dst = sys.argv[1:]

manifest = {}
if os.path.exists(manifest_path):
    try:
        with open(manifest_path) as f:
            manifest = json.load(f)
    except Exception:
        pass

manifest.setdefault("cores", {})[core] = {
    "display_version": ver,
    "corename":        cn,
    "md5":             h,
    "source":          "custom",
    "so_path":         dst,
    "info_version":    ver,
    "pinned_at":       datetime.date.today().isoformat(),
}
tmp_path = manifest_path + ".tmp"
with open(tmp_path, "w") as f:
    json.dump(manifest, f, indent=2)
os.replace(tmp_path, manifest_path)
print(json.dumps({"placed": True, "core": core, "md5": h, "version": ver}))
PYEOF
    log "Custom core placed: $core [$h]"
}

# ─── CORE DRIFT DETECTION (Task 6) ───────────────────────────────────────────
# Detects if Batocera's version changed since cores were last pinned.
check_core_drift() {
    local version_file="/usr/share/batocera/version"
    local stored_version_file="$CHANNEL_DIR/.batocera_version"
    local warning_file="/tmp/outbreak_core_drift_warning"

    if [ ! -f "$version_file" ]; then
        return 0
    fi

    local current_version
    current_version=$(cat "$version_file" 2>/dev/null | tr -d '[:space:]')

    if [ -z "$current_version" ]; then
        return 0
    fi

    if [ -f "$stored_version_file" ]; then
        local stored_version
        stored_version=$(cat "$stored_version_file" 2>/dev/null | tr -d '[:space:]')
        if [ "$current_version" != "$stored_version" ]; then
            local msg="Batocera updated: $stored_version -> $current_version. Netplay cores may be out of sync. Run: bash /userdata/system/netplay-arcade/scripts/netplay-cores.sh update"
            echo "$msg" > "$warning_file"
            log "DRIFT WARNING: $msg"
        else
            rm -f "$warning_file"
        fi
        # Do NOT update the stored version here — that suppresses the warning on
        # the very next call. The stored version is updated only by init/update-channel
        # once the admin has actually refreshed the cores.
    else
        # First run — write baseline version; no drift warning needed
        mkdir -p "$CHANNEL_DIR"
        echo "$current_version" > "$stored_version_file"
    fi
}

# ─── CHANNEL CURRENCY CHECK ───────────────────────────────────────────────────
# Returns 0 if the manifest's channel ID matches CHANNEL_ID (i.e. the pinned
# build date in the current script).  Returns 1 if the manifest is missing,
# corrupt, or was built from a different PINNED_BUILD_DATE.
# Called by boot.sh after auto-updates to decide whether re-init is needed.
check_channel_current() {
    [ -f "$MANIFEST" ] || return 1
    local stored_channel
    stored_channel=$(python3 -c "
import json, sys
try:
    m = json.load(open('$MANIFEST'))
    print(m.get('channel', ''))
except Exception:
    print('')
" 2>/dev/null)
    [ "$stored_channel" = "$CHANNEL_ID" ] && return 0 || return 1
}

# ─── MAIN DISPATCH ────────────────────────────────────────────────────────────
# Run drift check on every invocation (skip for check-channel — fast path)
[ "${1:-}" != "check-channel" ] && check_core_drift

case "$1" in
    init)            init_channel ;;
    resolve)         resolve_core_path "$2" ;;
    version)         get_core_version "$2" ;;
    verify)          verify_core "$2" "$3" "$4" ;;
    status)          channel_status ;;
    update-channel)  update_channel "$2" ;;
    place-custom)    place_custom "$2" "$3" ;;
    update)          update_channel "" ;;
    check-channel)   check_channel_current ;;
    *)
        echo "Usage: $0 {init|resolve <core>|version <core>|verify <core> <md5> [channel]|status|update-channel [core]|update|place-custom <core> <file.so>|check-channel}"
        exit 1
        ;;
esac
