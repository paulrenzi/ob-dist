#!/usr/bin/env python3
"""
DAT-based ROM hash verifier for Outbreak.

Reads Logiqx XML, ClrMame Pro XML, and ClrMame Pro text .dat files from a
directory and builds a JSON lookup cache mapping MD5 hashes to canonical ROM
names. Used by rom-checker.sh to verify console ROMs against No-Intro
canonical sets.

Place .dat files in /userdata/system/netplay-arcade/dats/ — any Logiqx,
ClrMame Pro XML, or ClrMame Pro text DAT works (No-Intro, Redump, etc.).
The cache is rebuilt automatically when DAT files change.

No-Intro DATs: https://www.no-intro.org/ (free account required)
Alternatively available at: https://archive.org/details/no-intro_romsets

Usage:
  dat_checker.py build-cache <dats_dir> <cache_path>
      Build JSON cache from all .dat/.xml files in dats_dir.

  dat_checker.py check-md5 <md5> <cache_path>
      Exit 0 and print match info if md5 is in cache; exit 1 if not found.

  dat_checker.py check-file <rom_path> <cache_path>
      Hash rom_path (handling zipped ROMs) and look it up in cache.
      Exit 0 if canonical, 1 if not found, 2 if cache missing.
"""

import sys
import os
import json
import hashlib
import re
import xml.etree.ElementTree as ET
from pathlib import Path


# ── Hashing ──────────────────────────────────────────────────────────────────

def md5_of_file(path: str) -> str:
    h = hashlib.md5()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(65536), b''):
            h.update(chunk)
    return h.hexdigest().lower()


def md5_of_rom(path: str) -> str:
    """
    Hash a ROM file. If it's a zip containing a single ROM binary, hash the
    inner file (matching No-Intro's convention of hashing the unzipped ROM).
    Falls back to hashing the zip itself if unzip isn't available or the zip
    contains multiple files.
    """
    ext = os.path.splitext(path)[1].lower()
    if ext == '.zip':
        try:
            import zipfile
            with zipfile.ZipFile(path, 'r') as z:
                members = [m for m in z.namelist()
                           if not m.endswith('/') and not m.startswith('__MACOSX')]
                if len(members) == 1:
                    with z.open(members[0]) as inner:
                        h = hashlib.md5()
                        for chunk in iter(lambda: inner.read(65536), b''):
                            h.update(chunk)
                        return h.hexdigest().lower()
        except Exception:
            pass
    return md5_of_file(path)


# ── DAT parsing ───────────────────────────────────────────────────────────────

def parse_dat_xml(dat_path: str) -> dict:
    """
    Parse a Logiqx XML or ClrMame Pro XML .dat file.

    Logiqx XML uses <game name="..."><rom md5="..."/></game>.
    ClrMame Pro XML uses <machine name="..."><rom md5="..."/></machine>.

    Returns dict: md5_lower -> {'name': game_name, 'rom': rom_filename, 'dat': dat_basename}
    """
    entries = {}
    dat_name = os.path.basename(dat_path)

    tree = ET.parse(dat_path)
    root = tree.getroot()

    for game in root.findall('.//game') + root.findall('.//machine'):
        game_name = game.get('name', '')
        for rom in game.findall('rom'):
            md5 = (rom.get('md5') or '').lower().strip()
            if md5 and len(md5) == 32:
                entries[md5] = {
                    'name': game_name,
                    'rom': rom.get('name', ''),
                    'dat': dat_name,
                }

    return entries


# Regex for ClrMame Pro text format:
#   game ( name "Game Name" rom ( name "file.ext" ... md5 ABCDEF01... ) )
_CMPro_GAME_RE = re.compile(
    r'^game\s*\(', re.MULTILINE
)
_CMPro_NAME_RE = re.compile(r'name\s+"([^"]*)"')
_CMPro_ROM_RE = re.compile(r'rom\s*\(([^)]+)\)')
_CMPro_MD5_RE = re.compile(r'\bmd5\s+([0-9a-fA-F]{32})\b')


def parse_dat_text(dat_path: str) -> dict:
    """
    Parse a ClrMame Pro text-format .dat file.

    Format:
        clrmamepro ( name "..." ... )
        game ( name "Game Name" rom ( name "file.ext" size 123 crc ABCD md5 ... ) )

    Returns dict: md5_lower -> {'name': game_name, 'rom': rom_filename, 'dat': dat_basename}
    """
    entries = {}
    dat_name = os.path.basename(dat_path)

    with open(dat_path, 'r', encoding='utf-8', errors='replace') as f:
        content = f.read()

    # Split into game blocks — each starts with "game (" at line start
    blocks = re.split(r'\ngame\s*\(', content)

    for i, block in enumerate(blocks):
        # First block is the header (clrmamepro section), skip unless it
        # starts with "game (" itself
        if i == 0 and not block.lstrip().startswith('game'):
            continue
        # Re-add the "game (" prefix that split removed (except block 0)
        if i == 0:
            block = block.lstrip()
            if block.startswith('game'):
                block = block[block.index('(') + 1:]

        name_m = _CMPro_NAME_RE.search(block)
        game_name = name_m.group(1) if name_m else ''

        for rom_m in _CMPro_ROM_RE.finditer(block):
            rom_body = rom_m.group(1)
            rom_name_m = _CMPro_NAME_RE.search(rom_body)
            rom_name = rom_name_m.group(1) if rom_name_m else ''
            md5_m = _CMPro_MD5_RE.search(rom_body)
            if md5_m:
                md5 = md5_m.group(1).lower()
                entries[md5] = {
                    'name': game_name,
                    'rom': rom_name,
                    'dat': dat_name,
                }

    return entries


def parse_dat(dat_path: str) -> dict:
    """
    Parse a .dat file, auto-detecting format (XML or ClrMame Pro text).
    Returns dict: md5_lower -> {'name': game_name, 'rom': rom_filename, 'dat': dat_basename}
    """
    # Try XML first
    try:
        return parse_dat_xml(dat_path)
    except ET.ParseError:
        pass

    # Fall back to ClrMame Pro text format
    try:
        return parse_dat_text(dat_path)
    except Exception as e:
        print(f"Warning: could not parse {dat_path}: {e}", file=sys.stderr)
        return {}


# ── Cache build ───────────────────────────────────────────────────────────────

def build_cache(dats_dir: str, cache_path: str) -> int:
    """
    Read all .dat and .xml files in dats_dir, merge into one dict, write JSON.
    Returns total number of entries indexed.
    """
    dats_dir_path = Path(dats_dir)
    cache: dict = {}
    dat_count = 0

    patterns = list(dats_dir_path.glob('*.dat')) + list(dats_dir_path.glob('*.xml'))
    # Exclude the cache file itself if it happens to be .xml
    patterns = [p for p in patterns if p.name != '.cache.json']

    for dat_file in sorted(patterns):
        entries = parse_dat(str(dat_file))
        if entries:
            cache.update(entries)
            dat_count += 1
            print(f"  {dat_file.name}: {len(entries):,} entries")

    tmp = cache_path + '.tmp'
    with open(tmp, 'w') as f:
        json.dump(cache, f, separators=(',', ':'))
    os.replace(tmp, cache_path)

    print(f"Cache built: {len(cache):,} entries from {dat_count} DAT file(s) → {cache_path}")
    return len(cache)


# ── Lookup ────────────────────────────────────────────────────────────────────

def load_cache(cache_path: str) -> dict | None:
    if not os.path.exists(cache_path):
        return None
    try:
        with open(cache_path) as f:
            return json.load(f)
    except Exception as e:
        print(f"Cache read error: {e}", file=sys.stderr)
        return None


def check_md5(md5: str, cache_path: str) -> bool:
    cache = load_cache(cache_path)
    if cache is None:
        print(f"No cache at {cache_path} — run: dat_checker.py build-cache <dats_dir> <cache_path>",
              file=sys.stderr)
        sys.exit(2)

    md5 = md5.lower().strip()
    entry = cache.get(md5)
    if entry:
        print(f"verified {entry['name']} [{entry['dat']}]")
        return True
    else:
        print(f"unknown md5={md5}")
        return False


def check_file(rom_path: str, cache_path: str) -> bool:
    cache = load_cache(cache_path)
    if cache is None:
        sys.exit(2)

    md5 = md5_of_rom(rom_path)
    entry = cache.get(md5)
    if entry:
        print(f"verified {os.path.basename(rom_path)} → {entry['name']} [{entry['dat']}]")
        return True
    else:
        print(f"unknown {os.path.basename(rom_path)} md5={md5}")
        return False


# ── CLI ───────────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    if len(sys.argv) < 4:
        print(__doc__)
        sys.exit(1)

    cmd = sys.argv[1]

    if cmd == 'build-cache':
        dats_dir, cache_path = sys.argv[2], sys.argv[3]
        if not os.path.isdir(dats_dir):
            print(f"Directory not found: {dats_dir}", file=sys.stderr)
            sys.exit(1)
        n = build_cache(dats_dir, cache_path)
        sys.exit(0 if n >= 0 else 1)

    elif cmd == 'check-md5':
        md5, cache_path = sys.argv[2], sys.argv[3]
        ok = check_md5(md5, cache_path)
        sys.exit(0 if ok else 1)

    elif cmd == 'check-file':
        rom_path, cache_path = sys.argv[2], sys.argv[3]
        ok = check_file(rom_path, cache_path)
        sys.exit(0 if ok else 1)

    else:
        print(__doc__)
        sys.exit(1)
