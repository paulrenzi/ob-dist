#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
export CORE_CHECKER_SCRIPT_DIR="$SCRIPT_DIR"
exec python3 - "$@" <<'PYEOF'
import json
import os
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional

SCRIPT_DIR = os.environ.get("CORE_CHECKER_SCRIPT_DIR", os.getcwd())
DEFAULT_INSTALL_DIR = "/userdata/system/netplay-arcade"
LOCAL_INSTALL_DIR = os.path.abspath(os.path.join(SCRIPT_DIR, ".."))
INSTALL_DIR = DEFAULT_INSTALL_DIR
if not os.path.isdir(DEFAULT_INSTALL_DIR) and not os.access("/userdata/system", os.W_OK):
    INSTALL_DIR = LOCAL_INSTALL_DIR

DB_FILE = os.path.join(INSTALL_DIR, "core_compat.json")
SYSTEM_CORES = "/usr/lib/libretro"
CHANNEL_CORES = os.path.join(INSTALL_DIR, "cores")
LOG_FILE = "/tmp/netplay-arcade.log"
ROMS_BASE = "/userdata/roms"

SYSTEM_CORE_PREFS = {
    "nes": ["fceumm", "nestopia", "mesen"],
    "snes": ["snes9x", "snes9x_next", "bsnes_mercury_performance"],
    "megadrive": ["genesisplusgx", "picodrive"],
    "genesis": ["genesisplusgx", "picodrive"],
    "gba": ["mgba", "gpsp"],
    "gb": ["gambatte", "sameboy", "mgba"],
    "gbc": ["gambatte", "sameboy", "mgba"],
    "ngp": ["mednafen_ngp"],
    "ngpc": ["mednafen_ngp"],
    "dreamcast": ["flycast"],
    "arcade": ["fbneo", "mame078plus", "mame"],
    "mame": ["mame078plus", "mame"],
    "fbneo": ["fbneo"],
    "neogeo": ["fbneo", "geolith"],
    "atari2600": ["stella"],
    "mastersystem": ["genesisplusgx", "picodrive"],
    "sega32x": ["picodrive"],
    "segacd": ["picodrive", "genesisplusgx"],
    "gamegear": ["genesisplusgx", "picodrive"],
    "turbografx16": ["mednafen_supergrafx"],
    "pcengine": ["mednafen_supergrafx"],
    "nds": ["desmume", "melonds"],
    "32x": ["picodrive"],
}

EXTENSION_MAP = {
    ".a26": "atari2600",
    ".gb": "gb",
    ".gba": "gba",
    ".gbc": "gbc",
    ".gen": "megadrive",
    ".gg": "gamegear",
    ".iso": "segacd",
    ".md": "megadrive",
    ".smd": "megadrive",
    ".nes": "nes",
    ".ngp": "ngp",
    ".ngc": "ngpc",
    ".gdi": "dreamcast",
    ".cdi": "dreamcast",
    ".neo": "neogeo",
    ".pce": "pcengine",
    ".rom": "neogeo",
    ".sfc": "snes",
    ".smc": "snes",
    ".sms": "mastersystem",
    ".nds": "nds",
    ".32x": "32x",
}


def log(message: str) -> None:
    ts = time.strftime("%H:%M:%S")
    with open(LOG_FILE, "a") as handle:
        handle.write(f"[{ts}] CORE: {message}\n")


def normalise_system(system: str) -> str:
    return (system or "").strip().lower()


def normalise_core(core: str) -> str:
    core = (core or "").strip()
    if core.endswith(".so"):
        core = core[:-3]
    if core.endswith("_libretro"):
        core = core[:-10]
    return core


def core_exists(core: str) -> bool:
    core = normalise_core(core)
    if not core:
        return False
    candidates = [
        Path(SYSTEM_CORES) / f"{core}_libretro.so",
        Path(SYSTEM_CORES) / f"{core}.so",
        Path(CHANNEL_CORES) / f"{core}_libretro.so",
    ]
    return any(path.exists() for path in candidates)


def installed_cores_for_system(system: str) -> List[str]:
    prefs = SYSTEM_CORE_PREFS.get(normalise_system(system), [])
    return [core for core in prefs if core_exists(core)]


def first_recommended_core(system: str) -> str:
    prefs = SYSTEM_CORE_PREFS.get(normalise_system(system), [])
    return prefs[0] if prefs else ""


def detect_system_from_rom(rom_path: str) -> str:
    rom = Path(rom_path)
    try:
        rel = rom.resolve().relative_to(Path(ROMS_BASE))
        if rel.parts:
            return normalise_system(rel.parts[0])
    except Exception:
        pass

    ext = rom.suffix.lower()
    if ext in EXTENSION_MAP:
        return EXTENSION_MAP[ext]

    parent = normalise_system(rom.parent.name)
    if parent in SYSTEM_CORE_PREFS:
        return parent
    return ""


def load_db() -> dict:
    try:
        with open(DB_FILE) as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_db(data: dict) -> None:
    os.makedirs(os.path.dirname(DB_FILE), exist_ok=True)
    with open(DB_FILE, "w") as handle:
        json.dump(data, handle, indent=2, sort_keys=True)


def build_entry(system: str, existing: Optional[Dict] = None) -> Dict:
    system = normalise_system(system)
    existing = existing or {}
    installed = installed_cores_for_system(system)
    recommended = normalise_core(existing.get("recommended", ""))
    if not recommended or not core_exists(recommended):
        recommended = installed[0] if installed else first_recommended_core(system)
    return {
        "recommended": recommended,
        "installed": installed,
        "known": SYSTEM_CORE_PREFS.get(system, []),
    }


def cmd_init() -> int:
    data = {}
    for system in sorted(SYSTEM_CORE_PREFS):
        data[system] = build_entry(system)
    save_db(data)
    print(json.dumps({
        "success": True,
        "systems": len(data),
        "db": DB_FILE,
    }))
    return 0


def cmd_set(system: str, core: str) -> int:
    system = normalise_system(system)
    core = normalise_core(core)
    if not system:
        print(json.dumps({"success": False, "error": "system required"}))
        return 1
    if not core:
        print(json.dumps({"success": False, "error": "core required"}))
        return 1
    if not core_exists(core):
        print(json.dumps({"success": False, "error": f"Core '{core}' not installed"}))
        return 1

    data = load_db()
    if system:
        entry = build_entry(system, data.get(system))
        if core not in entry["installed"]:
            entry["installed"].append(core)
            entry["installed"].sort()
        entry["recommended"] = core
        data[system] = entry
        save_db(data)
        log(f"Recommended core for {system} set to {core}")

    print(json.dumps({
        "success": True,
        "system": system,
        "core": core,
        "fixed": True,
    }))
    return 0


def cmd_detect(rom_path: str) -> int:
    system = detect_system_from_rom(rom_path)
    print(system or "unknown")
    return 0


def cmd_recommended(system: str) -> int:
    system = normalise_system(system)
    if not system:
        print("")
        return 1
    data = load_db()
    entry = build_entry(system, data.get(system))
    if data.get(system) != entry:
        data[system] = entry
        save_db(data)
    print(entry.get("recommended", ""))
    return 0 if entry.get("recommended") else 1


def cmd_check_fix(rom_path: str) -> int:
    if not rom_path:
        print(json.dumps({"success": False, "error": "rom required"}))
        return 1

    system = detect_system_from_rom(rom_path)
    if not system:
        print(json.dumps({"success": False, "error": "Could not detect ROM system"}))
        return 1

    data = load_db()
    entry = build_entry(system, data.get(system))
    fixed = False

    if not entry["recommended"]:
        print(json.dumps({
            "success": False,
            "error": f"No known cores for system '{system}'",
            "system": system,
        }))
        return 1

    if not core_exists(entry["recommended"]):
        installed = installed_cores_for_system(system)
        if not installed:
            print(json.dumps({
                "success": False,
                "error": f"No installed core found for system '{system}'",
                "system": system,
            }))
            return 1
        entry["recommended"] = installed[0]
        entry["installed"] = installed
        fixed = True

    if data.get(system) != entry:
        data[system] = entry
        save_db(data)

    print(json.dumps({
        "success": True,
        "fixed": fixed,
        "system": system,
        "core": entry["recommended"],
        "installed": entry["installed"],
    }))
    return 0


def main(argv: List[str]) -> int:
    if len(argv) < 2:
        print("Usage: core-checker.sh {init|detect <rom>|recommended <system>|set <system> <core>|check-fix <rom>}")
        return 1

    command = argv[1]
    if command == "init":
        return cmd_init()
    if command == "detect":
        rom_path = argv[2] if len(argv) > 2 else ""
        return cmd_detect(rom_path)
    if command == "recommended":
        system = argv[2] if len(argv) > 2 else ""
        return cmd_recommended(system)
    if command == "set":
        system = argv[2] if len(argv) > 2 else ""
        core = argv[3] if len(argv) > 3 else ""
        return cmd_set(system, core)
    if command == "check-fix":
        rom_path = argv[2] if len(argv) > 2 else ""
        return cmd_check_fix(rom_path)

    print("Usage: core-checker.sh {init|detect <rom>|recommended <system>|set <system> <core>|check-fix <rom>}")
    return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
PYEOF
