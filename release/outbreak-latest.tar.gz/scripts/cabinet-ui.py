#!/usr/bin/env python3
"""
Outbreak Arcade - Cabinet UI
Native pygame UI for Batocera cabinets without a web browser.
Talks to the REST API at http://localhost:8765.
"""

import sys
import os
import threading
import time
import json
import urllib.request
import urllib.error
import urllib.parse
import io

try:
    import pygame
except ImportError:
    print("ERROR: pygame is not installed. Install it with: pip install pygame")
    print("On Batocera: batocera-pkg install python-pygame")
    sys.exit(1)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

API_BASE = "http://localhost:8765"
POLL_INTERVAL = 3.0   # seconds between background polls
FPS = 30
DEBOUNCE_MS = 180
NOTIF_DURATION = 4.0  # seconds

# Colours
BG     = (3,   5,  16)
CARD   = (10,  20,  40)
CYAN   = (0,  245, 255)
PINK   = (255,  0, 110)
YELLOW = (255, 234,   0)
GREEN  = (57,  255,  20)
WHITE  = (255, 255, 255)
GREY   = (120, 130, 150)
RED    = (220,  50,  50)
DARK_CYAN  = (0, 80, 90)
DARK_PINK  = (80, 0, 40)
DARK_YELLOW = (70, 65, 0)

HEADER_H = 90
FOOTER_H = 70
CARD_H   = 200
CARD_PAD = 14
THUMB_SIZE = 150

# Button indices (Batocera layout)
BTN_A       = 0
BTN_START   = 7

def _detect_hotkey_btn() -> list[int]:
    """Read the hotkey button index from RetroArch config.
    Returns a list of button indices to check (always includes Select=6 as fallback)."""
    buttons = {6}  # Select — default fallback
    try:
        with open("/userdata/system/configs/retroarch/retroarchcustom.cfg") as f:
            for line in f:
                if line.strip().startswith("input_enable_hotkey_btn"):
                    val = line.split("=", 1)[1].strip().strip('"')
                    if val.isdigit():
                        buttons.add(int(val))
                    break
    except Exception:
        pass
    return list(buttons)

BTN_HOTKEYS = _detect_hotkey_btn()

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def game_stem(path: str) -> str:
    """Strip path components and extension: 'avsp.zip' → 'avsp'"""
    base = os.path.basename(path)
    stem, _ = os.path.splitext(base)
    return stem


def api_get(endpoint: str, params: dict = None, timeout: int = 8):
    """GET request to API, returns parsed JSON or None on failure."""
    url = API_BASE + endpoint
    if params:
        url += "?" + urllib.parse.urlencode(params)
    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception:
        return None


def api_get_binary(endpoint: str, params: dict = None, timeout: int = 10):
    """GET request returning raw bytes or None."""
    url = API_BASE + endpoint
    if params:
        url += "?" + urllib.parse.urlencode(params)
    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.read()
    except Exception:
        return None


def api_post(endpoint: str, body: dict, timeout: int = 30):
    """POST JSON to API, returns parsed JSON or None."""
    url = API_BASE + endpoint
    data = json.dumps(body).encode("utf-8")
    try:
        req = urllib.request.Request(
            url, data=data,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Font loader
# ---------------------------------------------------------------------------

def load_font(name: str, size: int):
    # Search: scripts dir, then ../ui/fonts/ (where boot.sh downloads TTF files)
    search = [
        os.path.join(SCRIPT_DIR, name),
        os.path.join(SCRIPT_DIR, '..', 'ui', 'fonts', name),
    ]
    for path in search:
        if os.path.isfile(path):
            try:
                return pygame.font.Font(path, size)
            except Exception:
                pass
    return pygame.font.SysFont("monospace", size)


# ---------------------------------------------------------------------------
# CRT scanline surface (created once)
# ---------------------------------------------------------------------------

def make_scanlines(width: int, height: int) -> pygame.Surface:
    surf = pygame.Surface((width, height), pygame.SRCALPHA)
    surf.fill((0, 0, 0, 0))
    line_color = (0, 0, 0, 55)
    for y in range(0, height, 4):
        pygame.draw.line(surf, line_color, (0, y), (width, y))
    return surf


# ---------------------------------------------------------------------------
# Notification manager
# ---------------------------------------------------------------------------

class Notification:
    def __init__(self, message: str, color=WHITE):
        self.message = message
        self.color = color
        self.created = time.monotonic()

    def alpha(self) -> int:
        age = time.monotonic() - self.created
        if age > NOTIF_DURATION:
            return 0
        if age > NOTIF_DURATION - 0.5:
            return int(255 * (NOTIF_DURATION - age) / 0.5)
        return 255

    def expired(self) -> bool:
        return time.monotonic() - self.created > NOTIF_DURATION


# ---------------------------------------------------------------------------
# Art cache
# ---------------------------------------------------------------------------

class ArtCache:
    """Fetches and caches game art thumbnails in background threads."""

    def __init__(self):
        self._lock = threading.Lock()
        self._cache: dict[str, pygame.Surface | None] = {}
        self._names: dict[str, str] = {}
        self._in_flight: set[str] = set()

    def get(self, stem: str) -> pygame.Surface | None:
        with self._lock:
            return self._cache.get(stem)

    def get_name(self, stem: str) -> str | None:
        with self._lock:
            return self._names.get(stem)

    def request(self, stem: str):
        with self._lock:
            if stem in self._cache or stem in self._in_flight:
                return
            self._in_flight.add(stem)
        t = threading.Thread(target=self._fetch, args=(stem,), daemon=True)
        t.start()

    def _fetch(self, stem: str):
        info = api_get("/game-info", {"game": stem})
        surf = None
        display_name = None
        if info:
            display_name = info.get("display_name")
            image_abs = info.get("image_abs", "")
            system    = info.get("system", "")
            if image_abs and system:
                data = api_get_binary("/game-art", {
                    "game": stem,
                    "system": system,
                    "imgpath": image_abs,
                })
                if data:
                    try:
                        raw = pygame.image.load(io.BytesIO(data)).convert_alpha()
                        rw, rh = raw.get_size()
                        scale = min(THUMB_SIZE / rw, THUMB_SIZE / rh)
                        surf = pygame.transform.smoothscale(raw, (int(rw * scale), int(rh * scale)))
                    except Exception:
                        surf = None
        with self._lock:
            self._cache[stem] = surf
            if display_name:
                self._names[stem] = display_name
            self._in_flight.discard(stem)


# ---------------------------------------------------------------------------
# State poller (background thread)
# ---------------------------------------------------------------------------

class Poller:
    def __init__(self):
        self._lock = threading.Lock()
        self._status: dict = {}
        self._peers: list = []
        self._wan_peers: list = []
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._running = False

    def get_state(self):
        with self._lock:
            return dict(self._status), list(self._peers), list(self._wan_peers)

    def _loop(self):
        while self._running:
            self._poll()
            time.sleep(POLL_INTERVAL)

    def _poll(self):
        status   = api_get("/status")   or {}
        peers    = api_get("/peers")    or {}
        wan      = api_get("/wan-peers") or {}
        with self._lock:
            self._status    = status
            self._peers     = peers.get("peers", [])
            self._wan_peers = wan.get("rooms", [])


# ---------------------------------------------------------------------------
# Drawing helpers
# ---------------------------------------------------------------------------

def draw_rect_border(surf: pygame.Surface, rect: pygame.Rect, color, width: int = 2):
    pygame.draw.rect(surf, color, rect, width, border_radius=4)


def draw_glow(surf: pygame.Surface, rect: pygame.Rect, color, spread: int = 6):
    """Draw a soft glow border by layering semi-transparent rectangles."""
    for i in range(spread, 0, -1):
        alpha = int(60 * (i / spread))
        glow_rect = rect.inflate(i * 2, i * 2)
        glow_surf = pygame.Surface(glow_rect.size, pygame.SRCALPHA)
        r, g, b = color
        pygame.draw.rect(glow_surf, (r, g, b, alpha), glow_surf.get_rect(), border_radius=4 + i)
        surf.blit(glow_surf, glow_rect.topleft)


def render_text_clipped(font, text: str, color, max_width: int) -> pygame.Surface:
    """Render text, truncating with '…' if wider than max_width."""
    surf = font.render(text, True, color)
    if surf.get_width() <= max_width:
        return surf
    ellipsis = font.render("…", True, color)
    ew = ellipsis.get_width()
    while len(text) > 0 and font.render(text, True, color).get_width() + ew > max_width:
        text = text[:-1]
    combined = font.render(text, True, color)
    out = pygame.Surface((combined.get_width() + ew, combined.get_height()), pygame.SRCALPHA)
    out.blit(combined, (0, 0))
    out.blit(ellipsis, (combined.get_width(), 0))
    return out


# ---------------------------------------------------------------------------
# Tag rendering
# ---------------------------------------------------------------------------

TAG_CONFIGS = {
    "LAN":  (CYAN,  (0, 50, 60)),
    "WAN":  (PINK,  (60, 0, 30)),
    "HOST": (YELLOW, (60, 55, 0)),
}

def draw_tag(surf: pygame.Surface, font, label: str, x: int, y: int) -> int:
    """Draw a coloured pill tag. Returns width consumed."""
    fg, bg = TAG_CONFIGS.get(label, (GREY, (30, 30, 40)))
    text_surf = font.render(label, True, fg)
    pad_x, pad_y = 10, 4
    w = text_surf.get_width() + pad_x * 2
    h = text_surf.get_height() + pad_y * 2
    tag_rect = pygame.Rect(x, y, w, h)
    pygame.draw.rect(surf, bg, tag_rect, border_radius=4)
    pygame.draw.rect(surf, fg, tag_rect, 1, border_radius=4)
    surf.blit(text_surf, (x + pad_x, y + pad_y))
    return w + 6


# ---------------------------------------------------------------------------
# Main application
# ---------------------------------------------------------------------------

class CabinetUI:
    def __init__(self):
        pygame.init()
        pygame.mixer.quit()  # no audio needed

        info = pygame.display.Info()
        self.W = info.current_w
        self.H = info.current_h

        self.screen = pygame.display.set_mode(
            (self.W, self.H),
            pygame.FULLSCREEN | pygame.NOFRAME
        )
        pygame.display.set_caption("Outbreak Arcade")
        pygame.mouse.set_visible(False)

        self.clock = pygame.time.Clock()

        # Fonts
        self.font_title   = load_font("press-start-2p.ttf", 32)
        self.font_game    = load_font("share-tech-mono.ttf", 28)
        self.font_tag     = load_font("share-tech-mono.ttf", 18)
        self.font_host    = load_font("share-tech-mono.ttf", 22)
        self.font_mono    = load_font("share-tech-mono.ttf", 22)

        # Larger fonts for stats and hosting banner
        self.font_stats   = load_font("share-tech-mono.ttf", 36)
        self.font_hosting = load_font("press-start-2p.ttf", 20)

        # CRT overlay
        self.scanlines = make_scanlines(self.W, self.H)

        # State
        self.poller = Poller()
        self.art    = ArtCache()

        self._lock        = threading.Lock()
        self.sessions: list[dict] = []
        self.cursor       = 0
        self.scroll       = 0
        self.notifications: list[Notification] = []
        self.last_nav_ms  = 0

        # Input: joystick
        pygame.joystick.init()
        self.joysticks: list[pygame.joystick.Joystick] = []
        for i in range(pygame.joystick.get_count()):
            js = pygame.joystick.Joystick(i)
            js.init()
            self.joysticks.append(js)

        # List area geometry
        self._list_y = HEADER_H + 4
        self._list_h = self.H - HEADER_H - FOOTER_H - 8
        self._cards_visible = max(1, self._list_h // (CARD_H + CARD_PAD))

        self._joining = False
        self._running = True

    # ------------------------------------------------------------------
    # Build session list from polled data
    # ------------------------------------------------------------------

    def _build_sessions(self, status: dict, peers: list, wan_peers: list) -> list[dict]:
        sessions = []

        hosting_session = status.get("session") or {}
        hosting_status  = hosting_session.get("status", "")
        is_hosting = hosting_status == "hosting"

        if is_hosting:
            sessions.append({
                "type":    "self",
                "eligible": False,
                "_self":   True,
                "_session": hosting_session,
            })

        for p in peers:
            sessions.append({
                "type":    "lan",
                "eligible": p.get("eligible", False),
                "_peer":   p,
            })

        for r in wan_peers:
            sessions.append({
                "type":    "wan",
                "eligible": r.get("eligible", False),
                "_room":   r,
            })

        return sessions

    # ------------------------------------------------------------------
    # Join logic
    # ------------------------------------------------------------------

    def _do_join(self, session: dict):
        if session.get("_self"):
            self._notify("You are already hosting this session.", YELLOW)
            return

        body: dict = {}
        stype = session.get("type")

        if stype == "lan":
            peer = session["_peer"]
            body["host"] = peer.get("ip", "")
        elif stype == "wan":
            room = session["_room"]
            body["host"] = room.get("host", "")
            if room.get("mitm_ip"):
                body["mitm_ip"]   = room["mitm_ip"]
                body["mitm_port"] = room.get("mitm_port")
        else:
            return

        if self._joining:
            return
        self._joining = True
        self._notify("Joining…", CYAN)

        def worker():
            result = api_post("/join-smart", body, timeout=30)
            self._joining = False
            if result is None:
                self._notify("Join failed: no response from server.", RED)
                return
            if result.get("error"):
                self._notify(f"Join error: {result['error']}", RED)
            elif result.get("needs_rom"):
                self._notify("Missing ROM for this game.", YELLOW)
            elif result.get("joined") or result.get("smart_join"):
                self._notify("Joined successfully!", GREEN)
            else:
                self._notify("Join returned unexpected response.", GREY)

        threading.Thread(target=worker, daemon=True).start()

    # ------------------------------------------------------------------
    # Notifications
    # ------------------------------------------------------------------

    def _notify(self, msg: str, color=WHITE):
        with self._lock:
            self.notifications.append(Notification(msg, color))

    # ------------------------------------------------------------------
    # Navigation
    # ------------------------------------------------------------------

    def _navigate(self, delta: int):
        now = pygame.time.get_ticks()
        if now - self.last_nav_ms < DEBOUNCE_MS:
            return
        self.last_nav_ms = now
        n = len(self.sessions)
        if n == 0:
            return
        self.cursor = (self.cursor + delta) % n
        # Scroll to keep cursor visible
        if self.cursor < self.scroll:
            self.scroll = self.cursor
        elif self.cursor >= self.scroll + self._cards_visible:
            self.scroll = self.cursor - self._cards_visible + 1

    # ------------------------------------------------------------------
    # Event handling
    # ------------------------------------------------------------------

    def _handle_events(self):
        start_held  = False
        select_held = False

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self._running = False

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self._running = False
                elif event.key == pygame.K_UP:
                    self._navigate(-1)
                elif event.key == pygame.K_DOWN:
                    self._navigate(1)
                elif event.key == pygame.K_RETURN:
                    if self.sessions:
                        self._do_join(self.sessions[self.cursor])

            elif event.type == pygame.JOYHATMOTION:
                _, y = event.value
                if y == 1:
                    self._navigate(-1)
                elif y == -1:
                    self._navigate(1)

            elif event.type == pygame.JOYAXISMOTION:
                if event.axis == 1:
                    if event.value < -0.5:
                        self._navigate(-1)
                    elif event.value > 0.5:
                        self._navigate(1)

            elif event.type == pygame.JOYBUTTONDOWN:
                if event.button == BTN_A:
                    if self.sessions:
                        self._do_join(self.sessions[self.cursor])

        # Check simultaneous HK+Start for exit (matches Batocera emulator exit combo)
        # Hotkey button is read from retroarchcustom.cfg at startup
        for js in self.joysticks:
            try:
                nb = js.get_numbuttons()
                hk = any(b < nb and js.get_button(b) for b in BTN_HOTKEYS)
                if hk and js.get_button(BTN_START):
                    self._running = False
            except Exception:
                pass

    # ------------------------------------------------------------------
    # Rendering
    # ------------------------------------------------------------------

    def _render(self, status: dict, sessions: list):
        screen = self.screen
        screen.fill(BG)

        self._draw_header(status)
        self._draw_sessions(sessions)
        self._draw_footer()
        self._draw_notifications()

        # CRT scanlines overlay
        screen.blit(self.scanlines, (0, 0))

        pygame.display.flip()

    # --- Header -------------------------------------------------------

    def _draw_header(self, status: dict):
        screen = self.screen
        W = self.W

        # Background bar
        pygame.draw.rect(screen, (6, 12, 28), (0, 0, W, HEADER_H))
        pygame.draw.line(screen, CYAN, (0, HEADER_H - 1), (W, HEADER_H - 1), 1)

        # Title: "OUTBREAK"
        title_surf = self.font_title.render("OUTBREAK", True, CYAN)
        screen.blit(title_surf, (14, (HEADER_H - title_surf.get_height()) // 2))

        # Status dot + label
        srv_status = status.get("status", "offline")
        dot_color  = GREEN if srv_status == "online" else RED
        label_text = srv_status.upper()
        dot_x = 14 + title_surf.get_width() + 16
        dot_y = HEADER_H // 2
        pygame.draw.circle(screen, dot_color, (dot_x, dot_y), 5)
        status_surf = self.font_mono.render(label_text, True, dot_color)
        screen.blit(status_surf, (dot_x + 10, dot_y - status_surf.get_height() // 2))

        # Top-right: IP + version
        local_ip = status.get("local_ip", "")
        version  = status.get("version", "")
        ver_label = version if version.startswith("v") else f"v{version}"
        info_str = f"{local_ip}  {ver_label}" if local_ip else ver_label
        info_surf = self.font_mono.render(info_str, True, GREY)
        screen.blit(info_surf, (W - info_surf.get_width() - 14,
                                (HEADER_H - info_surf.get_height()) // 2))

        # Center: HOSTING banner
        session = status.get("session") or {}
        if session.get("status") == "hosting":
            game_raw   = session.get("game", "")
            game_label = game_stem(game_raw).upper() if game_raw else "UNKNOWN"
            hosting_str = f"\u25b6 HOSTING: {game_label}"
            h_surf = self.font_hosting.render(hosting_str, True, PINK)
            cx = (W - h_surf.get_width()) // 2
            screen.blit(h_surf, (cx, (HEADER_H - h_surf.get_height()) // 2))

    # --- Session list -------------------------------------------------

    def _draw_sessions(self, sessions: list):
        screen = self.screen
        W = self.W

        list_x = 10
        list_w = W - 20
        y      = self._list_y

        if not sessions:
            msg = self.font_mono.render("No sessions found. Waiting for peers…", True, GREY)
            screen.blit(msg, (list_x + 10, y + 20))
            return

        visible = sessions[self.scroll: self.scroll + self._cards_visible]

        for i, s in enumerate(visible):
            idx       = self.scroll + i
            is_cursor = (idx == self.cursor)
            is_self   = s.get("_self", False)

            card_rect = pygame.Rect(list_x, y, list_w, CARD_H)

            # Card background
            pygame.draw.rect(screen, CARD, card_rect, border_radius=4)

            # Border / glow
            if is_self:
                draw_glow(screen, card_rect, PINK, spread=4)
                draw_rect_border(screen, card_rect, PINK, 2)
            elif is_cursor:
                draw_glow(screen, card_rect, YELLOW, spread=5)
                draw_rect_border(screen, card_rect, YELLOW, 2)
            else:
                draw_rect_border(screen, card_rect, (30, 45, 70), 1)

            # Thumbnail area
            thumb_rect = pygame.Rect(card_rect.x + 10, card_rect.y + (CARD_H - THUMB_SIZE) // 2,
                                     THUMB_SIZE, THUMB_SIZE)

            stem = self._session_stem(s)
            thumb = None
            if stem:
                thumb = self.art.get(stem)
                if thumb is None:
                    self.art.request(stem)

            if thumb:
                tw, th = thumb.get_size()
                bx = thumb_rect.x + (THUMB_SIZE - tw) // 2
                by = thumb_rect.y + (THUMB_SIZE - th) // 2
                screen.blit(thumb, (bx, by))
            else:
                pygame.draw.rect(screen, (20, 35, 60), thumb_rect, border_radius=3)
                placeholder = self.font_tag.render(stem[:4].upper() if stem else "?", True, GREY)
                px = thumb_rect.x + (THUMB_SIZE - placeholder.get_width()) // 2
                py = thumb_rect.y + (THUMB_SIZE - placeholder.get_height()) // 2
                screen.blit(placeholder, (px, py))

            # Text area
            tx = thumb_rect.right + 20
            ty = card_rect.y + (CARD_H - 70) // 2  # vertically centre the two text rows
            max_name_w = list_w - THUMB_SIZE - 50 - 180  # leave room for right-side info

            # Game display name
            display_name = self._session_display_name(s)
            name_surf = render_text_clipped(self.font_game, display_name, WHITE, max_name_w)
            screen.blit(name_surf, (tx, ty))

            # Second row: tag + host label
            tag_y = ty + name_surf.get_height() + 12
            tag_label = self._session_tag(s)
            tag_w = draw_tag(screen, self.font_tag, tag_label, tx, tag_y)

            host_label = self._session_host_label(s)
            if host_label:
                host_surf = self.font_host.render(host_label, True, GREY)
                screen.blit(host_surf, (tx + tag_w + 4, tag_y + 2))

            # Right-side info column
            right_x = card_rect.right - 20
            mid_y   = card_rect.y + CARD_H // 2

            # Ping
            ping = self._session_ping(s)
            if ping is not None:
                ping_color = GREEN if ping < 80 else (YELLOW if ping < 150 else RED)
                ping_text  = f"{ping}ms"
                ping_surf  = self.font_stats.render(ping_text, True, ping_color)
                screen.blit(ping_surf, (right_x - ping_surf.get_width(),
                                        mid_y - ping_surf.get_height() // 2 + 20))

            # Player count
            pc = self._session_player_count(s)
            if pc:
                pc_surf = self.font_stats.render(pc, True, CYAN)
                screen.blit(pc_surf, (right_x - pc_surf.get_width(),
                                      mid_y - pc_surf.get_height() // 2 - 20))

            y += CARD_H + CARD_PAD

        # Scroll indicators
        if self.scroll > 0:
            arrow = self.font_mono.render("▲", True, GREY)
            screen.blit(arrow, (W // 2 - arrow.get_width() // 2, self._list_y - arrow.get_height() - 2))
        if self.scroll + self._cards_visible < len(sessions):
            arrow = self.font_mono.render("▼", True, GREY)
            screen.blit(arrow, (W // 2 - arrow.get_width() // 2,
                                 self._list_y + self._cards_visible * (CARD_H + CARD_PAD) + 2))

    # --- Session field extractors -------------------------------------

    def _session_stem(self, s: dict) -> str:
        stype = s.get("type")
        if stype == "self":
            return game_stem(s.get("_session", {}).get("game", ""))
        elif stype == "lan":
            return game_stem(s["_peer"].get("session", {}).get("game", ""))
        elif stype == "wan":
            return game_stem(s["_room"].get("game", ""))
        return ""

    def _session_display_name(self, s: dict) -> str:
        stem = self._session_stem(s)
        if not stem:
            return "Unknown Game"
        cached = self.art.get_name(stem)
        if cached:
            return cached
        return stem.upper().replace("-", " ").replace("_", " ")

    def _session_tag(self, s: dict) -> str:
        stype = s.get("type")
        if stype == "self":
            return "HOST"
        elif stype == "lan":
            return "LAN"
        elif stype == "wan":
            return "WAN"
        return "???"

    def _session_host_label(self, s: dict) -> str:
        stype = s.get("type")
        if stype == "self":
            session = s.get("_session", {})
            return (session.get("system") or session.get("core") or "").upper() or "YOU"
        elif stype == "lan":
            peer = s["_peer"]
            session = peer.get("session", {})
            return (session.get("system") or session.get("core") or "").upper()
        elif stype == "wan":
            room = s["_room"]
            return (room.get("system") or room.get("core_name") or "").upper()
        return ""

    def _session_ping(self, s: dict) -> int | None:
        stype = s.get("type")
        if stype == "lan":
            v = s["_peer"].get("ping_ms")
            return int(v) if v is not None else None
        elif stype == "wan":
            v = s["_room"].get("ping_ms")
            return int(v) if v is not None else None
        return None

    def _session_player_count(self, s: dict) -> str:
        stype = s.get("type")
        session_data = None
        if stype == "self":
            session_data = s.get("_session", {})
        elif stype == "lan":
            session_data = s["_peer"].get("session", {})
        if session_data:
            pc  = session_data.get("player_count")
            max_p = session_data.get("max_players")
            if pc is not None and max_p is not None:
                return f"{pc}/{max_p}P"
            elif pc is not None:
                return f"{pc}P"
        return ""

    # --- Footer -------------------------------------------------------

    def _draw_footer(self):
        screen = self.screen
        W, H   = self.W, self.H

        pygame.draw.rect(screen, (6, 12, 28), (0, H - FOOTER_H, W, FOOTER_H))
        pygame.draw.line(screen, (30, 45, 70), (0, H - FOOTER_H), (W, H - FOOTER_H), 1)

        hints = [
            ("↑↓", "Navigate", CYAN),
            ("A",  "Join",     GREEN),
            ("HK+START", "Exit", RED),
        ]

        x = 20
        cy = H - FOOTER_H + FOOTER_H // 2
        for key, label, color in hints:
            key_surf = self.font_mono.render(key, True, color)
            screen.blit(key_surf, (x, cy - key_surf.get_height() // 2))
            x += key_surf.get_width() + 6
            lbl_surf = self.font_mono.render(label, True, GREY)
            screen.blit(lbl_surf, (x, cy - lbl_surf.get_height() // 2))
            x += lbl_surf.get_width() + 32

    # --- Notifications ------------------------------------------------

    def _draw_notifications(self):
        screen = self.screen
        W, H   = self.W, self.H

        with self._lock:
            self.notifications = [n for n in self.notifications if not n.expired()]
            notifs = list(self.notifications)

        x = W - 14
        y = H - FOOTER_H - 10

        for n in reversed(notifs):
            alpha = n.alpha()
            if alpha == 0:
                continue
            msg_surf = self.font_mono.render(n.message, True, n.color)
            pad = 8
            box_w = msg_surf.get_width()  + pad * 2
            box_h = msg_surf.get_height() + pad * 2
            box_x = x - box_w
            box_y = y - box_h

            box = pygame.Surface((box_w, box_h), pygame.SRCALPHA)
            box.fill((10, 20, 40, min(alpha, 220)))
            pygame.draw.rect(box, (*n.color, alpha), box.get_rect(), 1, border_radius=4)
            box.blit(msg_surf, (pad, pad))
            screen.blit(box, (box_x, box_y))

            y = box_y - 6

    # ------------------------------------------------------------------
    # Main loop
    # ------------------------------------------------------------------

    def run(self):
        while self._running:
            self._handle_events()

            status, peers, wan_peers = self.poller.get_state()
            sessions = self._build_sessions(status, peers, wan_peers)

            with self._lock:
                self.sessions = sessions
                # Clamp cursor
                if sessions:
                    self.cursor = max(0, min(self.cursor, len(sessions) - 1))
                    self.scroll = max(0, min(self.scroll, max(0, len(sessions) - self._cards_visible)))
                else:
                    self.cursor = 0
                    self.scroll = 0

            self._render(status, sessions)
            self.clock.tick(FPS)

        self.poller.stop()
        pygame.quit()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    app = CabinetUI()
    app.run()
