#!/bin/bash
# One-shot canonical ROM enforcement for FBNeo
# Every ROM in the set is canonical. Only remove regional duplicates:
# if a base game exists (e.g. avsp) AND a regional variant exists (e.g. avspu),
# quarantine the variant — but never quarantine a game that's in FBNEO_TITLES.
source "$(dirname "$0")/rom-checker.sh"

dest_dir="/userdata/roms/fbneo"
quarantine_dir="/userdata/roms/quarantine/fbneo"
variants_quarantined=0

# Known FBNeo region suffixes (single and double char)
region_suffixes="u j a b d e h k r ud ur ub"

# Build a set of all ROM names for O(1) lookup
declare -A rom_set
for rom in "$dest_dir"/*.zip; do
    [ -f "$rom" ] || continue
    rom_set[$(basename "$rom" .zip)]=1
done

# Find and quarantine regional duplicates
for name in "${!rom_set[@]}"; do
    # Never quarantine a game that's in our curated titles list
    [ -n "${FBNEO_TITLES[$name]+x}" ] && continue
    for suffix in $region_suffixes; do
        # Does this ROM name end with a known region suffix?
        base="${name%$suffix}"
        [ "$base" = "$name" ] && continue  # suffix didn't match
        [ -z "$base" ] && continue
        # Is the base game also present?
        [ -n "${rom_set[$base]+x}" ] || continue
        # This ROM is a regional variant of an existing base game — quarantine it
        mkdir -p "$quarantine_dir"
        mv "$dest_dir/$name.zip" "$quarantine_dir/$name.zip"
        for mext in thumb image; do
            [ -f "$dest_dir/images/${name}-${mext}.png" ] && \
                mv "$dest_dir/images/${name}-${mext}.png" "$quarantine_dir/" 2>/dev/null
        done
        ((variants_quarantined++))
        echo "Quarantined: $name.zip (regional variant of $base)"
        break  # only need one suffix match
    done
done

echo ""
echo "=== Results ==="
echo "Variants quarantined: $variants_quarantined"
[ "$variants_quarantined" -gt 0 ] && echo "Quarantine dir: $quarantine_dir"
