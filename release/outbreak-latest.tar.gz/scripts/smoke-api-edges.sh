#!/bin/bash
set -euo pipefail

BASE_URL="${1:-${BASE_URL:-http://127.0.0.1:8765}}"

log() {
    printf '[api-edges] %s\n' "$1"
}

assert_json() {
    local json="$1"
    local expr="$2"
    local message="$3"

    python3 - "$json" "$expr" "$message" <<'PYEOF'
import json
import sys

payload = json.loads(sys.argv[1])
expr = sys.argv[2]
message = sys.argv[3]
value = eval(expr, {}, {"payload": payload})
if not value:
    raise SystemExit(message)
PYEOF
}

wait_for_server() {
    local attempt
    for attempt in $(seq 1 30); do
        if curl -fsS "${BASE_URL}/status" >/dev/null 2>&1; then
            return 0
        fi
        sleep 1
    done
    echo "Server did not become ready at ${BASE_URL}" >&2
    exit 1
}

request_json() {
    local method="$1"
    local path="$2"
    local expected_code="$3"
    local data="${4:-}"
    local tmp body code

    tmp="$(mktemp)"
    if [ -n "$data" ]; then
        code="$(curl -sS -o "$tmp" -w '%{http_code}' -X "$method" \
            -H "Content-Type: application/json" \
            -d "$data" \
            "${BASE_URL}${path}")"
    else
        code="$(curl -sS -o "$tmp" -w '%{http_code}' -X "$method" \
            "${BASE_URL}${path}")"
    fi
    body="$(cat "$tmp")"
    rm -f "$tmp"

    if [ "$code" != "$expected_code" ]; then
        echo "Expected HTTP ${expected_code} for ${method} ${path}, got ${code}" >&2
        echo "$body" >&2
        exit 1
    fi

    printf '%s' "$body"
}

fetch_json() {
    request_json GET "$1" 200
}

restore_config() {
    local restore_body
    [ -n "${ORIGINAL_CONFIG_JSON:-}" ] || return 0
    restore_body="$(python3 - "$ORIGINAL_CONFIG_JSON" <<'PYEOF'
import json
import sys

cfg = json.loads(sys.argv[1])
allowed = {
    key: cfg[key]
    for key in ("username", "max_ping", "ra_username", "wan_enabled")
    if key in cfg
}
print(json.dumps(allowed))
PYEOF
)"
    curl -fsS -X POST "${BASE_URL}/save-config" \
        -H "Content-Type: application/json" \
        -d "$restore_body" >/dev/null || true
    curl -fsS -X POST "${BASE_URL}/stop" \
        -H "Content-Type: application/json" \
        -d '{}' >/dev/null || true
}

log "Waiting for ${BASE_URL}"
wait_for_server

ORIGINAL_CONFIG_JSON="$(fetch_json /config)"
trap restore_config EXIT

curl -fsS -X POST "${BASE_URL}/stop" \
    -H "Content-Type: application/json" \
    -d '{}' >/dev/null || true

resp="$(request_json POST /broadcast 400 '{"core":"snes9x"}')"
assert_json "$resp" 'payload.get("error") == "Missing: rom"' "broadcast missing-rom validation regressed"
log "broadcast rejects requests without a ROM"

resp="$(request_json POST /join 400 '{"host":"127.0.0.1","rom":"/tmp/game.sfc"}')"
assert_json "$resp" 'payload.get("error") == "Missing: core"' "join missing-core validation regressed"
log "join rejects requests with missing required fields"

resp="$(request_json POST /join 400 '{"host":"bad;host","rom":"/tmp/game.sfc","core":"snes9x"}')"
assert_json "$resp" 'payload.get("error") == "Invalid chars in host"' "join input sanitisation regressed"
log "join rejects shell metacharacters in host input"

resp="$(request_json POST /join-smart 400 '{}')"
assert_json "$resp" 'payload.get("error") == "host required"' "smart join missing-host validation regressed"
log "smart join requires a host target"

resp="$(request_json GET /core-version 400)"
assert_json "$resp" 'payload.get("error") == "core parameter required"' "core-version missing-core validation regressed"
log "core-version rejects requests without a core parameter"

resp="$(request_json GET /find-rom 400)"
assert_json "$resp" 'payload.get("error") == "q parameter required"' "find-rom missing-query validation regressed"
log "find-rom rejects requests without a query"

save_body="$(python3 <<'PYEOF'
import json

print(json.dumps({
    "username": "Arcade\nCrew",
    "max_ping": "55",
    "ra_username": "pilot-one",
    "wan_enabled": "false",
}))
PYEOF
)"
resp="$(request_json POST /save-config 200 "$save_body")"
assert_json "$resp" 'payload.get("saved") is True' "save-config did not report success"

config_json="$(fetch_json /config)"
assert_json "$config_json" 'payload.get("username") == "Arcade Crew"' "save-config did not sanitise embedded newlines"
assert_json "$config_json" 'payload.get("max_ping") == "55"' "save-config did not persist max_ping"
assert_json "$config_json" 'payload.get("ra_username") == "pilot-one"' "save-config did not persist ra_username"
assert_json "$config_json" 'payload.get("wan_enabled") == "false"' "save-config did not persist wan_enabled"
assert_json "$config_json" '"discord_webhook" not in payload and "rgsx_api_key" not in payload' "config endpoint exposed secret fields"
log "config save persists and sanitises allowed values"

status_json="$(fetch_json /status)"
assert_json "$status_json" 'payload.get("username") == "Arcade Crew"' "status endpoint did not reflect saved username"
assert_json "$status_json" 'payload.get("max_ping") == "55"' "status endpoint did not reflect saved max_ping"
assert_json "$status_json" 'payload.get("wan_enabled") is False' "status endpoint did not reflect saved wan_enabled"
log "status reflects the updated config state"

log "API edge smoke test passed"
